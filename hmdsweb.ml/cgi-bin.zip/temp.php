<?php
require_once 'md/Mobile_Detect.php';
$detect = new Mobile_Detect;
if($detect->isMobile()){

}else{}
?>