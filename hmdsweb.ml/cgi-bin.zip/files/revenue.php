<?php
$bernar1='<!-- BEGIN EroAdvertising ADSPACE CODE -->
<script type="text/javascript" language="javascript" charset="utf-8" src="//adspaces.ero-advertising.com/adspace/1984684.js"></script>
<!-- END EroAdvertising ADSPACE CODE -->
';
$bernar2='<!-- BEGIN EroAdvertising ADSPACE CODE -->
<script type="text/javascript" language="javascript" charset="utf-8" src="//adspaces.ero-advertising.com/adspace/1985972.js"></script>
<!-- END EroAdvertising ADSPACE CODE -->
';
$bernar3='<!-- BEGIN EroAdvertising ADSPACE CODE -->
<script type="text/javascript" language="javascript" charset="utf-8" src="//adspaces.ero-advertising.com/adspace/1985974.js"></script>
<!-- END EroAdvertising ADSPACE CODE -->

';

?>