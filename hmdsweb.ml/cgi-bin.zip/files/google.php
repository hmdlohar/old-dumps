<?php
$bernar3 = '<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Ani728x90 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-4449722018891371"
     data-ad-slot="9598683044"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>';

$bernar1 =  ' <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- AniAuto -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-4449722018891371"
     data-ad-slot="5028882646"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>';



$bernar2 = ' <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- AniAuto -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-4449722018891371"
     data-ad-slot="5028882646"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>';

$bernar3x =  '  <!-- Begin BidVertiser code -->
<SCRIPT LANGUAGE="JavaScript1.1" SRC="http://bdv.bidvertiser.com/BidVertiser.dbm?pid=580381&bid=1652468" type="text/javascript"></SCRIPT>
<noscript><a href="http://www.bidvertiser.com/bdv/BidVertiser/bdv_publisher_toolbar_creator.dbm">custom toolbar</a></noscript>
<!-- End BidVertiser code --> ';

$bernar4 =  ' <!-- Begin BidVertiser code -->
<SCRIPT LANGUAGE="JavaScript1.1" SRC="http://bdv.bidvertiser.com/BidVertiser.dbm?pid=580381&bid=1552437" type="text/javascript"></SCRIPT>
<noscript><a href="http://www.bidvertiser.com/bdv/BidVertiser/bdv_publisher_toolbar_creator.dbm">custom toolbar</a></noscript>
<!-- End BidVertiser code --> ';

?>