<?php
$dbhost = 'localhost';
$dbuser = 'hmdlohar_hmdsweb';
$dbpass = 'hamid445';
$dbname = 'hmdlohar_hmdsweb';
$conn = mysql_connect($dbhost, $dbuser, $dbpass);
if(! $conn )
{
  die('Could not connect: ' . mysql_error());
}

?>
