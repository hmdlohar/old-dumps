<?php
$bernar1 = '<script type="text/javascript" src="http://adhitzads.com/821811"></script>';
$bernar0 = ' <!-- Begin BidVertiser code -->
<SCRIPT LANGUAGE="JavaScript1.1" SRC="http://bdv.bidvertiser.com/BidVertiser.dbm?pid=580381&bid=1656634" type="text/javascript"></SCRIPT>
<!-- End BidVertiser code --> ';
$bernar2 = ' <script type="text/javascript" src="http://adhitzads.com/821810"></script>';

$bernar0 =  ' <!-- Begin BidVertiser code -->
<SCRIPT LANGUAGE="JavaScript1.1" SRC="http://bdv.bidvertiser.com/BidVertiser.dbm?pid=580381&bid=1656636" type="text/javascript"></SCRIPT>
<!-- End BidVertiser code --> ';
$bernar3 =  '<script type="text/javascript" src="http://adhitzads.com/821814"></script> ';

$bernar0 = ' <!-- Begin BidVertiser code -->
<SCRIPT LANGUAGE="JavaScript1.1" SRC="http://bdv.bidvertiser.com/BidVertiser.dbm?pid=580381&bid=1656635" type="text/javascript"></SCRIPT>
<!-- End BidVertiser code -->  ';
$bernar_mobile0 = '  <!-- Begin BidVertiser code -->
<SCRIPT LANGUAGE="JavaScript1.1" SRC="http://bdv.bidvertiser.com/BidVertiser.dbm?pid=580381&bid=1706099" type="text/javascript"></SCRIPT>
<!-- End BidVertiser code -->  ';
$bernar_mobile = ' <script type="text/javascript" src="http://adhitzads.com/822246"></script>  ';




?>
