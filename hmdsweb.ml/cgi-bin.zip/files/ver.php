<?php
$url = "http://ooltoo.in";
$site = "http://localhost/anisha778";
$xxxsite = "http://gals.kindgirls.com/go15x";

if(isset($_GET['nobernar'])){$bernar = "bernarx.php";}else{
$bernar = "bid_hmdsweb.php";}
$bernarx = "bernarx.php";

?>
