<?php
$bernar1 = '<iframe src="http://www.cpmleader.com/b_468x60.php?id=12650" width="468" height="60" frameborder="no" marginheight="0" marginwidth="0" scrolling="no"></iframe>';

$bernar3 =  ' <iframe src="http://www.cpmleader.com/b_160x600.php?id=12650" width="160" height="600" frameborder="no" marginheight="0" marginwidth="0" scrolling="no"></iframe>';

$bernar2 = ' <iframe src="http://www.cpmleader.com/b_728x90.php?id=12650" width="728" height="90" frameborder="no" marginheight="0" marginwidth="0" scrolling="no"></iframe>';

?>