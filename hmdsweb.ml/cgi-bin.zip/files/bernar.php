<?php
$bernar1 = '<iframe src="http://www.cpmleader.com/b_468x60.php?id=12650" width="468" height="60" frameborder="no" marginheight="0" marginwidth="0" scrolling="no"></iframe>';

$bernar3 =  ' <iframe src="http://www.cpmleader.com/b_160x600.php?id=12650" width="160" height="600" frameborder="no" marginheight="0" marginwidth="0" scrolling="no"></iframe>';

$bernar2 = ' <iframe src="http://www.cpmleader.com/b_728x90.php?id=12650" width="728" height="90" frameborder="no" marginheight="0" marginwidth="0" scrolling="no"></iframe>';

$bernar4 =  ' <!-- Begin BidVertiser code -->
<SCRIPT LANGUAGE="JavaScript1.1" SRC="http://bdv.bidvertiser.com/BidVertiser.dbm?pid=580381&bid=1552437" type="text/javascript"></SCRIPT>
<noscript><a href="http://www.bidvertiser.com/bdv/BidVertiser/bdv_publisher_toolbar_creator.dbm">custom toolbar</a></noscript>
<!-- End BidVertiser code --> ';

$bernar5 =  "<script type='text/javascript' src='http://ads.qadservice.com/t?id=740fa068-df17-4382-9253-80184615dd58&size=160x600'></script>";

$bernar6 = ' <!-- Begin BidVertiser code -->
<SCRIPT LANGUAGE="JavaScript1.1" SRC="http://bdv.bidvertiser.com/BidVertiser.dbm?pid=580381&bid=1452548" type="text/javascript"></SCRIPT>
<noscript><a href="http://www.bidvertiser.com/bdv/BidVertiser/bdv_publisher_toolbar_creator.dbm">custom toolbar</a></noscript>
<!-- End BidVertiser code --> ';

$bernar7 = ' <!-- Begin BidVertiser code -->
<SCRIPT LANGUAGE="JavaScript1.1" SRC="http://bdv.bidvertiser.com/BidVertiser.dbm?pid=580381&bid=1452548" type="text/javascript"></SCRIPT>
<noscript><a href="http://www.bidvertiser.com/bdv/BidVertiser/bdv_publisher_toolbar_creator.dbm">custom toolbar</a></noscript>
<!-- End BidVertiser code --> ';


?>
