<?php
$bernar1 = "";
$bernar2 = "";
$bernar3 = "";
$bernar4 = "";
$bernar5 = "";
$bernar6 = "";
$bernar_mobile = "";

?>