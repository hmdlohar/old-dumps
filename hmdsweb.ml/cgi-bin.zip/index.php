

<?php
include 'head.php';
include 'left.php';

?>

<div id=center>
	
	
<?php

include "pages/{$page}.php";
?>

</div>


<?php
include 'foot.php';
?>