<?php
include "../pages/redirect.php";

?>