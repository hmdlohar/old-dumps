<?php
include "../pages/full_movie.php";

?>