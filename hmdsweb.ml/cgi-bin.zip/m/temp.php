<?php
shell_exec("ls");

?>