<?php
include 'head.php';
?>

<div id=center>
	
	
<?php

include "pages/{$page}.php";
?>

</div>


<?php
include "foot.php";
?>