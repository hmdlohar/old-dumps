<?php header('Location:http://loegue.tk/smiles/');
?>
