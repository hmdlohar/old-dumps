<?
include_once '../sys/inc/start.php';
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/user.php';

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `news` LIMIT 1",$db), 0)==0)exit;

header("Content-type: application/rss+xml");
echo "<rss version=\"2.0\">\n";
echo "<channel>\n";
echo "<title>News ".$_SERVER['SERVER_NAME']."</title>\n";
echo "<link>http://".$_SERVER['SERVER_NAME']."</link>\n";
echo "<description>News ".$_SERVER['SERVER_NAME']."</description>\n";
echo "<language>ru-RU</language>\n";
//echo "<webMaster>$set[adm_mail]</webMaster>\n";
echo "<lastBuildDate>".date("r",mysql_result(mysql_query("SELECT MAX(time) FROM `news`",$db), 0))."</lastBuildDate>\n";


$q=mysql_query("SELECT * FROM `news` ORDER BY `id` DESC LIMIT $set[p_str]");

while ($post = mysql_fetch_assoc($q))
{
echo "<item>\n";
echo "<title>$post[title]</title>\n";
if ($post['link']!=NULL)
{
if (!ereg('^https?://',$post['link']))
echo "<link>".htmlentities("http://$_SERVER[SERVER_NAME]$post[link]", ENT_QUOTES, 'UTF-8')."</link>\n";
else
echo "<link>".htmlentities("$post[link]", ENT_QUOTES, 'UTF-8')."</link>\n";
}
echo "<description><![CDATA[";
echo output_text($post['msg'],true,true,false)."\n";
echo "]]></description>\n";
echo "<pubDate>".date("r",$post['time'])."</pubDate>\n";

echo "</item>\n";
}

echo "</channel>\n";
echo "</rss>\n";
?>
