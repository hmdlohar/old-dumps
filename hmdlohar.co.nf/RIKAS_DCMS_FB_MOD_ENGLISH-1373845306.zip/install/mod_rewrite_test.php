<?
echo 'mod_rewrite-ok';
?>