<?php

// remodified by noe
// http://nnetwork.tk
// loegue.info@gmail.com
// hargailah privasi orang

echo '<div class="penanda"><span class="lgn">Bookmark</span></div><div class="face">';
echo '<a href="/jurnal.php">Notifications</a><br/>';
echo '<a href="/chat/">Chatroom</a><br/>';
echo '<a href="/group/">Groups</a><br/>';
mysql_query("SELECT * FROM `user` WHERE `id` = '$ank[id]' LIMIT 1");
$user_id = $ank['id'];
echo "<a href='/blog/user.php'>Notes</a><br/>";
echo "<a href='/foto/'>Photos</a><br/>";
echo '<a href="/shout/">Shoutbox</a><br/>';
echo '<a href="/partner/">Sites</a><br/>';
echo '<a href="/menu.php">More...</a></div>';
?>
