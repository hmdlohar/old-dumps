USER MANAGEMENT SCRIPT uMScript v.1.0.3
=======================================
Created By: Evans Kirimi
Website: http://www.venturehapa.biz/umscript
Version: 1.0.1
Email:support@venturehapa.biz
FACEBOOK: http://facebook.com/UMScript

License: This script is provided for free and as is. You are welcome to modify, use and abuse this script in whichever way you choose. However, you must leave the credits for the file under lib/functions/ps_pagination.php intact.

I will not be held liable for any problems that may arise from use of this script.


REASON FOR WRITING THE SCRIPT
=============================

I was creating a log in system for a client's site and after completing it, he told me that he wanted to do his own CSS.

This gave me the idea to create a basic log in and user management system with administrator features that did not include CSS, so as to enable web developers mould the way it is presented to the user according to the way they wished.

I have added JQUERY to the PHP script that gives a seamless use of its forms. It is able to do the following:

[+] Administrator log in

[+] Administrator information management

[+] Administrator password management

[+] Administrator user management (edit, delete and suspend.)

[+] User log in

[+] User information management

[+] User password management

[+] Recover lost password through registered email address

[+] User upload photo

[+] User activate account through email confirmation



HOW TO USE / INSTALLATION
=========================

1 - Log in to your cPanel and create a database and user for the database.

2 - Assign the user with a password to that database.

3 - Update lib/connections/db.php with the above database, user and password information.

4 - Unzip umscript.zip

5 - Upload the files to your chosen directory

DONE!

7 - Optionally, you can email me and have me install the script for you for a fee of only $10.


CUSTOMIZATION OF REGISTRATION FORM
==================================

To add form fields to the registration form, please contact me via my facebook page http://facebook.com/UMScript.


SUPPORT
=======

I offer support via my facebook page http://facebook.com/UMScript. 

Customization, add-ons, feature requests, etc. are offered at a fee. Contact me for more information using the address above.

