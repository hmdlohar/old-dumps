<?php
/* customization area */
if (!defined('BZ_PARTNERID'))  {
define('BZ_PARTNERID', 71566);  // replace your partnerID here
}
$alternate_link = 'http://click.buzzcity.net/click.php?partnerid=71566';    // replace this to set an alternate link if no Ad is returned
$alternate_text = 'Visit More Sites' ;
/* End Customizaton area */
// Required for Ads API
define('BZ_API_VERSION', '1.1');
define('BZ_ADS_DOMAIN', 'ads.buzzcity.net');
define('BZ_CLICK_DOMAIN', 'click.buzzcity.net');
$ip = '' ;
$ua = '' ;
$browser = '' ;

// Extract full IP info (including Opera Mini)
if (empty($ip)) {
$keyname_ip_arr = array('HTTP_X_FORWARDED_FOR', 'HTTP_REMOTE_ADDR_REAL', 'REMOTE_ADDR');
foreach ($keyname_ip_arr as $keyname_ip) {
if (!empty($_SERVER[$keyname_ip])) {
$ip = urlencode($_SERVER[$keyname_ip]);
break;
}
}
}

// extract full UA info
$keyname_ua_arr = array('HTTP_X_DEVICE_USER_AGENT', 'HTTP_X_OPERAMINI_PHONE_UA','HTTP_X_BOLT_PHONE_UA', 'HTTP_X_MOBILE_UA', 'HTTP_USER_AGENT');
foreach ($keyname_ua_arr as $keyname_ua) {
if (isset($_SERVER[$keyname_ua]) && !empty($_SERVER[$keyname_ua])) {
$ua = urlencode($_SERVER[$keyname_ua]);
break;
}
}

// extract browser info
$keyname_browser_arr = array('OPERAMINI', 'BOLT');
foreach ($keyname_browser_arr as $keyname_browser) {
if (isset($_SERVER['HTTP_X_'.$keyname_browser.'_PHONE_UA'])) {
$browser = $keyname_browser;
break;
}
}

$url = 'http://'. BZ_ADS_DOMAIN . '/show.php?get=text&partnerid='. BZ_PARTNERID .'&i='. $ip . '&browser='. $browser . '&a='. $ua;

/* Use this if curl is not installed on your server */
$ad_serve = @fopen($url,'r');
$contents = '';
if ($ad_serve) {
while (!feof($ad_serve)) $contents .= fread($ad_serve,1024);
fclose($ad_serve);
}
/* Use this if fsockopen is not installed on your server */
// $ch = curl_init();
// curl_setopt($ch, CURLOPT_URL, $url);
// curl_setopt($ch, CURLOPT_HEADER, 0);
// curl_setopt($ch, CURLOPT_FAILONERROR, TRUE);
// curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
// curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
// $contents = curl_exec($ch);
// curl_close($ch);

$hasAd = FALSE;
if (!empty($contents)) {
$link = explode("\n", $contents);
if (isset($link) && !empty($link)) {
// display BuzzCity TextAd
$text = $link[0];
$cid = $link[1];
echo '<a href="http://' . BZ_CLICK_DOMAIN . '/click.php?cid=' . $cid . '&partnerid=' . BZ_PARTNERID . '">' . $text . '</a>';
$hasAd = TRUE;
}
}
if (!$hasAd) {
// No BuzzCity Ad, display alternate link
echo '<a href="' . $alternate_link . '">' . $alternate_text . '</a>';
}
?>
