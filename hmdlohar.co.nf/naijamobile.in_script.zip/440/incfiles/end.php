<?php
defined('_IN_JOHNCMS') or die('Error: restricted access');
echo '<div
class="mainblok"><div
class="menu" align="center"><div>'; if ($headmod != "mainpage" || ($headmod == 'mainpage' && $act)) { include_once('adiquity.php'); echo'</div>'; include_once('buzzcity.php'); } else { include_once('adiquity.php'); echo'</div><a href="http://click.buzzcity.net/click.php?partnerid=71566">Get to Win an IPad Today ?</a>'; }
echo '</div></div>';
echo '<div style="margin-bottom:2px"><div
class="orangex">Members: <a href="../users/index.php"> ' . counters::users() . ' </a><br/>'; include_once('member.php'); echo '</div></div></div>'; echo '<div
class="footer"><table
width="100%" cellpadding="0"
cellspacing="0"><tbody><tr><td
align="left"><font
color="yellow">Na</font><font
color="white">ijamobile</font></td><td width="auto"
align="right"><font
color="white">Page:</font> <font
color="yellow">'; list($msec,$sec)=explode(chr(3),microtime());
echo ''.round(($sec + $msec) - $conf['headtime'], 3).''; echo '</font> sec</td></tr></tbody></table></div><div align="center" style="padding:4px">Powered by <a href="http://harkorede.naijamobile.in"><font color="red">Harkorede</font></a></div></body></html>';
