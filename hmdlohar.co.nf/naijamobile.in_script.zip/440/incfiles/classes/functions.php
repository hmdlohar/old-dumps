<?php

/**
 * @package     JohnCMS
 * @link        http://johncms.com
 * @copyright   Copyright (C) 2008-2011 JohnCMS Community
 * @license     LICENSE.txt (see attached file)
 * @version     VERSION.txt (see attached file)
 * @author      http://johncms.com/about
 */

defined('_IN_JOHNCMS') or die('Restricted access');

class functions extends core
{
	/*
	-----------------------------------------------------------------
	Convert URL
	-----------------------------------------------------------------
	*/
	public static function converturl($text){
		$text = html_entity_decode(trim($text), ENT_QUOTES, 'UTF-8');
		$text=str_replace(" ","-", $text);
		$text=str_replace("--","-", $text);
		$text=str_replace("@","-",$text);
		$text=str_replace("/","-",$text);
		$text=str_replace("\\","-",$text);
		$text=str_replace(":","",$text);
		$text=str_replace("\"","",$text);
		$text=str_replace("'","",$text);
		$text=str_replace("<","",$text);
		$text=str_replace(">","",$text);
		$text=str_replace(",","",$text);
		$text=str_replace("?","",$text);
		$text=str_replace(";","",$text);
		$text=str_replace(".","",$text);
		$text=str_replace("[","",$text);
		$text=str_replace("]","",$text);
		$text=str_replace("(","",$text);
		$text=str_replace(")","",$text);
		$text=str_replace("*","",$text);
		$text=str_replace("!","",$text);
		$text=str_replace("$","-",$text);
		$text=str_replace("&","-and-",$text);
		$text=str_replace("%","",$text);
		$text=str_replace("#","",$text);
		$text=str_replace("^","",$text);
		$text=str_replace("=","",$text);
		$text=str_replace("+","",$text);
		$text=str_replace("~","",$text);
		$text=str_replace("`","",$text);
		$text=str_replace("--","-",$text);
		$text = preg_replace("/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/", 'a', $text);
		$text = preg_replace("/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/", 'a', $text);
		$text = preg_replace("/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/", 'e', $text);
		$text = preg_replace("/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/", 'e', $text);
		$text = preg_replace("/(ì|í|ị|ỉ|ĩ)/", 'i', $text);
		$text = preg_replace("/(ì|í|ị|ỉ|ĩ)/", 'i', $text);
		$text = preg_replace("/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/", 'o', $text);
		$text = preg_replace("/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/", 'o', $text);
		$text = preg_replace("/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/", 'u', $text);
		$text = preg_replace("/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/", 'u', $text);
		$text = preg_replace("/(ỳ|ý|ỵ|ỷ|ỹ)/", 'y', $text);
		$text = preg_replace("/(đ)/", 'd', $text);
		$text = preg_replace("/(ỳ|ý|ỵ|ỷ|ỹ)/", 'y', $text);
		$text = preg_replace("/(đ)/", 'd', $text);
		$text = preg_replace("/(À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ)/", 'A', $text);
		$text = preg_replace("/(À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ)/", 'A', $text);
		$text = preg_replace("/(È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ)/", 'E', $text);
		$text = preg_replace("/(È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ)/", 'E', $text);
		$text = preg_replace("/(Ì|Í|Ị|Ỉ|Ĩ)/", 'I', $text);
		$text = preg_replace("/(Ì|Í|Ị|Ỉ|Ĩ)/", 'I', $text);
		$text = preg_replace("/(Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ)/", 'O', $text);
		$text = preg_replace("/(Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ)/", 'O', $text);
		$text = preg_replace("/(Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ)/", 'U', $text);
		$text = preg_replace("/(Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ)/", 'U', $text);
		$text = preg_replace("/(Ỳ|Ý|Ỵ|Ỷ|Ỹ)/", 'Y', $text);
		$text = preg_replace("/(Đ)/", 'D', $text);
		$text = preg_replace("/(Ỳ|Ý|Ỵ|Ỷ|Ỹ)/", 'Y', $text);
		$text = preg_replace("/(Đ)/", 'D', $text);
		$text=strtolower($text);
		return $text;
	}

    /*
    -----------------------------------------------------------------
    ÐÐ½Ñ‚Ð¸Ñ„Ð»ÑƒÐ´
    -----------------------------------------------------------------
    Ð ÐµÐ¶Ð¸Ð¼Ñ‹ Ñ€Ð°Ð±Ð¾Ñ‚Ñ‹:
    1 - ÐÐ´Ð°Ð¿Ñ‚Ð¸Ð²Ð½Ñ‹Ð¹
    2 - Ð”ÐµÐ½ÑŒ / ÐÐ¾Ñ‡ÑŒ
    3 - Ð”ÐµÐ½ÑŒ
    4 - ÐÐ¾Ñ‡ÑŒ
    -----------------------------------------------------------------
    */
    public static function antiflood()
    {
        $default = array(
            'mode' => 2,
            'day' => 10,
            'night' => 30,
            'dayfrom' => 10,
            'dayto' => 22
        );
        $af = isset(self::$system_set['antiflood']) ? unserialize(self::$system_set['antiflood']) : $default;
        switch ($af['mode']) {
            case 1:
                // ÐÐ´Ð°Ð¿Ñ‚Ð¸Ð²Ð½Ñ‹Ð¹ Ñ€ÐµÐ¶Ð¸Ð¼
                $adm = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `rights` > 0 AND `lastdate` > " . (time() - 300)), 0);
                $limit = $adm > 0 ? $af['day'] : $af['night'];
                break;
            case 3:
                // Ð”ÐµÐ½ÑŒ
                $limit = $af['day'];
                break;
            case 4:
                // ÐÐ¾Ñ‡ÑŒ
                $limit = $af['night'];
                break;
            default:
                // ÐŸÐ¾ ÑƒÐ¼Ð¾Ð»Ñ‡Ð°Ð½Ð¸ÑŽ Ð´ÐµÐ½ÑŒ / Ð½Ð¾Ñ‡ÑŒ
                $c_time = date('G', time());
                $limit = $c_time > $af['day'] && $c_time < $af['night'] ? $af['day'] : $af['night'];
        }
        if (self::$user_rights > 0)
            $limit = 4; // Ð”Ð»Ñ ÐÐ´Ð¼Ð¸Ð½Ð¸ÑÑ‚Ñ€Ð°Ñ†Ð¸Ð¸ Ð·Ð°Ð´Ð°ÐµÐ¼ Ð»Ð¸Ð¼Ð¸Ñ‚ Ð² 4 ÑÐµÐºÑƒÐ½Ð´Ñ‹
        $flood = self::$user_data['lastpost'] + $limit - time();
        if ($flood > 0)
            return $flood;
        else
            return false;
    }

    /*
    -----------------------------------------------------------------
    ÐœÐ°ÑÐºÐ¸Ñ€Ð¾Ð²ÐºÐ° ÑÑÑ‹Ð»Ð¾Ðº Ð² Ñ‚ÐµÐºÑÑ‚Ðµ
    -----------------------------------------------------------------
    */
    public static function antilink($var)
    {
        $var = preg_replace('~\\[url=(https?://.+?)\\](.+?)\\[/url\\]|(https?://(www.)?[0-9a-z\.-]+\.[0-9a-z]{2,6}[0-9a-zA-Z/\?\.\~&amp;_=/%-:#]*)~', '###', $var);
        $replace = array(
            '.ru' => '***',
            '.com' => '***',
            '.biz' => '***',
            '.cn' => '***',
            '.in' => '***',
            '.net' => '***',
            '.org' => '***',
            '.info' => '***',
            '.mobi' => '***',
            '.wen' => '***',
            '.kmx' => '***',
            '.h2m' => '***'
        );
        return strtr($var, $replace);
    }

    /*
    -----------------------------------------------------------------
    ÐŸÑ€Ð¾Ð²ÐµÑ€ÐºÐ° Ð¿ÐµÑ€ÐµÐ¼ÐµÐ½Ð½Ñ‹Ñ…
    -----------------------------------------------------------------
    */
    public static function check($str)
    {
        $str = htmlentities(trim($str), ENT_QUOTES, 'UTF-8');
        $str = nl2br($str);
        $str = strtr($str, array(
                                chr(0) => '',
                                chr(1) => '',
                                chr(2) => '',
                                chr(3) => '',
                                chr(4) => '',
                                chr(5) => '',
                                chr(6) => '',
                                chr(7) => '',
                                chr(8) => '',
                                chr(9) => '',
                                chr(10) => '',
                                chr(11) => '',
                                chr(12) => '',
                                chr(13) => '',
                                chr(14) => '',
                                chr(15) => '',
                                chr(16) => '',
                                chr(17) => '',
                                chr(18) => '',
                                chr(19) => '',
                                chr(20) => '',
                                chr(21) => '',
                                chr(22) => '',
                                chr(23) => '',
                                chr(24) => '',
                                chr(25) => '',
                                chr(26) => '',
                                chr(27) => '',
                                chr(28) => '',
                                chr(29) => '',
                                chr(30) => '',
                                chr(31) => ''
                           ));
        $str = str_replace("'", "&#39;", $str);
        $str = str_replace('\\', "&#92;", $str);
        $str = str_replace("|", "I", $str);
        $str = str_replace("||", "I", $str);
        $str = str_replace("/\\\$/", "&#36;", $str);
        $str = mysql_real_escape_string($str);
        return $str;
    }

    /*
    -----------------------------------------------------------------
    ÐžÐ±Ñ€Ð°Ð±Ð¾Ñ‚ÐºÐ° Ñ‚ÐµÐºÑÑ‚Ð¾Ð² Ð¿ÐµÑ€ÐµÐ´ Ð²Ñ‹Ð²Ð¾Ð´Ð¾Ð¼ Ð½Ð° ÑÐºÑ€Ð°Ð½
    -----------------------------------------------------------------
    $br=1           Ð¾Ð±Ñ€Ð°Ð±Ð¾Ñ‚ÐºÐ° Ð¿ÐµÑ€ÐµÐ½Ð¾ÑÐ¾Ð² ÑÑ‚Ñ€Ð¾Ðº
    $br=2           Ð¿Ð¾Ð´ÑÑ‚Ð°Ð½Ð¾Ð²ÐºÐ° Ð¿Ñ€Ð¾Ð±ÐµÐ»Ð°, Ð²Ð¼ÐµÑÑ‚Ð¾ Ð¿ÐµÑ€ÐµÐ½Ð¾ÑÐ°
    $tags=1         Ð¾Ð±Ñ€Ð°Ð±Ð¾Ñ‚ÐºÐ° Ñ‚ÑÐ³Ð¾Ð²
    $tags=2         Ð²Ñ‹Ñ€ÐµÐ·Ð°Ð½Ð¸Ðµ Ñ‚ÑÐ³Ð¾Ð²
    -----------------------------------------------------------------
    */
    public static function checkout($str, $br = 0, $tags = 0)
    {
        $str = htmlentities(trim($str), ENT_QUOTES, 'UTF-8');
        if ($br == 1)
            $str = nl2br($str);
        elseif ($br == 2)
            $str = str_replace("\r\n", ' ', $str);
        if ($tags == 1)
            $str = bbcode::tags($str);
        elseif ($tags == 2)
            $str = bbcode::notags($str);
        $replace = array(
            chr(0) => '',
            chr(1) => '',
            chr(2) => '',
            chr(3) => '',
            chr(4) => '',
            chr(5) => '',
            chr(6) => '',
            chr(7) => '',
            chr(8) => '',
            chr(9) => '',
            chr(11) => '',
            chr(12) => '',
            chr(13) => '',
            chr(14) => '',
            chr(15) => '',
            chr(16) => '',
            chr(17) => '',
            chr(18) => '',
            chr(19) => '',
            chr(20) => '',
            chr(21) => '',
            chr(22) => '',
            chr(23) => '',
            chr(24) => '',
            chr(25) => '',
            chr(26) => '',
            chr(27) => '',
            chr(28) => '',
            chr(29) => '',
            chr(30) => '',
            chr(31) => ''
        );
        return strtr($str, $replace);
    }

    /*
    -----------------------------------------------------------------
    ÐŸÐ¾ÐºÐ°Ð· Ñ€Ð°Ð·Ð»Ð¸Ñ‡Ð½Ñ‹Ñ… ÑÑ‡ÐµÑ‚Ñ‡Ð¸ÐºÐ¾Ð² Ð²Ð½Ð¸Ð·Ñƒ ÑÑ‚Ñ€Ð°Ð½Ð¸Ñ†Ñ‹
    -----------------------------------------------------------------
    */
    public static function display_counters()
    {
        global $headmod;
        $req = mysql_query("SELECT * FROM `cms_counters` WHERE `switch` = '1' ORDER BY `sort` ASC");
        if (mysql_num_rows($req) > 0) {
            while (($res = mysql_fetch_array($req)) !== false) {
                $link1 = ($res['mode'] == 1 || $res['mode'] == 2) ? $res['link1'] : $res['link2'];
                $link2 = $res['mode'] == 2 ? $res['link1'] : $res['link2'];
                $count = ($headmod == 'mainpage') ? $link1 : $link2;
                if (!empty($count))
                    echo $count;
            }
        }
    }

    /*
    -----------------------------------------------------------------
    ÐŸÐ¾ÐºÐ°Ð·Ñ‹Ð²Ð°ÐµÐ¼ Ð´Ð°Ñ‚Ñƒ Ñ ÑƒÑ‡ÐµÑ‚Ð¾Ð¼ ÑÐ´Ð²Ð¸Ð³Ð° Ð²Ñ€ÐµÐ¼ÐµÐ½Ð¸
    -----------------------------------------------------------------
    */
    public static function display_date($var)
    {
        $shift = (self::$system_set['timeshift'] + self::$user_set['timeshift']) * 3600;
        if (date('Y', $var) == date('Y', time())) {
            if (date('z', $var + $shift) == date('z', time() + $shift))
                return self::$lng['today'] . ' ' . date("H:i", $var + $shift);
            if (date('z', $var + $shift) == date('z', time() + $shift) - 1)
                return self::$lng['yesterday'] . ' ' . date("H:i", $var + $shift);
        }
        return date("d.m.Y H:i", $var + $shift);
    }

    /*
    -----------------------------------------------------------------
    Ð¡Ð¾Ð¾Ð±Ñ‰ÐµÐ½Ð¸Ñ Ð¾Ð± Ð¾ÑˆÐ¸Ð±ÐºÐ°Ñ…
    -----------------------------------------------------------------
    */
    public static function display_error($error = NULL, $link = NULL)
    {
        if (!empty($error)) {
            return '<div class="rmenu"><p><b>' . self::$lng['error'] . '!</b><br />' .
                   (is_array($error) ? implode('<br />', $error) : $error) . '</p>' .
                   (!empty($link) ? '<p>' . $link . '</p>' : '') . '</div>';
        } else {
            return false;
        }
    }

    /*
    -----------------------------------------------------------------
    ÐžÑ‚Ð¾Ð±Ñ€Ð°Ð¶ÐµÐ½Ð¸Ðµ Ñ€Ð°Ð·Ð»Ð¸Ñ‡Ð½Ñ‹Ñ… Ð¼ÐµÐ½ÑŽ
    -----------------------------------------------------------------
    $delimiter - Ñ€Ð°Ð·Ð´ÐµÐ»Ð¸Ñ‚ÐµÐ»ÑŒ Ð¼ÐµÐ¶Ð´Ñƒ Ð¿ÑƒÐ½ÐºÑ‚Ð°Ð¼Ð¸
    $end_space - Ð²Ñ‹Ð²Ð¾Ð´Ð¸Ñ‚ÑÑ Ð² ÐºÐ¾Ð½Ñ†Ðµ
    -----------------------------------------------------------------
    */
    public static function display_menu($val = array(), $delimiter = ' | ', $end_space = '')
    {
        return implode($delimiter, array_diff($val, array(''))) . $end_space;
    }

    /*
    -----------------------------------------------------------------
    ÐŸÐ¾ÑÑ‚Ñ€Ð°Ð½Ð¸Ñ‡Ð½Ð°Ñ Ð½Ð°Ð²Ð¸Ð³Ð°Ñ†Ð¸Ñ
    Ð—Ð° Ð¾ÑÐ½Ð¾Ð²Ñƒ Ð²Ð·ÑÑ‚Ð° Ð°Ð½Ð°Ð»Ð¾Ð³Ð¸Ñ‡Ð½Ð°Ñ Ñ„ÑƒÐ½ÐºÑ†Ð¸Ñ Ð¾Ñ‚ Ñ„Ð¾Ñ€ÑƒÐ¼Ð° SMF2.0
    -----------------------------------------------------------------
    */
    public static function display_pagination($base_url, $start, $max_value, $num_per_page)
    {
        $neighbors = 2;
        if ($start >= $max_value)
            $start = max(0, (int)$max_value - (((int)$max_value % (int)$num_per_page) == 0 ? $num_per_page : ((int)$max_value % (int)$num_per_page)));
        else
            $start = max(0, (int)$start - ((int)$start % (int)$num_per_page));
        $base_link = '<a class="pagenav" href="' . strtr($base_url, array('%' => '%%')) . 'page=%d' . '">%s</a>';
        $out[] = $start == 0 ? '' : sprintf($base_link, $start / $num_per_page, '&lt;&lt;');
        if ($start > $num_per_page * $neighbors)
            $out[] = sprintf($base_link, 1, '1');
        if ($start > $num_per_page * ($neighbors + 1))
            $out[] = '<span style="font-weight: bold;">...</span>';
        for ($nCont = $neighbors; $nCont >= 1; $nCont--)
            if ($start >= $num_per_page * $nCont) {
                $tmpStart = $start - $num_per_page * $nCont;
                $out[] = sprintf($base_link, $tmpStart / $num_per_page + 1, $tmpStart / $num_per_page + 1);
            }
        $out[] = '<span class="currentpage"><b>' . ($start / $num_per_page + 1) . '</b></span>';
        $tmpMaxPages = (int)(($max_value - 1) / $num_per_page) * $num_per_page;
        for ($nCont = 1; $nCont <= $neighbors; $nCont++)
            if ($start + $num_per_page * $nCont <= $tmpMaxPages) {
                $tmpStart = $start + $num_per_page * $nCont;
                $out[] = sprintf($base_link, $tmpStart / $num_per_page + 1, $tmpStart / $num_per_page + 1);
            }
        if ($start + $num_per_page * ($neighbors + 1) < $tmpMaxPages)
            $out[] = '<span style="font-weight: bold;">...</span>';
        if ($start + $num_per_page * $neighbors < $tmpMaxPages)
            $out[] = sprintf($base_link, $tmpMaxPages / $num_per_page + 1, $tmpMaxPages / $num_per_page + 1);
        if ($start + $num_per_page < $max_value) {
            $display_page = ($start + $num_per_page) > $max_value ? $max_value : ($start / $num_per_page + 2);
            $out[] = sprintf($base_link, $display_page, '&gt;&gt;');
        }
        return implode(' ', $out);
    }

    public static function display_pagination2($base_url, $start, $max_value, $num_per_page) {
        $pgcont = 4;
        $pgcont = (int)($pgcont - ($pgcont % 2)) / 2;

        if ($start >= $max_value)
            $start = max(0, (int)$max_value - (((int)$max_value % (int)$num_per_page) == 0 ? $num_per_page : ((int)$max_value % (int)$num_per_page)));
        else
            $start = max(0, (int)$start - ((int)$start % (int)$num_per_page));
        $base_link = '<a class="pagenav" href="' . strtr($base_url, array ('%' => '%%')) . '_s%d.html' . '">%s</a> ';
        $pageindex = $start == 0 ? '' : sprintf($base_link, $start - $num_per_page, '&lt;&lt;');

        if ($start > $num_per_page * $pgcont)
            $pageindex .= sprintf($base_link, 0, '1');

        if ($start > $num_per_page * ($pgcont + 1))
            $pageindex .= '<span style="font-weight: bold;"> ... </span>';

        for ($nCont = $pgcont; $nCont >= 1; $nCont--)
            if ($start >= $num_per_page * $nCont) {
                $tmpStart = $start - $num_per_page * $nCont;
                $pageindex .= sprintf($base_link, $tmpStart, $tmpStart / $num_per_page + 1);
            }
        $pageindex .= '<span class="currentpage"><b>' . ($start / $num_per_page + 1) . '</b></span> ';
        $tmpMaxPages = (int)(($max_value - 1) / $num_per_page) * $num_per_page;

        for ($nCont = 1; $nCont <= $pgcont; $nCont++)
            if ($start + $num_per_page * $nCont <= $tmpMaxPages) {
                $tmpStart = $start + $num_per_page * $nCont;
                $pageindex .= sprintf($base_link, $tmpStart, $tmpStart / $num_per_page + 1);
            }

        if ($start + $num_per_page * ($pgcont + 1) < $tmpMaxPages)
            $pageindex .= '<span style="font-weight: bold;"> ... </span>';

        if ($start + $num_per_page * $pgcont < $tmpMaxPages)
            $pageindex .= sprintf($base_link, $tmpMaxPages, $tmpMaxPages / $num_per_page + 1);

        if ($start + $num_per_page < $max_value) {
            $display_page = ($start + $num_per_page) > $max_value ? $max_value : ($start + $num_per_page);
            $pageindex .= sprintf($base_link, $display_page, '&gt;&gt;');
        }
        return $pageindex;
    }

    /*
    -----------------------------------------------------------------
    ÐŸÐ¾ÐºÐ°Ð·Ñ‹Ð²Ð°ÐµÐ¼ Ð¼ÐµÑÑ‚Ð¾Ð¿Ð¾Ð»Ð¾Ð¶ÐµÐ½Ð¸Ðµ Ð¿Ð¾Ð»ÑŒÐ·Ð¾Ð²Ð°Ñ‚ÐµÐ»Ñ
    -----------------------------------------------------------------
    */
    public static function display_place($user_id = '', $place = '')
    {
        global $headmod;
        $place = explode(",", $place);
        $placelist = parent::load_lng('places');
        if (array_key_exists($place[0], $placelist)) {
            if ($place[0] == 'profile') {
                if ($place[1] == $user_id) {
                    return '<a href="' . self::$system_set['homeurl'] . '/users/profile.php?user=' . $place[1] . '">' . $placelist['profile_personal'] . '</a>';
                } else {
                    $user = self::get_user($place[1]);
                    return $placelist['profile'] . ': <a href="' . self::$system_set['homeurl'] . '/users/profile.php?user=' . $user['id'] . '">' . $user['name'] . '</a>';
                }
            }
            elseif ($place[0] == 'online' && isset($headmod) && $headmod == 'online') return $placelist['here'];
            else return str_replace('#home#', self::$system_set['homeurl'], $placelist[$place[0]]);
        }
        else return '<a href="' . self::$system_set['homeurl'] . '/index.php">' . $placelist['homepage'] . '</a>';
    }

    /*
    -----------------------------------------------------------------
    ÐžÑ‚Ð¾Ð±Ñ€Ð°Ð¶ÐµÐ½Ð¸Ñ Ð»Ð¸Ñ‡Ð½Ñ‹Ñ… Ð´Ð°Ð½Ð½Ñ‹Ñ… Ð¿Ð¾Ð»ÑŒÐ·Ð¾Ð²Ð°Ñ‚ÐµÐ»Ñ
    -----------------------------------------------------------------
    $user          (array)     Ð¼Ð°ÑÑÐ¸Ð² Ð·Ð°Ð¿Ñ€Ð¾ÑÐ° Ð² Ñ‚Ð°Ð±Ð»Ð¸Ñ†Ñƒ `users`
    $arg           (array)     ÐœÐ°ÑÑÐ¸Ð² Ð¿Ð°Ñ€Ð°Ð¼ÐµÑ‚Ñ€Ð¾Ð² Ð¾Ñ‚Ð¾Ð±Ñ€Ð°Ð¶ÐµÐ½Ð¸Ñ
       [lastvisit] (boolean)   Ð”Ð°Ñ‚Ð° Ð¸ Ð²Ñ€ÐµÐ¼Ñ Ð¿Ð¾ÑÐ»ÐµÐ´Ð½ÐµÐ³Ð¾ Ð²Ð¸Ð·Ð¸Ñ‚Ð°
       [stshide]   (boolean)   Ð¡ÐºÑ€Ñ‹Ñ‚ÑŒ ÑÑ‚Ð°Ñ‚ÑƒÑ (ÐµÑÐ»Ð¸ ÐµÑÑ‚ÑŒ)
       [iphide]    (boolean)   Ð¡ÐºÑ€Ñ‹Ñ‚ÑŒ (Ð½Ðµ Ð¿Ð¾ÐºÐ°Ð·Ñ‹Ð²Ð°Ñ‚ÑŒ) IP Ð¸ UserAgent
       [iphist]    (boolean)   ÐŸÐ¾ÐºÐ°Ð·Ñ‹Ð²Ð°Ñ‚ÑŒ ÑÑÑ‹Ð»ÐºÑƒ Ð½Ð° Ð¸ÑÑ‚Ð¾Ñ€Ð¸ÑŽ IP

       [header]    (string)    Ð¢ÐµÐºÑÑ‚ Ð² ÑÑ‚Ñ€Ð¾ÐºÐµ Ð¿Ð¾ÑÐ»Ðµ ÐÐ¸ÐºÐ° Ð¿Ð¾Ð»ÑŒÐ·Ð¾Ð²Ð°Ñ‚ÐµÐ»Ñ
       [body]      (string)    ÐžÑÐ½Ð¾Ð²Ð½Ð¾Ð¹ Ñ‚ÐµÐºÑÑ‚, Ð¿Ð¾Ð´ Ð½Ð¸ÐºÐ¾Ð¼ Ð¿Ð¾Ð»ÑŒÐ·Ð¾Ð²Ð°Ñ‚ÐµÐ»Ñ
       [sub]       (string)    Ð¡Ñ‚Ñ€Ð¾ÐºÐ° Ð²Ñ‹Ð²Ð¾Ð´Ð¸Ñ‚ÑÑ Ð²Ð²ÐµÑ€Ñ…Ñƒ Ð¾Ð±Ð»Ð°ÑÑ‚Ð¸ "sub"
       [footer]    (string)    Ð¡Ñ‚Ñ€Ð¾ÐºÐ° Ð²Ñ‹Ð²Ð¾Ð´Ð¸Ñ‚ÑÑ Ð²Ð½Ð¸Ð·Ñƒ Ð¾Ð±Ð»Ð°ÑÑ‚Ð¸ "sub"
    -----------------------------------------------------------------
    */
    public static function display_user($user = false, $arg = false)
    {
        global $rootpath, $mod;
        $out = false;

        if (!$user['id']) {
            $out = '<b>' . self::$lng['guest'] . '</b>';
            if (!empty($user['name']))
                $out .= ': ' . $user['name'];
            if (!empty($arg['header']))
                $out .= ' ' . $arg['header'];
        } else {
            if (self::$user_set['avatar']) {
                $out .= '<table cellpadding="0" cellspacing="0"><tr><td>';
                if (file_exists(($rootpath . 'files/users/avatar/' . $user['id'] . '.png')))
                    $out .= '<img src="' . self::$system_set['homeurl'] . '/files/users/avatar/' . $user['id'] . '.png" width="32" height="32" alt="" />&#160;';
                else
                    $out .= '<img src="' . self::$system_set['homeurl'] . '/images/empty.png" width="32" height="32" alt="" />&#160;';
                $out .= '</td><td>';
            }
            if ($user['sex'])
                $out .= '<img src="' . self::$system_set['homeurl'] . '/theme/' . self::$user_set['skin'] . '/images/' . ($user['sex'] == 'm' ? 'm' : 'w') . ($user['datereg'] > time() - 86400 ? '_new' : '')
                        . '.png" width="16" height="16" align="middle" alt="' . ($user['sex'] == 'm' ? 'Ðœ' : 'Ð–') . '" />&#160;';
            else
                $out .= '<img src="' . self::$system_set['homeurl'] . '/images/del.png" width="12" height="12" align="middle" />&#160;';
            $out .= !self::$user_id || self::$user_id == $user['id'] ? '<b>' . $user['name'] . '</b>' : '<a href="' . self::$system_set['homeurl'] . '/users/profile.php?user=' . $user['id'] . '"><b>' . $user['name'] . '</b></a>';
            $rank = array(
                0 => '',
                1 => '(GMod)',
                2 => '(CMod)',
                3 => '(FMod)',
                4 => '(DMod)',
                5 => '(LMod)',
                6 => '(Smd)',
                7 => '(Adm)',
                9 => '(SV!)'
            );
            $out .= ' ' . $rank[$user['rights']];
            $out .= (time() > $user['lastdate'] + 300 ? '<span class="red"> [Off]</span>' : '<span class="green"> [ON]</span>');
            if (!empty($arg['header']))
                $out .= ' ' . $arg['header'];
            if (!isset($arg['stshide']) && !empty($user['status']))
                $out .= '<div class="status"><img src="' . self::$system_set['homeurl'] . '/theme/' . self::$user_set['skin'] . '/images/label.png" alt="" align="middle" />&#160;' . $user['status'] . '</div>';
            if (self::$user_set['avatar'])
                $out .= '</td></tr></table>';
        }
        if (isset($arg['body']))
            $out .= '<div>' . $arg['body'] . '</div>';
        $ipinf = !isset($arg['iphide']) && (self::$user_rights || ($user['id'] && $user['id'] == self::$user_id)) ? 1 : 0;
        $lastvisit = time() > $user['lastdate'] + 300 && isset($arg['lastvisit']) ? self::display_date($user['lastdate']) : false;
        if ($ipinf || $lastvisit || isset($arg['sub']) && !empty($arg['sub']) || isset($arg['footer'])) {
            $out .= '<div class="sub">';
            if (isset($arg['sub']))
                $out .= '<div>' . $arg['sub'] . '</div>';
            if ($lastvisit)
                $out .= '<div><span class="gray">' . self::$lng['last_visit'] . ':</span> ' . $lastvisit . '</div>';
            $iphist = '';
            if ($ipinf) {
                $out .= '<div><span class="gray">' . self::$lng['browser'] . ':</span> ' . $user['browser'] . '</div>' .
                        '<div><span class="gray">' . self::$lng['ip_address'] . ':</span> ';
                $hist = $mod == 'history' ? '&amp;mod=history' : '';
                $ip = long2ip($user['ip']);
                if (self::$user_rights && isset($user['ip_via_proxy']) && $user['ip_via_proxy']) {
                    $out .= '<b class="red"><a href="' . self::$system_set['homeurl'] . '/' . self::$system_set['admp'] . '/index.php?act=search_ip&amp;ip=' . $ip . $hist . '">' . $ip . '</a></b> / ';
                    $out .= '<a href="' . self::$system_set['homeurl'] . '/' . self::$system_set['admp'] . '/index.php?act=search_ip&amp;ip=' . long2ip($user['ip_via_proxy']) . $hist . '">' . long2ip($user['ip_via_proxy']) . '</a>';
                } elseif (self::$user_rights) {
                    $out .= '<a href="' . self::$system_set['homeurl'] . '/' . self::$system_set['admp'] . '/index.php?act=search_ip&amp;ip=' . $ip . $hist . '">' . $ip . '</a>';
                } else {
                    $out .= $ip . $iphist;
                }
                if (isset($arg['iphist'])) {
                    $iptotal = mysql_result(mysql_query("SELECT COUNT(*) FROM `cms_users_iphistory` WHERE `user_id` = '" . $user['id'] . "'"), 0);
                    $out .= '<div><span class="gray">' . self::$lng['ip_history'] . ':</span> <a href="' . self::$system_set['homeurl'] . '/users/profile.php?act=ip&amp;user=' . $user['id'] . '">[' . $iptotal . ']</a></div>';
                }
                $out .= '</div>';
            }
            if (isset($arg['footer']))
                $out .= $arg['footer'];
            $out .= '</div>';
        }
        return $out;
    }

    /*
    -----------------------------------------------------------------
    Ð¤Ð¾Ñ€Ð¼Ð°Ñ‚Ð¸Ñ€Ð¾Ð²Ð°Ð½Ð¸Ðµ Ð¸Ð¼ÐµÐ½Ð¸ Ñ„Ð°Ð¹Ð»Ð°
    -----------------------------------------------------------------
    */
    public static function format($name)
    {
        $f1 = strrpos($name, ".");
        $f2 = substr($name, $f1 + 1, 999);
        $fname = strtolower($f2);
        return $fname;
    }

    /*
    -----------------------------------------------------------------
    ÐŸÐ¾Ð»ÑƒÑ‡Ð°ÐµÐ¼ Ð´Ð°Ð½Ð½Ñ‹Ðµ Ð¿Ð¾Ð»ÑŒÐ·Ð¾Ð²Ð°Ñ‚ÐµÐ»Ñ
    -----------------------------------------------------------------
    */
    public static function get_user($id = false)
    {
        if ($id && $id != self::$user_id) {
            $req = mysql_query("SELECT * FROM `users` WHERE `id` = '$id'");
            if (mysql_num_rows($req)) {
                return mysql_fetch_assoc($req);
            } else {
                return false;
            }
        } else {
            return self::$user_data;
        }
    }

    /*
    -----------------------------------------------------------------
    Ð¢Ñ€Ð°Ð½ÑÐ»Ð¸Ñ‚ÐµÑ€Ð°Ñ†Ð¸Ñ Ñ Ð ÑƒÑÑÐºÐ¾Ð³Ð¾ Ð² Ð»Ð°Ñ‚Ð¸Ð½Ð¸Ñ†Ñƒ
    -----------------------------------------------------------------
    */
    public static function rus_lat($str)
    {
        $replace = array(
            'Ð°' => 'a',
            'Ð±' => 'b',
            'Ð²' => 'v',
            'Ð³' => 'g',
            'Ð´' => 'd',
            'Ðµ' => 'e',
            'Ñ‘' => 'e',
            'Ð¶' => 'j',
            'Ð·' => 'z',
            'Ð¸' => 'i',
            'Ð¹' => 'i',
            'Ðº' => 'k',
            'Ð»' => 'l',
            'Ð¼' => 'm',
            'Ð½' => 'n',
            'Ð¾' => 'o',
            'Ð¿' => 'p',
            'Ñ€' => 'r',
            'Ñ' => 's',
            'Ñ‚' => 't',
            'Ñƒ' => 'u',
            'Ñ„' => 'f',
            'Ñ…' => 'h',
            'Ñ†' => 'c',
            'Ñ‡' => 'ch',
            'Ñˆ' => 'sh',
            'Ñ‰' => 'sch',
            'ÑŠ' => "",
            'Ñ‹' => 'y',
            'ÑŒ' => "",
            'Ñ' => 'ye',
            'ÑŽ' => 'yu',
            'Ñ' => 'ya'
        );
        return strtr($str, $replace);
    }

    /*
    -----------------------------------------------------------------
    ÐžÐ±Ñ€Ð°Ð±Ð¾Ñ‚ÐºÐ° ÑÐ¼Ð°Ð¹Ð»Ð¾Ð²
    -----------------------------------------------------------------
    */
    private static $smileys_cache = array();

    public static function smileys($str, $adm = false)
    {
        global $rootpath;
        if (empty(self::$smileys_cache)) {
            $file = $rootpath . 'files/cache/smileys.dat';
            if (file_exists($file) && ($smileys = file_get_contents($file)) !== false) {
                self::$smileys_cache = unserialize($smileys);
                return strtr($str, ($adm ? array_merge(self::$smileys_cache['usr'], self::$smileys_cache['adm']) : self::$smileys_cache['usr']));
            } else {
                return $str;
            }
        } else {
            return strtr($str, ($adm ? array_merge(self::$smileys_cache['usr'], self::$smileys_cache['adm']) : self::$smileys_cache['usr']));
        }
    }

    /*
    -----------------------------------------------------------------
    Ð¤ÑƒÐ½ÐºÑ†Ð¸Ñ Ð¿ÐµÑ€ÐµÑÑ‡ÐµÑ‚Ð° Ð½Ð° Ð´Ð½Ð¸, Ð¸Ð»Ð¸ Ñ‡Ð°ÑÑ‹
    -----------------------------------------------------------------
    */
    public static function timecount($var)
    {
        global $lng;
        if ($var < 0) $var = 0;
        $day = ceil($var / 86400);
        if ($var > 345600) return $day . ' ' . $lng['timecount_days'];
        if ($var >= 172800) return $day . ' ' . $lng['timecount_days_r'];
        if ($var >= 86400) return '1 ' . $lng['timecount_day'];
        return date("G:i:s", mktime(0, 0, $var));
    }

    /*
    -----------------------------------------------------------------
    Ð¢Ñ€Ð°Ð½ÑÐ»Ð¸Ñ‚ÐµÑ€Ð°Ñ†Ð¸Ñ Ñ‚ÐµÐºÑÑ‚Ð°
    -----------------------------------------------------------------
    */
    public static function trans($str)
    {
        $replace = array(
            'a' => 'а',
            'b' => 'б',
            'v' => 'в',
            'g' => 'г',
            'd' => 'д',
            'e' => 'е',
            'yo' => 'ё',
            'zh' => 'ж',
            'z' => 'з',
            'i' => 'и',
            'j' => 'й',
            'k' => 'к',
            'l' => 'л',
            'm' => 'м',
            'n' => 'н',
            'o' => 'о',
            'p' => 'п',
            'r' => 'р',
            's' => 'с',
            't' => 'т',
            'u' => 'у',
            'f' => 'ф',
            'h' => 'х',
            'c' => 'ц',
            'ch' => 'ч',
            'w' => 'ш',
            'sh' => 'щ',
            'q' => 'ъ',
            'y' => 'ы',
            'x' => 'э',
            'yu' => 'ю',
            'ya' => 'я',
            'A' => 'А',
            'B' => 'Б',
            'V' => 'В',
            'G' => 'Г',
            'D' => 'Д',
            'E' => 'Е',
            'YO' => 'Ё',
            'ZH' => 'Ж',
            'Z' => 'З',
            'I' => 'И',
            'J' => 'Й',
            'K' => 'К',
            'L' => 'Л',
            'M' => 'М',
            'N' => 'Н',
            'O' => 'О',
            'P' => 'П',
            'R' => 'Р',
            'S' => 'С',
            'T' => 'Т',
            'U' => 'У',
            'F' => 'Ф',
            'H' => 'Х',
            'C' => 'Ц',
            'CH' => 'Ч',
            'W' => 'Ш',
            'SH' => 'Щ',
            'Q' => 'Ъ',
            'Y' => 'Ы',
            'X' => 'Э',
            'YU' => 'Ю',
            'YA' => 'Я'
        );
        return strtr($str, $replace);
    }
}