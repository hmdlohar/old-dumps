<?php $req = mysql_query("SELECT * FROM `forum` WHERE `type`='t' AND `close` != '1' ORDER BY `time` DESC LIMIT 7");
$i = 0;
while($res = mysql_fetch_array($req)) {
echo $i % 2 ? '<div class="menu">' : '<div class="menu">';
$q3 = mysql_query("SELECT `id`, `refid`, `text` FROM `forum` WHERE `type`='r' AND `id`='" . $res['refid'] . "'");
$razd = mysql_fetch_array($q3);
$q4 = mysql_query("SELECT `text` FROM `forum` WHERE `type`='f' AND `id`='" . $razd['refid'] . "'");
$frm = mysql_fetch_array($q4);
$colmes = mysql_query("SELECT * FROM `forum` WHERE `refid` = '" . $res['id'] . "' AND `type` = 'm'" . ($rights >= 7 ? '' : " AND `close` != '1'") . " ORDER BY `time` DESC");
$colmes1 = mysql_num_rows($colmes);
$cpg = ceil($colmes1 / $kmess);
$nick = mysql_fetch_array($colmes);
if ($res['edit'])
echo '<img src="images/tz.gif" alt=""/>';
elseif ($res['close'])
echo '<img src="images/dl.gif" alt=""/>';
else
echo '<img src="images/np.gif" alt=""/>';
if ($res['realid'] == 1)
echo '&#160;<img src="images/rate.gif" alt=""/>';
echo '&#160;<a href="'.$home.'/forum/index.php?id=' . $res['id'] . ($cpg > 1 && $_SESSION['uppost'] ? '&amp;clip&amp;page=' . $cpg : '') . '">' . $res['text'] .
'</a>&#160;[' . $colmes1 . ']';
if ($cpg > 1)
echo '<a href="'.$home.'/forum/index.php?id=' . $res['id'] . ($_SESSION['uppost'] ? '' : '&amp;clip&amp;page=' . $cpg) . '">&#160;&rarr;</a>';
echo '<br /><div class="sub">';
echo 'by '.$res['from'].' &#187; ';
if ($colmes1 > 1) {
echo '' . $nick['from'] . '';
}else
echo $res['from'];
echo '</div></div>';
$i;
}/*
$req = mysql_query("SELECT `id`, `text`, `soft` FROM `forum` WHERE `type`='f' ORDER BY `realid`");
$i = 0;
while (($res = mysql_fetch_array($req)) !== false) {   echo $i % 2 ? '<div class="menu">' : '<div class="menu">';
$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum` WHERE `type`='r' and `refid`='" . $res['id'] . "'"), 0);
echo '<a class="flist" href="/forum/index.php?id=' . $res['id'] . '">' . $res['text'] . '</a>';echo '</div></div>';
$i;
}*/
echo'<div align="right"><a href="/forum/index.php?act=new"><b>More..</b></a></div>';
