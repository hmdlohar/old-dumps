<?
{
global $realtime;
global $user_id;
$req = mysql_query("SELECT `qchat`.*, `users`.`name`, `users`.`rights`, `users`.`lastdate`, `users`.`sex`, `users`.`status`, `users`.`datereg`, `users`.`ip` , `users`.`browser`   FROM `qchat` LEFT JOIN `users` ON `qchat`.`user_id` = `users`.`id` ORDER BY `time` DESC LIMIT 3;");
while ($res = mysql_fetch_array($req)) {
echo ceil(ceil($i / 2) - ($i / 2)) == 0 ? '<div class="textshout" style="background: #ffffff; border-bottom: 1px solid #e9e9e9; margin: 2px 4px -1px 4px; padding: 3px 2px 2px 2px">' : '<div class="textshout" style="background: #ffffff; border-bottom: 1px solid #e9e9e9; margin: 2px 4px -1px 4px; padding: 3px 2px 2px 2px">';
global $set_user, $realtime, $user_id, $admp, $home;
$ontime = $res['lastdate'] + 300;
if (time() > $ontime) {
echo '<font color="red">&bull;</font>&nbsp;';
} else {
echo '<font color="green">&bull;</font>&nbsp;';
}
if (!empty($user_id) && ($user_id != $res['user_id'])) {
echo '<a href="../users/profile.php?user=' . $res['user_id'] . '"><b>'.$res['name'] .'</b></a>';
} else {
echo '<b>' . $res['name'] . '</b> ';
}
$ontime = $res['lastdate'] + 300;
if (time() > $ontime) {
echo ': ';
} else {
echo ': ';
}
if (!empty($res['status']))
$text = htmlentities($res['text'], ENT_QUOTES, 'UTF-8');
$text = bbcode::tags($text);
$text = str_replace("\r\n", "<br />", $text);
if ($res['user_id']) {
$text = functions::checkout(mb_substr($res['text'], 0, 100), 1, 1);
if ($set_user['smileys'])
$text = functions::smileys($text, $res['rights'] >= 1 ? 1 : 0);
}
echo $text;
if (mb_strlen($res['text']) > 100)
echo '...<a href="../pages/qchat.php">more</a>';
echo '</div>';
++$i;
}
}

?>
