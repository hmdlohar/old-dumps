<?
$user_u = $res['user_id'];
$req_u = mysql_query("SELECT * FROM `users` WHERE `id` = '$user_u' LIMIT 1");
$res_u = mysql_fetch_array($req_u);
$exp = $res_u['postforum'] + $res_u['postguest'] + $res_u['komm'];
if ($res_u['rights']<9){
if ($exp>=0 && $exp<=15)
echo ' <img src = "../images/stars/0.gif" height="' . $height . '" /> ';
if ($exp>=15 && $exp<=25)
echo ' <img src = "../images/stars/.5.gif" height="' . $height . '" /> ';
if ($exp>=25 && $exp<=50)
echo ' <img src = "../images/stars/1.gif" height="' . $height . '" /> ';
if ($exp>=50 && $exp<=80)
echo ' <img src = "../images/stars/2.gif" height="' . $height . '" /> ';
if ($exp>=80 && $exp<=100)
echo ' <img src = "../images/stars/3.gif" height="' . $height . '" /> ';
if ($exp>=100 && $exp<=150)
echo ' <img src = "../images/stars/4.gif" height="' . $height . '" /> ';
if ($exp>=150 && $exp<=200)
echo ' <img src = "../images/stars/5.gif" height="' . $height . '" /> ';
if ($exp>=250 && $exp<=300)
echo ' <img src = "../images/stars/6.gif" height="' . $height . '" /> ';
if ($exp>=300 && $exp<=400)
echo ' <img src = "../images/stars/7.gif" height="' . $height . '" /> ';
if ($exp>=400 && $exp<=500)
echo ' <img src = "../images/stars/8.gif" height="' . $height . '" /> ';
if ($exp>=500 && $exp<=1000)
echo ' <img src = "../images/stars/9.gif" height="' . $height . '" /> ';
if ($exp>=1000 && $exp<=5000)
echo ' <img src = "../images/stars/10.gif" height="' . $height . '" /> ';
if ($exp>100000)
echo ' <img src = "../images/stars/10.gif" height="' . $height . '" /> ';

}else
echo ' <img src = "../images/stars/9.gif" height="' . $height . '" /> ';
?>
