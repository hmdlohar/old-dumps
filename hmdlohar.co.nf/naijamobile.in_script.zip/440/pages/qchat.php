<?php
define('_IN_JOHNCMS', 1);
$headmod = 'quickchat';
require_once ("../incfiles/core.php");
$set_user['avatar'] = 1; //set avatar 0 -> Off, 1 -> On
// Set Page Headers
$textl = $lng['quickchat'];
require_once ("../incfiles/head.php");
/**/
if (empty($user_id) || $ban['1'] || $ban['12']){
header('Location: ' . $homeurl .'/?err');
exit;
}
$act = isset($_GET['act']) ? $_GET['act'] : '';
switch ($act){
case "del":
// Deleting a single post
if (($rights==2 || $rights >= 6) && $id){
if (isset($_GET['yes'])){
mysql_query("DELETE FROM `qchat` WHERE `id`='" . $id . "' LIMIT 1 ");
header("Location: qchat.php");
}else{
echo '<div class="mainblok"><div class="phdr"><a href="?">Quick Chat</a> | ' . $lng['delete_message'] . '</div>';
echo '<div class="rmenu">Are you sure want to delete?<br /><a href="?act=del&amp;id='.$id.'&amp;yes">Yes</a> | <a href="?">No</a></div></div>';
}
}else{
echo functions::display_error('' . $lng['error_edit_rights'] . '');
}
break;

case "trans":
// Translate
include ("../pages/trans.$ras_pages");
echo '&gt;<a href="' . htmlspecialchars(getenv("HTTP_REFERER")) . '">' . $lng['back'] . '</a><br />';
break;

case "say":
// Adding a new post
if (!$user_id || $ban['12'] || $ban['1']){
echo functions::display_error('' . $lng['error_address'] . '<br /><a href="' . htmlspecialchars(getenv("HTTP_REFERER")) . '">' . $lng['back'] . '</a>');
require_once ('../incfiles/end.php');
exit;
}

if (isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER']!=NULL){
$balek=$_SERVER['HTTP_REFERER'];
} elseif (ereg("&pass=", $_SERVER['HTTP_REFERER'])){
$balek='/index.php';
} else {
$balek='qchat.php';
}

if (empty($user_id)){
echo '' . $lng['error'] . '<br />&gt;<a href="qchat.php?">' . $lng['back'] . '</a><br />';
require_once ('../incfiles/end.php');
exit;
}

if (isset($_POST['submit'])){
if (empty($_POST['msg'])){
echo functions::display_error('' . $lng['error_empty_text'] . '<br /><a href="'.$balek.'">' . $lng['back'] . '</a><br />');
require_once ("../incfiles/end.php");
exit;
}

//antiflood
$flood = functions::antiflood();
if ($flood) {
echo functions::display_error($lng['error_flood'] . ' ' . $flood . ' '.$lng['sec']. '<br/><a href="' . $_SERVER['HTTP_REFERER'] . '?' . $_SERVER['QUERY_STRING'] . '">' . $lng['back'] . '</a>');
require('../incfiles/end.php');
exit;
}
// anti spam, cek pada frekuensi menambahkan pesan
$msg = trim($_POST['msg']);
$msg = mb_substr($msg, 0, 300);
if ($_POST['msgtrans'] == 1)	{
$msg = functions::trans($msg);
}

// masukan pesan ke dalam database
mysql_query("INSERT INTO `qchat` SET
`time`='" . time() . "',
`user_id`='" . $user_id . "',
`text`='" . mysql_real_escape_string($msg) . "';");

// memperbaiki posting terakhir (antispam)
mysql_query("UPDATE `users` SET `lastpost` = '" . time() . "' WHERE `id` = '" . $user_id . "'");
header("location: $balek");
} else {
echo '<form action="qchat.php?act=say" method="post">';
echo 'Max 250 character<br /><textarea cols="21" rows="4" name="msg"></textarea><br />';
if ($offtr != 1){
echo '<input type="checkbox" name="msgtrans" value="1" /> Translate<br />';
}
echo '<input type="submit" title="Click to post" name="submit" value="Post"/><br /></form>';
echo '&gt;<a href="'.$balek.'">' . $lng['back'] . '</a><br />';
}

break;

case 'clean':
// Cleaning quick chat
if ($rights>=7){
if (isset($_POST['submit'])){
$cl = isset($_POST['cl']) ? intval($_POST['cl']) : '';
switch ($cl){
case '1':
// Clean messages older than 1 day
mysql_query("DELETE FROM `qchat` WHERE `time`<='" . (time() - 86400) . "';");
mysql_query("OPTIMIZE TABLE `qchat`;");
echo '<p>' . $lng['clear_day_ok'] . '<br /><a href="?">' . $lng['back'] . '</a></p>';
break;
case '2':
// delete all
mysql_query("DELETE FROM `qchat`;");
mysql_query("OPTIMIZE TABLE `qchat`;");
echo '<p>' . $lng['clear_full_ok'] . '<br /><a href="?">' . $lng['back'] . '</a></p>';
break;
default:
// Clean messages older than 1 week
mysql_query("DELETE FROM `qchat` WHERE `time`<='" . (time() - 604800) . "';");
mysql_query("OPTIMIZE TABLE `qchat`;");
echo '<p>' . $lng['clear_week_ok'] . '<br /><a href="?">' . $lng['back'] . '</a></p>';
}
}else{
echo '<div class="mainblok"><div class="phdr"><a href="?">Quick Chat</a> | ' . $lng['delete_message'] . '</div>';
echo '<div class="rmenu"><form id="clean" method="post" action="?act=clean">';
echo '<input type="radio" name="cl" value="0" checked="checked" />' . $lng['clear_param_week'] . '<br />';
echo '<input type="radio" name="cl" value="1" />' . $lng['clear_param_day'] . '<br />';
echo '<input type="radio" name="cl" value="2" />' . $lng['clear_param_all'] . '<br />';
echo '<input type="submit" name="submit" value="' . $lng['delete'] . '" />';
echo '</form></div></div>';
}
}else{
header("location: qchat.php");
}
break;
default:
// display Quick chat
// bentuk input pesan baru
if ($user_id || $ban['1'] || $ban['12']){
echo '<div class="mainblok"><div class="phdr"><a name="down" id="down"></a><a href="#down">' .
'<img src="../theme/' . $set_user['skin'] . '/images/down.png" alt="' . $lng['down'] . '" width="20" height="10" border="0"/></a> <b>Quickchat</b></div>';
echo '<div
class="sbox"><b>Message</b><small> (max. 100 character)</small><br/><form name="form" action="qchat.php?act=say" method="post">';
echo bbcode::auto_bb('form', 'msg');
echo '<textarea class="textareks" name="msg"></textarea><br/>'; echo "<input type='submit' title='Click to post' name='submit' value='Send'/>";
echo "</form></div></div>"; } $req = mysql_query("SELECT COUNT(*) FROM `qchat`"); $colmes = mysql_result($req, 0); // jumlah pesan
//echo '<div class="mainblok"><div class="topmenu">' . functions::display_pagination('qchat.php?', $start, $colmes, $kmess) . '</div></div>';
if ($colmes > 0){
$req = mysql_query("SELECT `qchat`.*, `users`.`name`, `users`.`rights`, `users`.`lastdate`, `users`.`sex`, `users`.`status`, `users`.`datereg`, `users`.`ip` , `users`.`browser` , `users`.`rights`  FROM `qchat` LEFT JOIN `users` ON `qchat`.`user_id` = `users`.`id` ORDER BY `time` DESC LIMIT " . $start . "," . $kmess . ";"); echo '<div class="mainblok"><div class="topmenu">' . functions::display_pagination('qchat.php?', $start, $colmes, $kmess) . '</div></div>';
while ($res = mysql_fetch_array($req)){
echo ($i % 2) ? '<div class="mainblok">' : '<div class="mainblok">';
//set avatar
global $set_user, $realtime, $user_id, $admp, $home;
if ($set_user['avatar']){
echo '<div
class="phdr"><table
width="100%" cellpadding="0"
cellspacing="0"><tbody><tr><td
width="auto"><img src="../images/file.png"/> '; $vrp = $res['time'] + $sdvig * 3600;
$vr = date(" d.m.y - H:i", $vrp);
echo ''. $vr .'</td></tr></tbody></table></div><table
class="newsx" width="100%" cellpadding="1" cellspacing="0"><tr><td width="32">';
if (file_exists(('../files/users/avatar/' . $res['user_id'] . '.png')))
echo '<img src="../files/users/avatar/' . $res['user_id'] . '.png"/> ';
else
echo '<img src="../images/empty.png" /> ';
echo '</td><td width="auto" align="left"
valign="top">';
} // nick dan link ke profil
if (!empty($user_id) && ($user_id != $res['user_id'])){
//$name_lat = mysql_result (mysql_query ("SELECT `name_lat` FROM `users` WHERE `id` = '" .$res['user_id']. "' LIMIT 1;"), 0);
echo '<a href="../users/profile.php?user=' . $res['user_id'] . '"><b>'.$res['name'] .'</b></a>';
} else{
echo '<b>' . $res['name'] .'</b> '; } $ontime = $res['lastdate'] + 300;
if (time() > $ontime){
echo ' <font color="red">&bull;</font><br/>';
}else{ echo ' <font color="green">&bull;</font><br/>'; }
$user_rights = array (
0 => 'Newbie',
1 => 'Newbie',
2 => 'Activist',
3 => 'Staff',
6 => 'Moderator',
7 => 'Pro Admin',
9 => '<font color="red">Adminstrator</font>'
);
echo $user_rights[$res['rights']];
echo '</td></tr></table><div class="textshout">';
if ($res['user_id']) { // A??peAc??o??? ????e?cc?? ?c???
$text = functions::checkout($res['text'], 1, 1);
if ($set_user['smileys'])
$text = functions::smileys($text, $res['rights'] >= 1 ? 1 : 0); } else {
// A?Ac??o@a@??e???????ye?cc??
$res['name'] = functions::checkout($res['name']);
$text = functions::antilink(functions::checkout($res['text'], 0, 2)); }
// Tampilkan text posting
echo $text;
// link ke pungsi moderskie
if ($rights>=6 || $user_id == $user['id']){ echo '<br/>
<a href="qchat.php?act=del&amp;id=' . $res['id'] . '">' . $lng['delete'] . '</a><br />';
}
echo '</div></div>';
++$i;
}
echo "<div class='mainblok'><div class='phdr'>" . $lng['total'] . ": $colmes</div>";
if ($colmes > $kmess){
echo '<div class="topmenu">' . functions::display_pagination('qchat.php?', $start, $colmes, $kmess) . '</div>';
echo '<form action="qchat.php" method="get"><input type="text" name="page" size="2"/><input type="submit" value="' . $lng['to_page'] . '"/><br /></form>';
} echo '</div>';
// untuk admin menyediakan link untuk pembersihan
if ($rights>=7)
echo '<div class="rmenu"><a href="?act=clean">' . $lng['delete_message'] . '</a></div>';
}else{
echo '<div class="list1">Empty</div>';
}
break;
}
require_once ("../incfiles/end.php");
?>
