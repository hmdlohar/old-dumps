<?
defined('_IN_JOHNCMS') or die('Error: restricted access');
$mp = new mainpage();  if (($user_id) && !$ban['1'] && !$ban['12']){
echo '<div class="mainblok"><div class="phdr"><b>Shoutbox</b></div>'; echo '<div class="sbox"><form action="../pages/qchat.php?act=say" method="post">'; echo '<input type="text" cols="15" rows="2" name="msg"/>'; echo "<br/><input type='submit' title='mengirim pesan' name='submit' value='Shout'/></form></div>";  require_once ($rootpath . 'incfiles/func_quick.php'); echo '<div class="none" align="center"><a href="/pages/faq.php?act=tags">bbcodes</a> | <a href="/pages/faq.php?act=smileys">smiles</a> | <a href="/pages/qchat.php">shoutbox</a></div></div>'; }
echo '<div class="mainblok"><div class="phdr"><b>Main menu</b></div>';
echo $mp->news;
echo '<div class="none"><table width="100%" border="0" cellspacing="0" cellpadding="2"><tr><td width="55px" align="center">
<img src="images/logox.png"/></td><td align="left" width="auto"><p class="func"> <a href="news/index.php">'. $lng['news_archive'] .'</a></p><p class="func"> <a href="guestbook/index.php">' . $lng['guestbook'] . '</a> (' . counters::guestbook() . ')</p><p class="func"> <a href="users/index.php">Members</a> (' . counters::users() . ')</p><p class="func"> <a href="download/">Downloads</a> (' . counters::downloads() . ')</p><p class="func"> <a href="forum/">' . $lng['forum'] . '</a> (' . counters::forum() . ')</p></td></tr></table></div></div>';
echo '<div class="mainblok"><div class="phdr"><b>Latest forum post</b></div>';
require('incfiles/new.php');
echo '</div><div
class="mainblok"><div
class="phdr"><b>Friends site & More</b></div><div
class="menu"><img src="/images/nsite.gif" width="14"
height="14"/> <a
href="pages/friendssite.php">Friends site..</a></div><div
class="menu"><img src="/images/album.png" width="14"
height="14"/> <a
href="users/album.php">'. $lng['photo_album'] .'</a> (' . counters::album() . ')</div><div
class="menu"><img src="/images/emil.gif" width="14"
height="14"/> <a href="/mail">Mail Service</a></div><div
class="menu"><img src="/images/host.png" width="14"
height="14"/> <a href="http://naijahost.tk">Free WebHost</a></div><div
class="menu"><img src="/images/lock.png" width="14"
height="14"/> <a href="http://blueftp.tk">Wap Ftp Service</a></div></div>';
?>
