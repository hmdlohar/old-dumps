<?php
include('social_bookmarking.php');
// example of use
echo "Share This ON<br />";
echo digg();
echo facebook();
echo twitter();
echo delicious();
?>