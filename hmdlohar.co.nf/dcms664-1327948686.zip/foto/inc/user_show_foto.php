<?
if (!isset($user) && !isset($_GET['id_user'])){header("Location: /foto/?".SID);exit;}
if (isset($user))$ank['id']=$user['id'];
if (isset($_GET['id_user']))$ank['id']=$_GET['id_user'];

$ank=get_user($ank['id']);
if (!$ank){header("Location: /foto/?".SID);exit;}


$gallery['id']=intval($_GET['id_gallery']);

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery` WHERE `id` = '$gallery[id]' AND `id_user` = '$ank[id]' LIMIT 1"),0)==0){header("Location: /foto/$ank[id]/?".SID);exit;}
$gallery=mysql_fetch_assoc(mysql_query("SELECT * FROM `gallery` WHERE `id` = '$gallery[id]' AND `id_user` = '$ank[id]' LIMIT 1"));

$foto['id']=intval($_GET['id_foto']);

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_foto` WHERE `id` = '$foto[id]' LIMIT 1"),0)==0){header("Location: /foto/$ank[id]/$gallery[id]/?".SID);exit;}
$foto=mysql_fetch_assoc(mysql_query("SELECT * FROM `gallery_foto` WHERE `id` = '$foto[id]'  LIMIT 1"));

$set['title']=$ank['nick'].' - '.$gallery['name'].' - '.$foto['name']; // заголовок страницы

include_once '../sys/inc/thead.php';
title();
if (user_access('foto_foto_edit') && $ank['level']>$user['level'] || isset($user) && $ank['id']==$user['id'])
include 'inc/gallery_show_foto_act.php';





if (isset($user) && $user['id']!=$ank['id'] && $user['balls']>=50 && $user['rating']>=0 && mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_rating` WHERE `id_user` = '$user[id]' AND `id_foto` = '$foto[id]'"), 0)==0)
{
if (isset($_GET['rating']) && $_GET['rating']=='down'){
mysql_query("UPDATE `gallery_foto` SET `rating` = '".($foto['rating']-1)."' WHERE `id` = '$foto[id]' LIMIT 1",$db);
mysql_query("INSERT INTO `gallery_rating` (`id_user`, `id_foto`) values('$user[id]', '$foto[id]')",$db);
msg ('Your negative opinion adopted');$foto=mysql_fetch_assoc(mysql_query("SELECT * FROM `gallery_foto` WHERE `id` = $foto[id] LIMIT 1"));}
elseif(isset($_GET['rating']) && $_GET['rating']=='up'){
mysql_query("UPDATE `gallery_foto` SET `rating` = '".($foto['rating']+1)."' WHERE `id` = '$foto[id]' LIMIT 1",$db);
mysql_query("INSERT INTO `gallery_rating` (`id_user`, `id_foto`) values('$user[id]', '$foto[id]')",$db);
msg ('Your positive feedback received');$foto=mysql_fetch_assoc(mysql_query("SELECT * FROM `gallery_foto` WHERE `id` = $foto[id] LIMIT 1"));}
}



err();
aut();

echo "<div style='text-align: center;'>\n";


if ($set['web'])
{
echo "<img class='show_foto' src='/foto/foto640/$foto[id].$foto[ras]' alt='$foto[name]' /><br />\n";
}
else
{
echo "<img class='show_foto' src='/foto/foto128/$foto[id].$foto[ras]' alt='$foto[name]' /><br />\n";
}



if ($foto['opis']!=null)
echo esc(trim(br(bbcode(smiles(links(stripcslashes(htmlspecialchars($foto['opis']))))))))."<br />\n";
echo "</div>\n";
echo "<a href='/foto/foto0/$foto[id].$foto[ras]' title='Download'>";
echo "Download original";
echo " (".size_file(filesize(H.'sys/gallery/foto/'.$foto['id'].'.jpg')).")";
echo "</a><br />\n";

echo "<span class=\"ank_n\">Rating:</span> ";
if (isset($user) && $user['id']!=$ank['id'] && $user['balls']>=50 && $user['rating']>=0 && mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_rating` WHERE `id_user` = '$user[id]' AND `id_foto` = '$foto[id]'"), 0)==0)
echo "[<a href=\"?id=$foto[id]&amp;rating=down\" title=\"To give a negative vote\">-</a>] ";
echo "<span class=\"ank_d\">$foto[rating]</span>";
if (isset($user) && $user['id']!=$ank['id'] && $user['balls']>=50 && $user['rating']>=0 && mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_rating` WHERE `id_user` = '$user[id]' AND `id_foto` = '$foto[id]'"), 0)==0)
echo " [<a href=\"?id=$foto[id]&amp;rating=up\" title=\"To give a postive vote\">+</a>]";
echo "<br />\n";

if (user_access('foto_foto_edit') && $ank['level']>$user['level'] || isset($user) && $ank['id']==$user['id'])
include 'inc/gallery_show_foto_form.php';


echo "<div class=\"foot\">\n";
echo "&raquo;<a href='/foto/$ank[id]/$gallery[id]/komm/$foto[id]/'>Comments (".mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_komm` WHERE `id_foto` = '$foto[id]'"),0).")</a><br />\n";
echo "&laquo;<a href='/foto/$ank[id]/$gallery[id]/'>$gallery[name]</a><br />\n";
echo "&laquo;<a href='/foto/$ank[id]/'>Photo Albums</a><br />\n";

echo "</div>\n";
include_once '../sys/inc/tfoot.php';
exit;
?>