<?
if (!isset($user) && !isset($_GET['id_user'])){header("Location: /foto/?".SID);exit;}
if (isset($user))$ank['id']=$user['id'];
if (isset($_GET['id_user']))$ank['id']=intval($_GET['id_user']);
$ank=get_user($ank['id']);
if (!$ank){header("Location: /foto/?".SID);exit;}
$gallery['id']=intval($_GET['id_gallery']);

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery` WHERE `id` = '$gallery[id]' AND `id_user` = '$ank[id]' LIMIT 1"),0)==0){header("Location: /foto/$ank[id]/?".SID);exit;}
$gallery=mysql_fetch_assoc(mysql_query("SELECT * FROM `gallery` WHERE `id` = '$gallery[id]' AND `id_user` = '$ank[id]' LIMIT 1"));



$set['title']=$ank['nick'].' - '.$gallery['name'].' - Gallery'; // заголовок страницы

include_once '../sys/inc/thead.php';
title();

include 'inc/gallery_show_act.php';
err();
aut();


$k_post=mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_foto` WHERE `id_gallery` = '$gallery[id]'"),0);
$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];
echo "<table class='post'>\n";
if ($k_post==0)
{
echo "   <tr>\n";
echo "  <td class='p_t'>\n";
echo "Most empty\n";
echo "  </td>\n";
echo "   </tr>\n";

}

$q=mysql_query("SELECT * FROM `gallery_foto` WHERE `id_gallery` = '$gallery[id]' ORDER BY `id` DESC LIMIT $start, $set[p_str]");
while ($post = mysql_fetch_assoc($q))
{

echo "   <tr>\n";
if ($set['set_show_icon']==2){
echo "  <td class='icon48' rowspan='2'>\n";
echo "<img src='/foto/foto48/$post[id].$post[ras]' alt='Photo_$post[id]' />";
echo "  </td>\n";
}
elseif ($set['set_show_icon']==1)
{
echo "  <td class='icon14'>\n";
echo "<img src='/style/themes/$set[set_them]/user/$ank[pol].png' alt='' />";
echo "  </td>\n";
}

echo "  <td class='p_t'>\n";
echo "<a href='/foto/$ank[id]/$gallery[id]/$post[id]/'>$post[name]</a>\n";


echo "  </td>\n";
echo "   </tr>\n";
echo "   <tr>\n";
if ($set['set_show_icon']==1)echo "  <td class='p_m' colspan='2'>\n"; else echo "  <td class='p_m'>\n";
if ($post['opis']==null)
echo "No descriptions<br />\n";
else 
echo esc(trim(br(bbcode(smiles(links(stripcslashes(htmlspecialchars($post['opis']))))))))."<br />\n";
echo "<span class=\"ank_n\">Rating:</span> <span class=\"ank_d\">$post[rating]</span><br />\n";
echo "<a href='/foto/$ank[id]/$gallery[id]/komm/$post[id]/'>Comments (".mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_komm` WHERE `id_foto` = '$post[id]'"),0).")</a><br />\n";

echo "  </td>\n";
echo "   </tr>\n";

}
echo "</table>\n";




if ($k_page>1)str('?',$k_page,$page); // Вывод страниц


include 'inc/gallery_show_form.php';


echo "<div class=\"foot\">\n";
echo "&laquo;<a href='/foto/$ank[id]/'>$gallery[name]</a><br />\n";
echo "</div>\n";
include_once '../sys/inc/tfoot.php';
exit;
?>