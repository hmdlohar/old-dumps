<?
$set['title']='Forum - '.$forum['name'].' - '.$razdel['name'].' - New Topic'; // заголовок страницы
include_once '../sys/inc/thead.php';
title();

if (isset($_POST['name']) && isset($_POST['msg']))
{

if (isset($_SESSION['time_c_t_forum']) && $_SESSION['time_c_t_forum']>$time-600 && $user['level']==0)$err='No so much to create topics';

$name=esc(stripcslashes(htmlspecialchars($_POST['name'])));
if (isset($_POST['translit1']) && $_POST['translit1']==1)$name=translit($name);
//if (ereg("\{|\}|\^|\%|\\$|#|@|!|\~|'|\"|`|<|>",$name))$err='В названии темы присутствуют запрещенные символы';
if (strlen2($name)<3)$err[]='Short name for topic';
if (strlen2($name)>32)$err[]='Title of topic max. 32 characters';
$mat=antimat($name);
if ($mat)$err[]='Contains mat: '.$mat;


$name=my_esc($name);


$msg=$_POST['msg'];
if (isset($_POST['translit2']) && $_POST['translit2']==1)$msg=translit($msg);
if (strlen2($msg)<10)$err[]='Message too short, min. 10 characters';
if (strlen2($msg)>1024)$err[]='Length of the message exceeds the limits of 1024 characters';

$mat=antimat($msg);
if ($mat)$err[]='In the message body found mat: '.$mat;

$msg=my_esc($msg);

if (!isset($err))
{
$_SESSION['time_c_t_forum']=$time;
mysql_query("INSERT INTO `forum_t` (`id_forum`, `id_razdel`, `time_create`, `id_user`, `name`, `time`) values('$forum[id]', '$razdel[id]', '$time', '$user[id]', '$name', '$time')");
$them['id']=mysql_insert_id();
mysql_query("INSERT INTO `forum_p` (`id_forum`, `id_razdel`, `id_them`, `id_user`, `msg`, `time`) values('$forum[id]', '$razdel[id]', '$them[id]', '$user[id]', '$msg', '$time')");
mysql_query("UPDATE `forum_r` SET `time` = '$time' WHERE `id` = '$razdel[id]' LIMIT 1");
msg('Topics successfullt created');
aut();


echo "<div class='menu'>\n";
echo "<a href=\"/forum/$forum[id]/$razdel[id]/$them[id]/\" title='Back'>Back to Topics</a><br />\n";
echo "<a href=\"/forum/$forum[id]/$razdel[id]/\" title='Section'>Back</a><br />\n";
echo "<a href=\"/forum/$forum[id]/\">$forum[name]</a><br />\n";
echo "<a href=\"/forum/\">Forum</a><br />\n";
echo "</div>\n";
include_once '../sys/inc/tfoot.php';
}
}

err();
aut();








echo "<form method=\"post\" action=\"/forum/$forum[id]/$razdel[id]/?act=new\">";
echo "Topic Name:<br />\n";
echo "<input name=\"name\" type=\"text\" maxlength='32' value='' /><br />\n";
if ($user['set_translit']==1)echo "<label><input type=\"checkbox\" name=\"translit1\" value=\"1\" /> Translit</label><br />\n";
echo "Message:<br />\n";
echo "<textarea name=\"msg\"></textarea><br />\n";
if ($user['set_translit']==1)echo "<label><input type=\"checkbox\" name=\"translit2\" value=\"1\" /> Translit</label><br />\n";
echo "<input value=\"Создать\" type=\"submit\" /><br />\n";
echo "</form>\n";

echo "<div class=\"foot\">\n";
echo "<a href=\"/forum/$forum[id]/$razdel[id]/\" title='Section'>Back</a><br />\n";
echo "<a href=\"/forum/$forum[id]/\">$forum[name]</a><br />\n";
echo "<a href=\"/forum/\">Forum</a><br />\n";
echo "</div>\n";
?>