<?
if (isset($_GET['act']) && isset($_GET['ok']) && $_GET['act']=='set' && isset($_POST['name']))
{

$name=esc(stripcslashes(htmlspecialchars($_POST['name'])));
if (isset($_POST['translit1']) && $_POST['translit1']==1)$name=translit($name);
if (strlen2($name)<3)$err='Min. 3 characters';
if (strlen2($name)>32)$err='Max. 32 characters';
$name=my_esc($name);


if (!isset($err)){

admin_log('Forum','Categories',"Rename list '$razd[name]' in '$name'");

mysql_query("UPDATE `forum_r` SET `name` = '$name' WHERE `id` = '$razdel[id]' LIMIT 1");
$razdel=mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_r` WHERE `id` = '$razdel[id]' LIMIT 1"));
msg('Change have successfully taken');
}
}

if (isset($_GET['act']) && isset($_GET['ok']) && $_GET['act']=='mesto' && isset($_POST['forum']) && is_numeric($_POST['forum'])
&& mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_f` WHERE `id` = '".intval($_POST['forum'])."'"),0)==1)
{
$forum_new['id']=intval($_POST['forum']);
$forum_old=$forum;
mysql_query("UPDATE `forum_p` SET `id_forum` = '$forum_new[id]' WHERE `id_forum` = '$forum[id]' AND `id_razdel` = '$razdel[id]'");
mysql_query("UPDATE `forum_t` SET `id_forum` = '$forum_new[id]' WHERE `id_forum` = '$forum[id]' AND `id_razdel` = '$razdel[id]'");
mysql_query("UPDATE `forum_r` SET `id_forum` = '$forum_new[id]' WHERE `id_forum` = '$forum[id]' AND `id` = '$razdel[id]'");


$forum=mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_f` WHERE `id` = '$forum_new[id]' LIMIT 1"));


admin_log('Forum','Categories',"Transfer section '$razd[name]' from subforums '$forum_old[name]' в '$forum[name]'");

msg('Sections successfully moved');

}

if (isset($_GET['act']) && isset($_GET['ok']) && $_GET['act']=='delete')
{

mysql_query("DELETE FROM `forum_r` WHERE `id` = '$razdel[id]'");
mysql_query("DELETE FROM `forum_t` WHERE `id_razdel` = '$razdel[id]'");
mysql_query("DELETE FROM `forum_p` WHERE `id_razdel` = '$razdel[id]'");
admin_log('Форум','Разделы',"Удаление раздела '$razd[name]' из подфорума '$forum[name]'");
msg('Раздел успешно удален');
err();
aut();
echo "<a href=\"/forum/$forum[id]/\">Sub Forums</a><br />\n";
echo "<a href=\"/forum/\">Forum</a><br />\n";
include_once '../sys/inc/tfoot.php';
}
?>