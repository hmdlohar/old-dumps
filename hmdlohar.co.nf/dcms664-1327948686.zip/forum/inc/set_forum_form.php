<?





if (user_access('forum_razd_create') && (isset($_GET['act']) && $_GET['act']=='new' || !isset($_GET['act']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_r` WHERE `id_forum` = '$forum[id]'"),0)==0))

{

echo "<form method=\"post\" action=\"/forum/$forum[id]/?act=new&amp;ok\">\n";

echo "Title:<br />\n";

echo "<input name=\"name\" type=\"text\" maxlength='32' value='' /><br />\n";

if ($user['set_translit']==1)echo "<label><input type=\"checkbox\" name=\"translit1\" value=\"1\" /> Translit</label><br />\n";

echo "<input value=\"Create\" type=\"submit\" /><br />\n";

echo "&laquo;<a href=\"/forum/$forum[id]/\">Cancel</a><br />\n";

echo "</form>\n";

}





if (user_access('forum_for_edit') && (isset($_GET['act']) && $_GET['act']=='set'))

{

echo "<form method=\"post\" action=\"/forum/$forum[id]/?act=set&amp;ok\">\n";

echo "Forum Name:<br />\n";

echo "<input name=\"name\" type=\"text\" maxlength='32' value='$forum[name]' /><br />\n";

if ($user['set_translit']==1)echo "<label><input type=\"checkbox\" name=\"translit1\" value=\"1\" /> Translit</label><br />\n";

echo "Description:<br />\n";

echo "<textarea name=\"opis\">".esc(trim(stripcslashes(htmlspecialchars($forum['opis']))))."</textarea><br />\n";

if ($user['set_translit']==1)echo "<label><input type=\"checkbox\" name=\"translit2\" value=\"1\" /> Translit</label><br />\n";

echo "Position:<br />\n";

echo "<input name=\"pos\" type=\"text\" maxlength='3' value='$forum[pos]' /><br />\n";



if ($user['level']>=3){

if ($forum['adm']==1)$check=' checked="checked"';else $check=NULL;

echo "<label><input type=\"checkbox\"$check name=\"adm\" value=\"1\" /> For admin only</label><br />\n";

}



echo "<input value=\"Edit\" type=\"submit\" /><br />\n";

echo "&laquo;<a href=\"/forum/$forum[id]/\">Cancel</a><br />\n";

echo "</form>\n";

}



if (isset($_GET['act']) && $_GET['act']=='del' && user_access('forum_for_delete'))

{

echo "<div class=\"err\">\n";

echo "Confirm removal forum<br />\n";

echo "<a href=\"/forum/$forum[id]/?act=delete&amp;ok\">Yes</a> | <a href=\"/forum/$forum[id]/\">No</a><br />\n";

echo "</div>\n";

}



if (user_access('forum_razd_create') || user_access('forum_for_edit') || user_access('forum_for_delete'))

{

echo "<div class=\"foot\">\n";



if(user_access('forum_razd_create'))

echo "&raquo;<a href=\"/forum/$forum[id]/?act=new\">New Section</a><br />\n";



if(user_access('forum_for_edit'))

echo "&raquo;<a href=\"/forum/$forum[id]/?act=set\">Forum Option</a><br />\n";



if(user_access('forum_for_delete'))

echo "&raquo;<a href=\"/forum/$forum[id]/?act=del\">Remove Forum</a><br />\n";



echo "</div>\n";

}



?>