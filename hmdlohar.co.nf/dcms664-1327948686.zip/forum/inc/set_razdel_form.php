<?
if (isset($_GET['act']) && $_GET['act']=='mesto')
{
echo "<form method=\"post\" action=\"/forum/$forum[id]/$razdel[id]/?act=mesto&amp;ok\">\n";
echo "Childboard:<br />\n";

echo "<select name=\"forum\">\n";
$q2 = mysql_query("SELECT * FROM `forum_f` ORDER BY `pos` ASC");
while ($forums = mysql_fetch_assoc($q2))
{
if ($forum['id']==$forums['id'])$check=' selected="selected"';else $check=NULL;
echo "<option$check value=\"$forums[id]\">$forums[name]</option>\n";
}
echo "</select><br />\n";

echo "<input value=\"Move\" type=\"submit\" /><br />\n";
echo "&laquo;<a href='/forum/$forum[id]/$razdel[id]/'>Cancel</a><br />\n";
echo "</form>\n";
}

if (isset($_GET['act']) && $_GET['act']=='set')
{
echo "<form method=\"post\" action=\"/forum/$forum[id]/$razdel[id]/?act=set&amp;ok\">\n";
echo "Title section:<br />\n";
echo "<input name='name' type='text' maxlength='32' value='$razdel[name]' /><br />\n";
if ($user['set_translit']==1)echo "<label><input type=\"checkbox\" name=\"translit1\" value=\"1\" /> Translit</label><br />\n";
echo "<input value=\"Edit\" type=\"submit\" /><br />\n";
echo "&laquo;<a href='/forum/$forum[id]/$razdel[id]/'>Cancel</a><br />\n";
echo "</form>\n";
}

if (isset($_GET['act']) && $_GET['act']=='del')
{
echo "<div class=\"err\">\n";
echo "Confirm to delete section<br />\n";
echo "<a href=\"/forum/$forum[id]/$razdel[id]/?act=delete&amp;ok\">Yes</a> | <a href=\"/forum/$forum[id]/$razdel[id]/\">No</a><br />\n";
echo "</div>\n";
}


echo "<div class=\"foot\">\n";
echo "&raquo;<a href='/forum/$forum[id]/$razdel[id]/?act=mesto'>Move</a><br />\n";
echo "&raquo;<a href='/forum/$forum[id]/$razdel[id]/?act=del'>Delete</a><br />\n";
echo "&raquo;<a href='/forum/$forum[id]/$razdel[id]/?act=set'>Option</a><br />\n";
echo "</div>\n";

?>