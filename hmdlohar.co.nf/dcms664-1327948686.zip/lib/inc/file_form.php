<?
if (user_access('lib_stat_delete')){
if (isset($_GET['act']) && $_GET['act']=='delete' && $l!='/')
{

echo "<div class=\"err\">";
echo "Delete File \"$file_id[name]\"?<br />\n";
echo "<a href='?act=delete&amp;ok'>Yes</a> \n";
echo "<a href='?'>No�</a><br />\n";
echo "</div>";
}


echo "<div class=\"foot\">\n";
echo "&raquo;<a href='?act=delete'>Delete File</a><br />\n";
echo "</div>\n";



}
?>