<?
include_once 'sys/inc/start.php';
include_once 'sys/inc/compress.php';
include_once 'sys/inc/sess.php';
include_once 'sys/inc/home.php';
include_once 'sys/inc/settings.php';
include_once 'sys/inc/db_connect.php';
include_once 'sys/inc/ipua.php';
include_once 'sys/inc/fnc.php';
include_once 'sys/inc/user.php';
only_reg(); 
$set['title']='New Messages';
include_once 'sys/inc/thead.php';
title();
aut();


$k_post=mysql_result(mysql_query("SELECT COUNT(DISTINCT `mail`.`id_user`) FROM `mail`
 LEFT JOIN `users_konts` ON `mail`.`id_user` = `users_konts`.`id_kont` AND `users_konts`.`id_user` = '$user[id]'
 WHERE `mail`.`id_kont` = '$user[id]' AND (`users_konts`.`type` IS NULL OR `users_konts`.`type` = 'common' OR `users_konts`.`type` = 'favorite') AND `mail`.`read` = '0'"),0);
//echo mysql_error(),"<br />\n";

$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];
echo "<table class='post'>\n";
if ($k_post==0)
{
echo "   <tr>\n";
echo "  <td class='p_t'>\n";
echo "No Messages\n";
echo "  </td>\n";
echo "   </tr>\n";
}
else
{
$q=mysql_query("SELECT MAX(`mail`.`time`) AS `last_time`, COUNT(`mail`.`id`) AS `count`, `mail`.`id_user`, `users_konts`.`name` FROM `mail`
 LEFT JOIN `users_konts` ON `mail`.`id_user` = `users_konts`.`id_kont` AND `users_konts`.`id_user` = '$user[id]'
 WHERE `mail`.`id_kont` = '$user[id]' AND (`users_konts`.`type` IS NULL  OR `users_konts`.`type` = 'common' OR `users_konts`.`type` = 'favorite') AND `mail`.`read` = '0'
  GROUP BY `mail`.`id_user` ORDER BY `count` DESC LIMIT $start, $set[p_str]");
//echo mysql_error(),"<br />\n";
while ($kont = mysql_fetch_assoc($q))
{
$ank=get_user($kont['id_user']);
echo "   <tr>\n";
if ($set['set_show_icon']==2){
echo "  <td class='icon48' rowspan='2'>\n";
avatar($ank['id']);
echo "  </td>\n";
}
elseif ($set['set_show_icon']==1)
{
echo "  <td class='icon14'>\n";
echo "<img src='/style/themes/$set[set_them]/user/$ank[pol].png' alt='' />";
echo "  </td>\n";
}

echo "  <td class='p_t'>\n";
if ($ank)
echo "<a href='/mail.php?id=$ank[id]'>".($kont['name']?$kont['name']:$ank['nick'])."</a>".online($ank['id'])." (+$kont[count])\n";
else
echo "<a href='/mail.php?id=$ank[id]'>[DELETED] (+$kont[count])\n";
echo "  </td>\n";
echo "   </tr>\n";
echo "   <tr>\n";
if ($set['set_show_icon']==1)echo "  <td class='p_m' colspan='2'>\n"; else echo "  <td class='p_m'>\n";
echo "Sent: ".vremja($kont['last_time'])."<br />\n";
echo "  </td>\n";
echo "   </tr>\n";




}
}
echo "</table>\n";




if ($k_page>1)str('?',$k_page,$page); // Вывод страниц

echo "<div class='foot'>\n";
echo "<a href='/konts.php?$passgen'>Contact List</a><br />\n";
if(isset($_SESSION['refer']) && $_SESSION['refer']!=NULL && otkuda($_SESSION['refer']))
echo "&laquo;<a href='$_SESSION[refer]'>".otkuda($_SESSION['refer'])."</a><br />\n";
echo "&laquo;<a href='umenu.php'>CPanel</a><br />\n";
echo "</div>\n";
include_once 'sys/inc/tfoot.php';
?>