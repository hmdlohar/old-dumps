<?
function permissions($filez){
return decoct(@fileperms("$filez")) % 1000;
}


function test_chmod($df,$chmod)
{
global $err,$user;
if (isset($user) && $user['level']==10)
$show_df=ereg_replace('^'.H, $_SERVER["DOCUMENT_ROOT"].'/', $df);
else $show_df=$df;


@list($f_chmod1,$f_chmod2,$f_chmod3)=str_split(permissions($df));
list($n_chmod1,$n_chmod2,$n_chmod3)=str_split($chmod);
//list($m_chmod1,$m_chmod2,$m_chmod3)=str_split($max_chmod);

if ($f_chmod1<$n_chmod1 || $f_chmod2<$n_chmod2 || $f_chmod3<$n_chmod3)
{
$err[]="Set the CHMOD $n_chmod1$n_chmod2$n_chmod3 at $show_df";
echo "<span class='off'>$show_df : [$f_chmod1$f_chmod2$f_chmod3] - >$n_chmod1$n_chmod2$n_chmod3</span><br />\n";
}
else
{
echo "<span class='on'>$show_df ($n_chmod1$n_chmod2$n_chmod3) : $f_chmod1$f_chmod2$f_chmod3 (OK)</span><br />\n";
}
}

if (file_exists(H.'install/'))test_chmod(H.'install/',777);
test_chmod(H.'sys/avatar/',777);
test_chmod(H.'sys/dat/',777);
test_chmod(H.'sys/forum/files',777);
test_chmod(H.'sys/gallery/48/',777);
test_chmod(H.'sys/gallery/128/',777);
test_chmod(H.'sys/gallery/640/',777);
test_chmod(H.'sys/gallery/foto/',777);
test_chmod(H.'sys/lib/stats/',777);
test_chmod(H.'sys/license/',777);
test_chmod(H.'sys/inc/',777);
test_chmod(H.'sys/fnc/',777);
test_chmod(H.'sys/loads/files/',777);
test_chmod(H.'sys/loads/mp3crop/',777);
test_chmod(H.'sys/loads/screens/14/',777);
test_chmod(H.'sys/loads/screens/48/',777);
test_chmod(H.'sys/loads/screens/128/',777);
test_chmod(H.'sys/obmen/files/',777);
test_chmod(H.'sys/obmen/screens/14/',777);
test_chmod(H.'sys/obmen/screens/48/',777);
test_chmod(H.'sys/obmen/screens/128/',777);
test_chmod(H.'sys/update/',777);
test_chmod(H.'sys/tmp/',777);
test_chmod(H.'style/themes/',777);
if (file_exists(H.'sys/dat/settings_6.2.dat'))test_chmod(H.'sys/dat/settings_6.2.dat',666);

?>