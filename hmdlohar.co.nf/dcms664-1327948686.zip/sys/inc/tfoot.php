<?

if (file_exists(H."style/themes/$set[set_them]/foot.php"))
include_once H."style/themes/$set[set_them]/foot.php";
else
{

list($msec, $sec) = explode(chr(32), microtime());
echo "<div class='foot'>";
echo "<a href='/'>Home</a><br />\n";
echo "<a href='/users.php'>Members: ".mysql_result(mysql_query("SELECT COUNT(*) FROM `user`"), 0)."</a> users<br />\n";
echo "<a href='/online.php'>Online: ".mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `date_last` > ".(time()-600).""), 0)."</a> members<br />\n";
echo "<a href='/online_g.php'>Guest: ".mysql_result(mysql_query("SELECT COUNT(*) FROM `guests` WHERE `date_last` > ".(time()-600)." AND `pereh` > '0'"), 0)."</a> Online<br />\n";
if (isset($user) && $user['level']!=0) echo "Speed: ".round(($sec + $msec) - $conf['headtime'], 3)." secs<br />\n";

echo "</div>\n";
echo "<div class='rekl'>\n";
rekl(3);
echo "</div>\n";
echo "</div>\n</body>\n</html>";
}
exit;

?>