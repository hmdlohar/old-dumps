<?








$k_n_s_zak=mysql_result(mysql_query("SELECT COUNT(`forum_zakl`.`id_them`) FROM `forum_zakl` LEFT JOIN `forum_p` ON `forum_zakl`.`id_them` = `forum_p`.`id_them` AND `forum_p`.`time` > `forum_zakl`.`time` WHERE `forum_zakl`.`id_user` = '$user[id]' AND `forum_p`.`id` IS NOT NULL"),0);
if ($k_n_s_zak>0)
echo "<a href='/zakl.php' title='New Bookmarks Messages'><b>Messages in bookmarks ($k_n_s_zak)</b></a><br />\n";
elseif (mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_zakl` WHERE `id_user` = '$user[id]'"),0)!=0)
echo "<a href='/zakl.php'>My Bookmarks</a><br />\n";








$k_new=mysql_result(mysql_query("SELECT COUNT(`mail`.`id`) FROM `mail`
 LEFT JOIN `users_konts` ON `mail`.`id_user` = `users_konts`.`id_kont` AND `users_konts`.`id_user` = '$user[id]'
 WHERE `mail`.`id_kont` = '$user[id]' AND (`users_konts`.`type` IS NULL OR `users_konts`.`type` = 'common' OR `users_konts`.`type` = 'favorite') AND `mail`.`read` = '0'"),0);
$k_new_fav=mysql_result(mysql_query("SELECT COUNT(`mail`.`id`) FROM `mail`
 LEFT JOIN `users_konts` ON `mail`.`id_user` = `users_konts`.`id_kont` AND `users_konts`.`id_user` = '$user[id]'
 WHERE `mail`.`id_kont` = '$user[id]' AND (`users_konts`.`type` = 'favorite') AND `mail`.`read` = '0'"),0);



if ($k_new!=0 && $k_new_fav==0)
echo "<b><a href='/new_mess.php'>New ".($k_new==1?'':'')."Private Message".($k_new==1?'':"s ($k_new)")."</a></b> <img src='/style/icons/mess0.png' /><br />\n";
if ($k_new_fav!=0)
echo "<b><a href='/new_mess.php'>Messages".($k_new_fav==1?'':'')."</a></b> <img src='/style/icons/mess_fav.png' alt='$k_new_fav' /><br />\n";


echo "<a href='/konts.php'>My Contacts</a> (".mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND (`type` = 'common' OR `type` = 'favorite')"), 0).")<br />\n";
echo "<a href='/info.php'>My Profile</a><br />\n";
echo "<a href='/settings.php'>My Settings</a><br />\n";
echo "<a href='/avatar.php'>My Avatars</a><br />\n";
echo "<a href='/anketa.php'>Edit Profile</a><br />\n";

$opdirbase=@opendir(H.'sys/add/umenu');
while ($filebase=@readdir($opdirbase))
if (eregi('\.php$',$filebase))
include_once(H.'sys/add/umenu/'.$filebase);

echo "<a href='/secure.php'>Change Password</a><br />\n";
echo "<a href='/rules.php'>Rules of the site</a><br />\n";

if (user_access('adm_panel_show'))echo "<a href='/adm_panel/'>Admin Panel</a><br />\n";

if ($set['web']==false)
echo "<hr />\n<a href='/exit.php'>LogOut</a><br />\n";
?>