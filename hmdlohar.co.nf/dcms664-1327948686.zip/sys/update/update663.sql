ALTER TABLE `user` ADD `add_konts` INT DEFAULT '1' NOT NULL;

