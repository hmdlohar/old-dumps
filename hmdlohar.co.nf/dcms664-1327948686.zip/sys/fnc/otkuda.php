<?



if (isset($_SESSION['refer']) && $_SESSION['refer']!=NULL && !ereg('(rules)|(smiles)|(secure)|(aut)|(reg)|(umenu)|(zakl)|(mail)|(anketa)|(settings)|(avatar)|(info)\.php',$_SERVER['SCRIPT_NAME']))

$_SESSION['refer']=NULL;



function otkuda($ref)

{

if (eregi('^/forum/',$ref))

$mesto='Forum';

elseif (eregi('^/chat/',$ref))

$mesto='ChatBox';

elseif (eregi('^/lib/',$ref))

$mesto='Library';

elseif (eregi('^/news/',$ref))

$mesto='News';

elseif (eregi('^/adm_panel/',$ref))

$mesto='Admin Panel';

elseif (eregi('^/votes/',$ref))

$mesto='Votes';

elseif (eregi('^/guest/',$ref))

$mesto='Guestbook';

elseif (eregi('^/loads/',$ref))

$mesto='Download';

elseif (eregi('^/users\.php',$ref))

$mesto='Users';

elseif (eregi('^/online\.php',$ref))

$mesto='Online';

elseif (eregi('^/online_g\.php',$ref))

$mesto='Guest Online';

elseif (eregi('^/reg\.php',$ref))

$mesto='Registration';

elseif (eregi('^/obmen/',$ref))

$mesto='Shared File';

elseif (eregi('^/aut\.php',$ref))

$mesto='Login Site';

elseif (eregi('^/index\.php',$ref))

$mesto='Home';

elseif (eregi('^/\??$',$ref))

$mesto='Home';

else

$mesto=false;

return $mesto;

}





?>