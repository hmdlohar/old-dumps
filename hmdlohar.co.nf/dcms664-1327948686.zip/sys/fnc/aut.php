<?


function aut()
{
global $set;





if ($set['web']==false)
{
echo "<div class='aut'>";
global $user;
if (isset($user))
{


$k_new=mysql_result(mysql_query("SELECT COUNT(`mail`.`id`) FROM `mail`
 LEFT JOIN `users_konts` ON `mail`.`id_user` = `users_konts`.`id_kont` AND `users_konts`.`id_user` = '$user[id]'
 WHERE `mail`.`id_kont` = '$user[id]' AND (`users_konts`.`type` IS NULL OR `users_konts`.`type` = 'common' OR `users_konts`.`type` = 'favorite') AND `mail`.`read` = '0'"),0);
$k_new_fav=mysql_result(mysql_query("SELECT COUNT(`mail`.`id`) FROM `mail`
 LEFT JOIN `users_konts` ON `mail`.`id_user` = `users_konts`.`id_kont` AND `users_konts`.`id_user` = '$user[id]'
 WHERE `mail`.`id_kont` = '$user[id]' AND (`users_konts`.`type` = 'favorite') AND `mail`.`read` = '0'"),0);


if ($k_new!=0 && $k_new_fav==0)
echo "<a href='/new_mess.php'>$k_new <img src='/style/icons/mess0.png' alt='$k_new' /><br />Private Message</a><br />\n";


echo "$user[nick] <a href='/umenu.php'>CPanel</a> | <a href='/exit.php'>Logout</a><br />\n";
if ($k_new_fav!=0)
echo "<b><a href='/new_mess.php'><img src='/style/icons/mess_fav.png' alt='$k_new_fav' /> Messages".($k_new_fav==1?'е':'я')."</a></b><br />\n";



$k_n_s_zak=mysql_result(mysql_query("SELECT COUNT(`forum_zakl`.`id_them`) FROM `forum_zakl` LEFT JOIN `forum_p` ON `forum_zakl`.`id_them` = `forum_p`.`id_them` AND `forum_p`.`time` > `forum_zakl`.`time` WHERE `forum_zakl`.`id_user` = '$user[id]' AND `forum_p`.`id` IS NOT NULL"),0);
if ($k_n_s_zak>0)
echo "<a href='/zakl.php' title='New messages in bookmarks'>Messages in bookmarks ($k_n_s_zak)</a><br />\n";



}
else
{
echo "In order to use all features on the site must pass authorization with Login. If you have not yet registered, you must go through a registration process.<br />\n";
echo "<a href='/aut.php'>Login</a> | <a href='/reg.php'>Register</a><br />\n";

}
echo "</div>\n";
}
}



?>