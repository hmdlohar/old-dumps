<?
function smiles($msg)
{
$msg=eregi_replace('(:|=)-?\){4,}|:ROFL:|\*ROFL\*|ROFL!{1,}', '<img src="/style/smiles/rofl.gif" alt="*ROFL*" />', $msg);
$msg=eregi_replace('\*BRAVO\*', '<img src="/style/smiles/clapping.gif" alt="*BRAVO*" />', $msg);
$msg=eregi_replace(':BRAVO:', '<img src="/style/smiles/clapping.gif" alt=":BRAVO:" />', $msg);
$msg=eregi_replace(':clapping:', '<img src="/style/smiles/clapping.gif" alt=":clapping:" />', $msg);
$msg=eregi_replace(':БРАВО:', '<img src="/style/smiles/clapping.gif" alt=":БРАВО:" />', $msg);
$msg=eregi_replace('\*БРАВО\*', '<img src="/style/smiles/clapping.gif" alt="*БРАВО*" />', $msg);
// большая улыбка
$msg=ereg_replace('((:-?)|\+|=)D', '<img src="/style/smiles/biggrin.gif" alt="\\0" />', $msg);
//
$msg=eregi_replace('\*TIRED\*|\|-?0|:boredom:', '<img src="/style/smiles/boredom.gif" alt="*TIRED*" />', $msg);
// плохо
$msg=eregi_replace(':-?(!|~)|:bad:|(:|\+|=)\(~', '<img src="/style/smiles/bad.gif" alt=":-!" />', $msg);
// улыбка 
$msg=eregi_replace('(:-?|\+)\){1,3}|:smile:|\*smile\*', '<img src="/style/smiles/smile.gif" alt="\\0" />', $msg);
// грусть
$msg=eregi_replace('(:-?|\+)\({1,3}|:sad:|\*sad\*', '<img src="/style/smiles/sad.gif" alt="\\0" />', $msg);
// подмигивание
$msg=ereg_replace('(^| );-?\)', '<img src="/style/smiles/wink.gif" alt="\\0" />', $msg);
$msg=str_replace('^_~', '<img src="/style/smiles/wink.gif" alt="^_~" />', $msg);
$msg=eregi_replace(':wink:', '<img src="/style/smiles/wink.gif" alt=":wink:" />', $msg);
// язык 
$msg=ereg_replace('(:-?)(P|b|p)', '<img src="/style/smiles/blum3.gif" alt="\\0" />', $msg);
$msg=eregi_replace(':tongue:', '<img src="/style/smiles/blum3.gif" alt=":tongue:" />', $msg);
// крутой
$msg=ereg_replace('((8|B)-?)\)', '<img src="/style/smiles/dirol.gif" alt="\\0" />', $msg);
$msg=eregi_replace(':COOL:|COOL!{1,}', '<img src="/style/smiles/dirol.gif" alt="\\0" />', $msg);

// 
$msg=str_replace(':-[', '<img src="/style/smiles/blush2.gif" alt=":-[" />', $msg);
// шок
$msg=eregi_replace('(O|0)_(O|0)', '<img src="/style/smiles/shok.gif" alt="\\0" />', $msg);
// поцелуй
$msg=eregi_replace('(:-?)(\*|\{\})|\^\.\^|:kiss:|\*kiss\*', '<img src="/style/smiles/kiss.gif" alt="\\0" />', $msg);
// плак
$msg=ereg_replace(':\'-?\({1,}', '<img src="/style/smiles/cray.gif" alt="\\0" />', $msg);
// секрет
$msg=eregi_replace(':-?(X|#)|:secret:', '<img src="/style/smiles/secret.gif" alt="\\0" />', $msg);
// агрессия
$msg=eregi_replace('(&gt;)(:|\+)(o|0)|:angry:|:-@', '<img src="/style/smiles/aggressive.gif" alt="\\0" />', $msg);
// дурак
$msg=ereg_replace('(:-?|=)\|', '<img src="/style/smiles/fool.gif" alt="\\0" />', $msg);
// be
$msg=ereg_replace(':-/', '<img src="/style/smiles/beee.gif" alt="\\0" />', $msg);
// смех
$msg=eregi_replace('8P|\*JOKINGLY\*', '<img src="/style/smiles/mosking.gif" alt="\\0" />', $msg);
// дьявол
$msg=eregi_replace('(\]|\}):-?&gt;|:diablo:|\*DIABLO\*|&gt;:-?]', '<img src="/style/smiles/diablo.gif" alt="\\0" />', $msg);
// музыка
$msg=eregi_replace('\[:-?\}', '<img src="/style/smiles/music2.gif" alt="\\0" />', $msg);
// воздушный поцелуй
$msg=eregi_replace('\*KISSED\*', '<img src="/style/smiles/air_kiss.gif" alt="\\0" />', $msg);
// стоп
$msg=eregi_replace('\*STOP\*|:stop:|stop!{1,}', '<img src="/style/smiles/stop.gif" alt="\\0" />', $msg);
// поцелуй
$msg=eregi_replace('\*KISSING\*', '<img src="/style/smiles/kiss_3.gif" alt="\\0" />', $msg);
// роза
$msg=ereg_replace('@\}-&gt;--|@\}-:--|@&gt;\}--', '<img src="/style/smiles/give_rose.gif" alt="\\0" />', $msg);
// все отлично
$msg=eregi_replace('\*THUMBS_UP\*|:GOOD:|\*GOOD\*|good!{1,}', '<img src="/style/smiles/good.gif" alt="\\0" />', $msg);
// пить
$msg=eregi_replace('\*DRINK\*|:drink:', '<img src="/style/smiles/drinks.gif" alt="\\0" />', $msg);
// влюблен
$msg=eregi_replace('\*IN_LOVE\*|LOVE!{1,}', '<img src="/style/smiles/man_in_love.gif" alt="\\0" />', $msg);
// бомба
$msg=str_replace('@=', '<img src="/style/smiles/bomb.gif" alt="@=" />', $msg);
// потерян
$msg=eregi_replace('%-?\)|:-?\$|:wacko:', '<img src="/style/smiles/wacko.gif" alt="\\0" />', $msg);

$msg=eregi_replace('\*WASSUP\*', '<img src="/style/smiles/mamba.gif" alt="*WASSUP*" />', $msg);
$msg=eregi_replace('\*SUP\*', '<img src="/style/smiles/mamba.gif" alt="*SUP*" />', $msg);
$msg=eregi_replace('\*MAMBA\*', '<img src="/style/smiles/mamba.gif" alt="*MAMBA*" />', $msg);
$msg=eregi_replace(':MAMBA:', '<img src="/style/smiles/mamba.gif" alt=":MAMBA:" />', $msg);

$msg=eregi_replace('\*PARDON\*', '<img src="/style/smiles/pardon.gif" alt="*PARDON*" />', $msg);
$msg=eregi_replace(':pardon:', '<img src="/style/smiles/pardon.gif" alt=":pardon:" />', $msg);

$msg=eregi_replace('\*NO\*', '<img src="/style/smiles/nea.gif" alt="*NO*" />', $msg);

$msg=eregi_replace('\*CRAZY\*', '<img src="/style/smiles/crazy.gif" alt="*CRAZY*" />', $msg);
$msg=eregi_replace(':crazy:', '<img src="/style/smiles/crazy.gif" alt="*CRAZY*" />', $msg);

$msg=eregi_replace('\*DONT_KNOW\*', '<img src="/style/smiles/dntknw.gif" alt="*DONT_KNOW*" />', $msg);
$msg=eregi_replace('\*UNKNOWN\*', '<img src="/style/smiles/dntknw.gif" alt="*DONT_KNOW*" />', $msg);
$msg=eregi_replace(':HZ:', '<img src="/style/smiles/dntknw.gif" alt="*DONT_KNOW*" />', $msg);

$msg=eregi_replace('\*SORRY\*', '<img src="/style/smiles/sorry.gif" alt="*SORRY*" />', $msg);
$msg=eregi_replace(':sorry:', '<img src="/style/smiles/sorry.gif" alt="*SORRY*" />', $msg);

$msg=eregi_replace('\*YAHOO!*\*|:YAHOO:|YAHOO!{1,}', '<img src="/style/smiles/yahoo.gif" alt="\\0" />', $msg);

$msg=eregi_replace('\*DANCE\*', '<img src="/style/smiles/dance4.gif" alt="*DANCE*" />', $msg);
$msg=eregi_replace(':dance:', '<img src="/style/smiles/dance4.gif" alt="*DANCE*" />', $msg);

$msg=eregi_replace('\*HELP\*', '<img src="/style/smiles/help.gif" alt="*HELP*" />', $msg);

$msg=eregi_replace('\*OK\*', '<img src="/style/smiles/ok.gif" alt="*OK*" />', $msg);

$msg=eregi_replace('\*HELLO\*', '<img src="/style/smiles/preved.gif" alt="*HELLO*" />', $msg);
$msg=eregi_replace('\*PREVED\*', '<img src="/style/smiles/preved.gif" alt="*PREVED*" />', $msg);
$msg=eregi_replace('\*PRIVET\*', '<img src="/style/smiles/preved.gif" alt="*PRIVET*" />', $msg);
$msg=eregi_replace('\*HI\*', '<img src="/style/smiles/preved.gif" alt="*HI*" />', $msg);

//$msg=eregi_replace(';D', '<img src="/style/smiles/acute.gif" alt="*ACUTE*" />', $msg);
$msg=eregi_replace('\*ACUTE\*', '<img src="/style/smiles/acute.gif" alt="*ACUTE*" />', $msg);

$msg=eregi_replace('\*BYE\*', '<img src="/style/smiles/bye.gif" alt="*BYE*" />', $msg);

$msg=eregi_replace('\*WRITE\*', '<img src="/style/smiles/mail1.gif" alt="*WRITE*" />', $msg);
$msg=eregi_replace('\*MAIL\*', '<img src="/style/smiles/mail1.gif" alt="*MAIL*" />', $msg);

$msg=eregi_replace('\*WALL\*', '<img src="/style/smiles/dash1.gif" alt="*WALL*" />', $msg);
$msg=eregi_replace('\*DASH\*', '<img src="/style/smiles/dash1.gif" alt="*DASH*" />', $msg);

$msg=eregi_replace('\*YES\*', '<img src="/style/smiles/yes3.gif" alt="*YES*" />', $msg);

$msg=eregi_replace('\*SCRATCH\*', '<img src="/style/smiles/scratch_one-s_head.gif" alt="*SCRATCH*" />', $msg);

$msg=eregi_replace('\*LOL!*\*|:LOL:|LOL!{1,}', '<img src="/style/smiles/lol.gif" alt="\\0" />', $msg);

$msg=eregi_replace('\*HAPPY\*', '<img src="/style/smiles/i-m_so_happy.gif" alt="*HAPPY*" />', $msg);
$msg=eregi_replace(':happy:', '<img src="/style/smiles/i-m_so_happy.gif" alt=":happy:" />', $msg);

$msg=eregi_replace('\*db\*', '<img src="/style/smiles/pleasantry.gif" alt="*db*" />', $msg);
$msg=eregi_replace(':db:', '<img src="/style/smiles/pleasantry.gif" alt=":db:" />', $msg);

return $msg;
}

?>