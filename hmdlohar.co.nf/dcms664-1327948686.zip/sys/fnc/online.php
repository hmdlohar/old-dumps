<?

function online($user=NULL)
{
global $set,$time;
static $users;
if (!isset($users[$user]))
{
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE `id_user` = '$user' AND `time` > '$time'"), 0)!=0)
$users[$user]= ' <span class="off">[BAN]</span>';
elseif (mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `id` = '$user' AND `date_last` > '".(time()-600)."' LIMIT 1"),0)==1)
{
if ($set['show_away']==0)$on='online';
else
{
$ank=mysql_fetch_assoc(mysql_query("SELECT `date_last` FROM `user` WHERE `id` = '$user' LIMIT 1"));
if ((time()-$ank['date_last'])==0)
$on='online';
else
$on='away: '.(time()-$ank['date_last']).' secs';
}

$users[$user]= " <span class=\"on\">[$on]</span>";
}
else 
{
$users[$user]=null;
$users[$user]= ' <span class="off">[off]</span>'; // раскомментируйте, чтобы отображалось, когда пользователь не на сайте
}

}
return $users[$user];
}

?>