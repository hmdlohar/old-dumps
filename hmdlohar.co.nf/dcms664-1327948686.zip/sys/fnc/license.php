<?

function lic_dcms_loc() // получение локальной лицензии
{
$return=false;
$od_lic=opendir(H.'sys/license/');
while ($rd_lic=readdir($od_lic))
{
if (eregi(str_replace('.', '\.', $rd_lic).'$',$_SERVER['HTTP_HOST']))
{
if ($license=@unserialize(@file_get_contents(H.'sys/license/'.$rd_lic)))
{
if (isset($license['url']) && eregi(str_replace('.', '\.', $license['url']).'$',$_SERVER['HTTP_HOST']))
{
if ($license['last_time']<time()-604800 || $license['last_time']<$license['last_update']-604800)
{
@unlink(H.'sys/license/'.$rd_lic);
}
else
{
$return=$license;
}
break;
}
else
{
@unlink(H.'sys/license/'.$rd_lic);
}
}
}
}
return $return;
closedir($od_lic);
}

function copyright2($copyright){
return eregi_replace("</div>(\n|\r)*</body>", "<div style='font-size:small;'>Powered by: <a title='translit by' href=\"http://siegiett.co.tv\">&copy;</a> <a title='dcms.su' href=\"http://dcms.su\">DCMS</a><br />\n</div>\n</div>\n</body>", $copyright);
}



function lic_dcms($send=null)
{
global $set,$license;
if ($sock=@fsockopen($set['http_license'], 80, $err_no, $err_str, 7))
{
$data_out['host']=$_SERVER['HTTP_HOST']; // адрес сайта
$data_out['ver']=$set['dcms_version']; // версия движка
$data_out['data']=$send; // отправляемые данные



// ключег
if ($license)
{
$data_out['key']=$license['key'];
$data_out['last_time']=$license['last_time'];
}
else
{
$data_out['tmp_key']=md5(passgen());
@file_put_contents(H.'sys/tmp/tmp_key.dat', $data_out['tmp_key']);
@chmod(H.'sys/tmp/tmp_key.dat', 0777);
}

$post_value='data='.serialize($data_out);
$s_head="POST /dcms/license.dcms HTTP/1.0\r\n";
$s_head.="Host: $set[http_license]\r\n";
$s_head.="User-Agent: DCMS/$set[dcms_version]\r\n";
//$s_head.="Keep-Alive: 300\r\n";
$s_head.="Connection: close\r\n";
$s_head .= "Content-Type: application/x-www-form-urlencoded\r\n";
$s_head .= "Content-Length: ".strlen($post_value)."\r\n\r\n"; 
$s_head .= $post_value;

fwrite($sock, $s_head); // отправка данных

$buffer=null;while (!feof($sock)){$buffer .= fgets($sock);} // прием данных
fclose($sock);


list($header,$content)=explode("\r\n\r\n", $buffer); // разборка данных

$data_in=@unserialize($content);

// информация о лицензии
if (isset($data_in['lic_info']))
{
$data_in['lic_info']['last_update']=time();
@unlink(H.'sys/license/'.$data_in['lic_info']['url']);
@file_put_contents(H.'sys/license/'.$data_in['lic_info']['url'], serialize($data_in['lic_info']));
@chmod(H.'sys/license/'.$data_in['lic_info']['url'], 0777);
$license=$data_in['lic_info'];
}
else $license=false;


// список новых версий
if (isset($data_in['new_ver']))
{
mysql_query('TRUNCATE TABLE `license_list_ver`');
mysql_query('TRUNCATE TABLE `license_list_changelog`');
$new_ver=$data_in['new_ver'];
for ($i=0;$i<count($new_ver);$i++)
{
mysql_query("INSERT INTO `license_list_ver` (`id`, `ver_1`, `ver_2`, `ver_3`, `delete`, `sql`)
VALUES ('".$new_ver[$i]['id']."', '".$new_ver[$i]['ver_1']."', '".$new_ver[$i]['ver_2']."', '".$new_ver[$i]['ver_3']."','".my_esc($new_ver[$i]['delete'])."','".my_esc($new_ver[$i]['sql'])."')");
for ($z=0;(isset($new_ver[$i]['changelog']) && $z<count($new_ver[$i]['changelog']) );$z++)
{
mysql_query("INSERT INTO `license_list_changelog` (`text`, `ver_1`, `ver_2`, `ver_3`) VALUES ('".my_esc($new_ver[$i]['changelog'][$z])."', '".$new_ver[$i]['ver_1']."','".$new_ver[$i]['ver_2']."','".$new_ver[$i]['ver_3']."')");
}
}
}

// запрашиваемые занные
if (isset($data_in['data']))return $data_in['data'];else return false;
}
elseif($license!==false)
{
$license['last_update']=time();
@unlink(H.'sys/license/'.$data_in['lic_info']['url']);
@file_put_contents(H.'sys/license/'.$data_in['lic_info']['url'], serialize($license));
}
else return false;
}


$license=lic_dcms_loc(); // получение локальной лицензии

if (!isset($nolicupdate)){
if (isset($license['last_update']) && $license['last_update']<time()-60*60*6)
lic_dcms(); // обновление сведений раз в 6 часов
}
if (isset($compress) && $license==false)ob_start ("copyright2");
?>