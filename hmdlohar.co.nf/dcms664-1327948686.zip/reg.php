<?
//include_once 'sys/inc/mp3.php';
//include_once 'sys/inc/zip.php';
include_once 'sys/inc/start.php';
include_once 'sys/inc/compress.php';
include_once 'sys/inc/sess.php';
include_once 'sys/inc/home.php';
include_once 'sys/inc/settings.php';
include_once 'sys/inc/db_connect.php';
include_once 'sys/inc/ipua.php';
include_once 'sys/inc/fnc.php';
include_once 'sys/inc/shif.php';
$show_all=true; // показ для всех
include_once 'sys/inc/user.php';
only_unreg();
$set['title']='Site Registration';
include_once 'sys/inc/thead.php';
title();
//aut();
if ($set['guest_select']=='1')msg("Access to the site is allowed only to authorized users");
if ((!isset($_SESSION['refer']) || $_SESSION['refer']==NULL)
&& isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER']!=NULL &&
!ereg('mail\.php',$_SERVER['HTTP_REFERER']))
$_SESSION['refer']=str_replace('&','&amp;',ereg_replace('^http://[^/]*/','/', $_SERVER['HTTP_REFERER']));


if ($set['reg_select']=='close')
{
$err='Registration suspended';
err();

echo "<a href='/aut.php'>Login</a><br />\n";
include_once 'sys/inc/tfoot.php';
}
elseif($set['reg_select']=='open_mail' && isset($_GET['id']) && isset($_GET['activation']) && $_GET['activation']!=NULL)
{
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `id` = '".intval($_GET['id'])."' AND `activation` = '".my_esc($_GET['activation'])."'"),0)==1)
{

mysql_query("UPDATE `user` SET `activation` = null WHERE `id` = '".intval($_GET['id'])."' LIMIT 1");
$user=mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = '".intval($_GET['id'])."' LIMIT 1"));
mysql_query("INSERT INTO `reg_mail` (`id_user`,`mail`) VALUES ('$user[id]','$user[ank_mail]')");
msg('Your account has been successfully activated');

$_SESSION['id_user']=$user['id'];
include_once 'sys/inc/tfoot.php';
}
}

if (isset($_SESSION['step']) && $_SESSION['step']==1 && mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `nick` = '".$_SESSION['reg_nick']."'"),0)==0 && isset($_POST['pass1']) && $_POST['pass1']!=NULL && $_POST['pass2'] && $_POST['pass2']!=NULL)
{

if ($set['reg_select']=='open_mail')
{
if (!isset($_POST['ank_mail']) || $_POST['ank_mail']==NULL)$err[]='Enter your valid email address';
elseif (!preg_match('#^[A-z0-9-\._]+@[A-z0-9]{2,}\.[A-z]{2,4}$#ui',$_POST['ank_mail']))$err[]='Email wrong!!!';
elseif(mysql_result(mysql_query("SELECT COUNT(*) FROM `reg_mail` WHERE `mail` = '".my_esc($_POST['ank_mail'])."'"),0)!=0)
{
$err[]="Users with this email is already registered";
}
}


if (strlen2($_POST['pass1'])<6)$err[]='For security reasons, the password must be longer than 6 characters';
if (strlen2($_POST['pass1'])>32)$err[]='The password lenght is more than 32 characters';
if ($_POST['pass1']!=$_POST['pass2'])$err[]='Paswords do not match';
if (!isset($_SESSION['captcha']) || !isset($_POST['chislo']) || $_SESSION['captcha']!=$_POST['chislo']){$err[]='Wrong verification number';}

if (!isset($err))
{
if ($set['reg_select']=='open_mail')
{
$activation=md5(passgen());
mysql_query("INSERT INTO `user` (`nick`, `pass`, `date_reg`, `date_last`, `pol`, `activation`, `ank_mail`) values('".$_SESSION['reg_nick']."', '".shif($_POST['pass1'])."', '$time', '$time', '".intval($_POST['pol'])."', '$activation', '".my_esc($_POST['ank_mail'])."')",$db);

$id_reg=mysql_insert_id();
$subject = "Account Activate";
$regmail = "Hi $_SESSION[reg_nick]<br />
To activate your account, go to:<br />
<a href='http://$_SERVER[HTTP_HOST]/reg.php?id=$id_reg&amp;activation=$activation'>http://$_SERVER[HTTP_HOST]/reg.php?id=".mysql_insert_id()."&amp;activation=$activation</a><br />
If your account not activated within 24 hours, Admin will be removed your account <br />
Sincerely, site administration<br />
";
$adds="From: \"admin@$_SERVER[HTTP_HOST]\" <admin@$_SERVER[HTTP_HOST]>\n";
//$adds = "From: <$set[reg_mail]>\n";
//$adds .= "X-sender: <$set[reg_mail]>\n";
$adds .= "Content-Type: text/html; charset=utf-8\n";
mail($_POST['ank_mail'],'=?utf-8?B?'.base64_encode($subject).'?=',$regmail,$adds);

}
else
mysql_query("INSERT INTO `user` (`nick`, `pass`, `date_reg`, `date_last`, `pol`) values('".$_SESSION['reg_nick']."', '".shif($_POST['pass1'])."', '$time', '$time', '".intval($_POST['pol'])."')",$db);



$user=mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `nick` = '".my_esc($_SESSION['reg_nick'])."' AND `pass` = '".shif($_POST['pass1'])."' LIMIT 1"));


if (isset($_SESSION['http_referer']))
mysql_query("INSERT INTO `user_ref` (`time`, `id_user`, `type_input`, `url`) VALUES ('$time', '$user[id]', 'reg', '".my_esc($_SESSION['http_referer'])."')");

$_SESSION['id_user']=$user['id'];
setcookie('id_user', $user['id'], time()+60*60*24*365);
setcookie('pass', cookie_encrypt($_POST['pass1'],$user['id']), time()+60*60*24*365);


if ($set['reg_select']=='open_mail')
{
msg('You need to activate your account on the link sent to Email');
}
else
{
msg('Registration was successfully');
}

echo "If your browser doesn't support cookies, you can create a bookmark for autologin<br />\n";
echo "<input type='text' value='http://$_SERVER[SERVER_NAME]/?id=$user[id]&amp;pass=".htmlspecialchars($_POST['pass1'])."' /><br />\n";
if ($set['reg_select']=='open_mail')unset($user);
echo "<div class='foot'>\n";
if(isset($_SESSION['refer']) && $_SESSION['refer']!=NULL && otkuda($_SESSION['refer']))
echo "&raquo;<a href='$_SESSION[refer]'>".otkuda($_SESSION['refer'])."</a><br />\n";
echo "&raquo;<a href='umenu.php'>CPanel</a><br />\n";
echo "&raquo;<a href='/anketa.php'>Profile</a><br />\n";
echo "</div>\n";
include_once 'sys/inc/tfoot.php';
}
}
elseif (isset($_POST['nick']) && $_POST['nick']!=NULL )
{



if (mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `nick` = '".my_esc($_POST['nick'])."'"),0)==0)
{
$nick=my_esc($_POST['nick']);


if( !preg_match("#^([a-zA-Z0-9\-\_])+$#ui", $_POST['nick']))$err[]='Do not use a invalid characters!';

if (strlen2($nick)<3)$err[]='Short nickname';
if (strlen2($nick)>8)$err[]='Nick lenght exceeds 8 characters';



}
else $err[]='Nick "'.stripcslashes(htmlspecialchars($_POST['nick'])).'" already registered';


if (!isset($err)){
$_SESSION['reg_nick']=$nick;
$_SESSION['step']=1;
msg ("Nick \"$nick\" available, continue with registration?");
}
}

err();



if (isset($_SESSION['step']) && $_SESSION['step']==1){

echo "<form method='post' action='/reg.php?$passgen'>\n";
echo "Nickname [a-zA-Z0-9\-\_]:<br /><input type='text' name='nick' maxlength='32' value='$_SESSION[reg_nick]' /><br />\n";
echo "<input type='submit' value='Change' />\n";
echo "</form><br />\n";


echo "<form method='post' action='/reg.php?$passgen'>\n";
echo "Gender:<br /><select name='pol'><option value='1'>Male</option><option value='0'>Female</option></select><br />\n";

if ($set['reg_select']=='open_mail')
{
echo "E-mail:<br /><input type='text' name='ank_mail' /><br />\n";
echo "* Use a valid Email address.<br />\n";
}
echo "Password (6-32 characters):<br /><input type='password' name='pass1' maxlength='32' /><br />\n";
echo "Confirm Password:<br /><input type='password' name='pass2' maxlength='32' /><br />\n";
echo "<img src='/captcha.php?$passgen&amp;SESS=$sess' width='100' height='30' alt='Chaptcha' /><br />\n<input name='chislo' size='5' maxlength='5' value='' type='text' /><br/>\n";
echo "By registering, you automically aggre with the <a href='/rules.php'>rules</a> of the site<br />\n";

echo "<input type='submit' value='Continue' />\n";
echo "</form><br />\n";
}
else
{
echo "<form method='post' action='/reg.php?$passgen'>\n";
echo "Choose a nickname [a-zA-Z0-9\-\_]:<br /><input type='text' name='nick' maxlength='32' /><br />\n";
echo "By registering, you automically aggre with the <a href='/rules.php'>rules</a> of the site<br />\n";
echo "<input type='submit' value='Continue' />\n";
echo "</form><br />\n";
}


echo "Registered user &raquo;<a href='/aut.php'><b> Login</b></a><br />\n";
include_once 'sys/inc/tfoot.php';
?>