<?
include_once 'sys/inc/start.php';
include_once 'sys/inc/compress.php';
include_once 'sys/inc/sess.php';
include_once 'sys/inc/home.php';
include_once 'sys/inc/settings.php';
include_once 'sys/inc/db_connect.php';
include_once 'sys/inc/ipua.php';
include_once 'sys/inc/fnc.php';
include_once 'sys/inc/user.php';

only_reg();
$set['title']='My Avatar';
include_once 'sys/inc/thead.php';
title();

if (isset($_FILES['file']))
{

if (eregi('\.jpe?g$',$_FILES['file']['name']) && $imgc=@imagecreatefromjpeg($_FILES['file']['tmp_name']))
{
if (imagesx($imgc)>48 || imagesy($imgc)>48)
{
$img_x=imagesx($imgc);
$img_y=imagesy($imgc);
if ($img_x==$img_y)
{
$dstW=48; // ширина
$dstH=48; // высота
}
elseif ($img_x>$img_y)
{
$prop=$img_x/$img_y;
$dstW=48;
$dstH=ceil($dstW/$prop);
}
else
{
$prop=$img_y/$img_x;
$dstH=48;
$dstW=ceil($dstH/$prop);
}

$screen=imagecreatetruecolor($dstW, $dstH);
imagecopyresampled($screen, $imgc, 0, 0, 0, 0, $dstW, $dstH, $img_x, $img_y);
imagedestroy($imgc);
@chmod(H."sys/avatar/$user[id].jpg",0777);
@chmod(H."sys/avatar/$user[id].gif",0777);
@chmod(H."sys/avatar/$user[id].png",0777);
@unlink(H."sys/avatar/$user[id].jpg");
@unlink(H."sys/avatar/$user[id].gif");
@unlink(H."sys/avatar/$user[id].png");
imagejpeg($screen,H."sys/avatar/$user[id].jpg",100);
@chmod(H."sys/avatar/$user[id].jpg",0777);
imagedestroy($screen);
}
else
{
copy($_FILES['file']['tmp_name'