<?
if (is_file(H."sys/obmen/screens/128/$file_id[id].gif"))
{
echo "<img src='/sys/obmen/screens/128/$file_id[id].gif' alt='Скрин...' /><br />\n";
}

if ($file_id['opis']!=NULL)
{
echo "Description: ";
echo output_text($file_id['opis']);
//echo trim(br(links($file_id['opis'])));

echo "<br />\n";
}


echo "Added: ".vremja($file_id['time'])."<br />\n";





echo "Size: ".size_file($file_id['size'])."<br />\n";

?>