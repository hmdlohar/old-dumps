<?
if (user_access('obmen_file_delete'))
{
if (isset($_GET['act']) && $_GET['act']=='delete' && $l!='/')
{
echo "<div class=\"err\">";
echo "Delete file \"$file_id[name]\"?<br />\n";
echo "<a href='?showinfo&amp;act=delete&amp;ok'>Yes</a> \n";
echo "<a href='?showinfo'>No</a><br />\n";
echo "</div>";
}
else
{
echo "<div class=\"foot\">\n";
echo "&raquo;<a href='?showinfo&amp;act=delete'>Delete</a><br />\n";
echo "</div>\n";
}
}
?>