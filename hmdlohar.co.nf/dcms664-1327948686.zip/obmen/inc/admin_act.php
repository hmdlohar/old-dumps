<?


if (user_access('obmen_dir_delete') && isset($_GET['act']) && $_GET['act']=='delete' && isset($_GET['ok']) && $l!='/')
{

$q=mysql_query("SELECT * FROM `obmennik_dir` WHERE `dir_osn` like '$l%'");
while ($post = mysql_fetch_assoc($q))
{

$q2=mysql_query("SELECT * FROM `obmennik_files` WHERE `id_dir` = '$post[id]'");
while ($post2 = mysql_fetch_assoc($q2))
{
unlink(H.'sys/obmen/files/'.$post2['id'].'.dat');
}


mysql_query("DELETE FROM `obmennik_files` WHERE `id_dir` = '$post[id]'");
mysql_query("DELETE FROM `obmennik_dir` WHERE `id` = '$post[id]' LIMIT 1");
}
$q2=mysql_query("SELECT * FROM `obmennik_files` WHERE `id_dir` = '$dir_id[id]'");
while ($post = mysql_fetch_assoc($q2))
{
unlink(H.'sys/obmen/files/'.$post['id'].'.dat');
}
mysql_query("DELETE FROM `obmennik_files` WHERE `id_dir` = '$dir_id[id]'");
mysql_query("DELETE FROM `obmennik_dir` WHERE `id` = '$dir_id[id]' LIMIT 1");
$l=$dir_id['dir_osn'];
msg('Folder successfully removed');
admin_log('Exchange','Delete folder',"Folder '$dir_id[name]' removed");

$dir_id=mysql_fetch_assoc(mysql_query("SELECT * FROM `obmennik_dir` WHERE `dir` = '/$l' OR `dir` = '$l/' OR `dir` = '$l' LIMIT 1"));
$id_dir=$dir_id['id'];

}



if (user_access('obmen_dir_edit') && isset($_GET['act']) && $_GET['act']=='mesto' && isset($_GET['ok']) && isset($_POST['dir_osn']) && $l!='/')
{
if ($_POST['dir_osn']==NULL)
$err= "Invalid select path";
else
{

$q=mysql_query("SELECT * FROM `obmennik_dir` WHERE `dir_osn` like '$l%'");
while ($post = mysql_fetch_assoc($q))
{
$new_dir_osn=eregi_replace("^$l/",$_POST['dir_osn'],$post['dir_osn']).$dir_id['name'].'/';
$new_dir=$new_dir_osn.$post['name'];
mysql_query("UPDATE `obmennik_dir` SET `dir`='$new_dir/', `dir_osn`='$new_dir_osn' WHERE `id` = '$post[id]' LIMIT 1");
}

$l=$_POST['dir_osn'];

mysql_query("UPDATE `obmennik_dir` SET `dir`='".$l."$dir_id[name]/', `dir_osn`='".$l."' WHERE `id` = '$dir_id[id]' LIMIT 1");
admin_log('Exchange','Change folder',"Folder '$dir_id[name]' moved");
msg('Folders successfully moved');
$dir_id=mysql_fetch_assoc(mysql_query("SELECT * FROM `obmennik_dir` WHERE `id` = '$dir_id[id]' LIMIT 1"));
$id_dir=$dir_id['id'];

}
}


if (isset($access['obm_dir_rename']) && isset($_GET['act']) && $_GET['act']=='rename' && isset($_GET['ok']) && isset($_POST['name']) && $l!=NULL)
{

if ($_POST['name']==NULL)
$err= "Enter the folder name";
else
{

$newdir=retranslit(esc($_POST['name'],1));

if (!isset($err)){
if ($l!='/')$l.='/';
$downpath=eregi_replace('[^/]*/$', NULL, $l);




mysql_query("UPDATE `obmennik_dir` SET `name`='".esc($_POST['name'],1)."' WHERE `dir` = '/$l' OR `dir` = '$l/' OR `dir` = '$l' LIMIT 1");
msg('Folder is renamed successfully');
admin_log('Exchange','Change folder',"Folder '$dir_id[name]' renamed to '".esc($_POST['name'],1)."'");

$l=$downpath.$newdir;
$dir_id=mysql_fetch_assoc(mysql_query("SELECT * FROM `obmennik_dir` WHERE `dir` = '/$l' OR `dir` = '$l/' OR `dir` = '$l' LIMIT 1"));
$id_dir=$dir_id['id'];
}


}
}


if (user_access('obmen_dir_create') && isset($_GET['act']) && $_GET['act']=='mkdir' && isset($_GET['ok']) && isset($_POST['name']))
{

if ($_POST['name']==NULL)
$err= "Enter the folder name";
else
{
$newdir=retranslit(esc($_POST['name'],1));


if (isset($_POST['upload']) && $_POST['upload']=='1')$upload=1; else $upload=0;


if (!isset($_POST['ras']) || $_POST['ras']==NULL)
{
$upload=0;
}
$size=0;
if ($upload==1 && isset($_POST['size']) && isset($_POST['mn']))
{
$size=intval($_POST['size'])*intval($_POST['mn']);
if ($upload_max_filesize<$size)$size=$upload_max_filesize;
}
else $upload=0;


$ras=esc($_POST['ras'],1);


if (!isset($err)){
if ($l!='/')$l.='/';
mysql_query("INSERT INTO `obmennik_dir` (`name` , `ras` , `maxfilesize` , `dir` , `dir_osn` , `upload` ) 
VALUES ('".esc($_POST['name'],1)."', '$ras', '$size', '".$l."$newdir/', '".$l."', '$upload')");
msg('Folder "'.esc($_POST['name'],1).'" successfully created');
admin_log('Exchange','Create folder',"New folder '".esc($_POST['name'],1)."'");
}
}
}









if (user_access('obmen_dir_edit') && isset($_GET['act']) && $_GET['act']=='set' && isset($_GET['ok']))
{



if (isset($_POST['upload']) && $_POST['upload']=='1')$upload=1; else $upload=0;


if (!isset($_POST['ras']) || $_POST['ras']==NULL)
{
$upload=0;
}
$size=0;
if ($upload==1 && isset($_POST['size']) && isset($_POST['mn']))
{
$size=intval($_POST['size'])*intval($_POST['mn']);
if ($upload_max_filesize<$size)$size=$upload_max_filesize;
}
else $upload=0;


$ras=esc($_POST['ras'],1);


if (!isset($err)){
if ($l!='/')$l.='/';
mysql_query("UPDATE `obmennik_dir` SET `ras`='$ras', `maxfilesize`='$size', `upload`='$upload' WHERE `id` = '$dir_id[id]'");
msg('Settings successfully adopted');
admin_log('Exchange','Change folder',"Change folder option '$dir_id[name]'");
$dir_id=mysql_fetch_assoc(mysql_query("SELECT * FROM `obmennik_dir` WHERE `id` = '$dir_id[id]' LIMIT 1"));
$id_dir=$dir_id['id'];
}
}



?>