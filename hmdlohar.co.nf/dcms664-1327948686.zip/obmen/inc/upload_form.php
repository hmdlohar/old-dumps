<?
if ($dir_id['upload']==1){




if (isset($_GET['act']) && $_GET['act']=='upload' && $l!='/')
{
if (!isset($set['obmen_limit_up']) || $set['obmen_limit_up']<=$user['balls']){
echo "<form class='foot' enctype=\"multipart/form-data\" action='?act=upload&amp;ok&amp;page=$page' method=\"post\">";
echo "File:<br />\n";
echo "<input name='file' type='file' maxlength='$dir_id[maxfilesize]' /><br />\n";
echo "Screenshot:<br />\n";
echo "<input name='screen' type='file' accept='image/*' /><br />\n";
echo "Description:<br />\n";
echo "<textarea name='opis'></textarea><br />\n";
echo "<input class=\"submit\" type=\"submit\" value=\"Upload\" /><br />\n";
echo "*Permision is granted to upload files formats: $dir_id[ras]<br />\n";
echo "Up to.: ".size_file($dir_id['maxfilesize'])."<br />\n";
echo "&laquo;<a href='?'>Cancel</a><br />\n";
echo "</form>";
}
else
{
echo "Upload file in shared folder can only to users who have collected $set[obmen_limit_up] and more points<br />\n";
}
}



echo "<div class=\"foot\">\n";
echo "&raquo;<b><a href='?act=upload&amp;page=$page'>Upload File</a></b><br />\n";
echo "</div>\n";
}
?>