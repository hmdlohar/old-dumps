<?
echo 'Size: '.size_file($size)."<br />\n";

$jfile=$name;


$media = mysql_fetch_assoc(mysql_query("SELECT * FROM `media_info` WHERE `file` = '".my_esc($jfile)."' AND `size` = '$size' LIMIT 1"));
if ($media!=NULL)
{
echo 'Resolution: '.$media['wh']."px<br />\n";
echo 'Codec: '.$media['codec']."<br />\n";
echo 'Duration: '.$media['lenght']."<br />\n";
echo "Bitrate: ".$media['bit']." KBPS<br />\n";
}
elseif (class_exists('ffmpeg_movie')){
$media = new ffmpeg_movie($file);


echo 'Resolution: '. $media->GetFrameWidth().'x'.$media->GetFrameHeight()."px<br />\n";
echo 'Codec: '.$media->getVideoCodec()."<br />\n";

if (intval($media->getDuration())>3599)
echo 'Duration: '.intval($media->getDuration()/3600).":".date('s',fmod($media->getDuration()/60,60)).":".date('s',fmod($media->getDuration(),3600))."<br />\n";
elseif (intval($media->getDuration())>59)
echo 'Duration: '.intval($media->getDuration()/60).":".date('s',fmod($media->getDuration(),60))."<br />\n";
else
echo 'Duration: '.intval($media->getDuration())." sec<br />\n";
echo "BitRate: ".ceil(($media->getBitRate())/1024)." KBPS<br />\n";
if (intval($media->getDuration())>3599)
mysql_query("INSERT INTO `media_info` (`file`, `size`, `lenght`, `bit`, `codec`, `wh`) values('".my_esc($jfile)."', '$size', '".intval($media->getDuration()/3600).":".date('s',fmod($media->getDuration()/60,60)).":".date('s',fmod($media->getDuration(),3600))."', '".ceil(($media->getBitRate())/1024)."', '".$media->getVideoCodec()."', '".$media->GetFrameWidth().'x'.$media->GetFrameHeight()."')");
elseif (intval($media->getDuration())>59)
mysql_query("INSERT INTO `media_info` (`file`, `size`, `lenght`, `bit`, `codec`, `wh`) values('".my_esc($jfile)."', '$size', '".intval($media->getDuration()/60).":".date('s',fmod($media->getDuration(),60))."', '".ceil(($media->getBitRate())/1024)."', '".$media->getVideoCodec()."', '".$media->GetFrameWidth().'x'.$media->GetFrameHeight()."')");
else
mysql_query("INSERT INTO `media_info` (`file`, `size`, `lenght`, `bit`, `codec`, `wh`) values('".my_esc($jfile)."', '$size', '".intval($media->getDuration())." sec', '".ceil(($media->getBitRate())/1024)."', '".$media->getVideoCodec()."', '".$media->GetFrameWidth().'x'.$media->GetFrameHeight()."')");
}
else echo 'Added: '.vremja($post['time'])."<br />\n";


?>