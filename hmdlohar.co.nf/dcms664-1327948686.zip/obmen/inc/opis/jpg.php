<?



if (function_exists('getimagesize'))
{
$img_size=getimagesize($file);
echo "Resolution: $img_size[0]*$img_size[1] px.<br />\n";

}

echo 'Size: '.size_file($size)."<br />\n";
echo 'Added: '.vremja($post['time'])."<br />\n";
?>