<?
echo "Playlist<br />\n";
echo 'Size: '.size_file($size)."<br />\n";
echo 'Added: '.vremja(filectime($dir_loads.'/'.$dirlist[$i]))."<br />\n";
?>