<?
include_once '../sys/inc/start.php';
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/loads.php';
include_once '../sys/inc/user.php';



$set['title']='Downloads - Search Files'; // заголовок страницы
include_once '../sys/inc/thead.php';
title();
aut();

$search=NULL;
if (isset($_SESSION['search']))$search=$_SESSION['search'];
if (isset($_POST['search']))$search=$_POST['search'];
$_SESSION['search']=$search;

$search=ereg_replace("( ){2,}"," ",$search);
$search=ereg_replace("^( ){1,}|( ){1,}$","",$search);



if (isset($_GET['go']) && $search!=NULL)
{
$search_a=explode(' ', $search);

for($i=0;$i<count($search_a);$i++)
{
$search_a2[$i]='<span class="search_c">'.stripcslashes(htmlspecialchars($search_a[$i])).'</span>';
$search_a[$i]=stripcslashes(htmlspecialchars($search_a[$i]));
}

$q_search=str_replace('%','',$search);
$q_search=str_replace(' ','%',$q_search);
$k_post=mysql_result(mysql_query("SELECT COUNT(*) FROM `loads_list` WHERE `name` like '%".mysql_escape_string($q_search)."%'"),0);
$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];
if ($k_post==0)echo "<div class=\"post\">\nSorry, your query returns no results</div>\n";
$q=mysql_query("SELECT * FROM `loads_list` WHERE `name` like '%".mysql_escape_string($q_search)."%' ORDER BY `loads` DESC LIMIT $start, $set[p_str]");
$i=0;

echo "<table class='post'>\n";

while ($post = mysql_fetch_assoc($q))
{
$l=$post['path'];
if (function_exists('iconv'))$l=iconv('utf-8', 'windows-1251', $l);
$dir_loads="../sys/loads/files/$l";


$dirlist[$i]=$post['name'];
if (function_exists('iconv'))$dirlist[$i]=iconv('utf-8', 'windows-1251', $dirlist[$i]);

if (!is_file($dir_loads.'/'.$dirlist[$i]))
{
continue;

}


$ras=strtolower(eregi_replace('^.*\.', NULL, $dirlist[$i]));
$name=eregi_replace('\.[^\.]*$', NULL, $dirlist[$i]);
if (is_file($dir_loads.'/'.$dirlist[$i].'.name'))
$name2=trim(esc(file_get_contents($dir_loads.'/'.$dirlist[$i].'.name')));
elseif (function_exists('iconv'))
$name2=iconv('windows-1251', 'utf-8', $name);
else $name2=$name;
$size=filesize($dir_loads.'/'.$dirlist[$i]);

echo "   <tr>\n";


if ($set['set_show_icon']==2){

echo "  <td rowspan='2' class='icon48'>\n";
include 'inc/icon48.php';
echo "  </td>\n";
}
elseif ($set['set_show_icon']==1){

echo "  <td class='icon14'>\n";
include 'inc/icon14.php';
echo "  </td>\n";
}



echo "  <td class='p_t'>\n";
echo "<a href='index.php?".url("d=$l&amp;f=$dirlist[$i]&amp;page=$page")."'>$name2.$ras</a>".file_new($dir_loads.'/'.$dirlist[$i])."\n";
echo "  </td>\n";
echo "   </tr>\n";
echo "   <tr>\n";
if ($set['set_show_icon']==1)echo "  <td class='p_m' colspan='2'>\n"; else echo "  <td class='p_m'>\n";
echo "Path: ".rupath($l,'../sys/loads/files')."<br />\n";
include 'inc/opis.php';
echo "  </td>\n";
echo "   </tr>\n";





$i++;
}
echo "</table>\n";
if ($k_page>1)str("search.php?go&amp;",$k_page,$page); // Вывод страниц
}
else
echo "What you look for? ;)";


echo "<form method=\"post\" action=\"search.php?go\" class=\"search\">\n";
$search=stripcslashes(htmlspecialchars($search));
echo "<input type=\"text\" name=\"search\" maxlength=\"64\" value=\"$search\" /><br />\n";
echo "<input type=\"submit\" value=\"Search\" />\n";
echo "</form>\n";
echo "<div class=\"foot\">\n";
echo "&laquo;<a href='/loads/'>Downloads</a><br />\n";
echo "</div>\n";
include_once '../sys/inc/tfoot.php';
?>