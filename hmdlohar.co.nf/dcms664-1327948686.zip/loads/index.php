<?
include_once '../sys/inc/start.php';
if (!isset($_GET['f']) || !isset($_GET['down']))
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/loads.php';
include_once '../sys/inc/user.php';

$set['title']='Download';

$_SESSION['page']=1;


if (isset($_GET['d']) && esc($_GET['d'])!=NULL)
{
$l=ereg_replace("\.{2,}",NULL,esc(urldecode($_GET['d'])));
$l=ereg_replace("\./|/\.",NULL,$l);
$l=ereg_replace("(/){1,}","/",$l);
$l=ereg_replace("(^(/){1,})|((/){1,}$)","",$l);
$dir_loads="../sys/loads/files/$l";
}
if (!isset($dir_loads) || !is_dir($dir_loads))
{
$dir_loads='../sys/loads/files';
$l=NULL;
}


if (isset($_GET['f']) && is_file($dir_loads.'/'.ereg_replace(".*/",'',urldecode($_GET['f']))) && isset($_GET['komm']))
{
$file=ereg_replace(".*/",NULL,urldecode($_GET['f'])); // получение имени файла
$name=eregi_replace('\.[^\.]*$', NULL, $file); // имя файла без расширения
$ras=strtolower(eregi_replace('^.*\.', NULL, $file)); // расширение (в нижнем регистре)
$size=filesize($dir_loads.'/'.$file);
if (is_file($dir_loads.'/'.$file.'.name'))
$name2=trim(esc(file_get_contents($dir_loads.'/'.$file.'.name')));
elseif (function_exists('iconv'))
$name2=iconv('windows-1251', 'utf-8', $name);
else $name2=$name;
include 'inc/komm.php';
exit;
}
elseif (isset($_GET['f']) && is_file($dir_loads.'/'.ereg_replace(".*/",'',urldecode($_GET['f']))) && isset($_GET['down']))
{
include_once '../sys/inc/downloadfile.php';
$file=ereg_replace(".*/",NULL,urldecode($_GET['f'])); // получение имени файла

$name=eregi_replace('\.[^\.]*$', NULL, $file); // имя файла без расширения
$ras=strtolower(eregi_replace('^.*\.', NULL, $file)); // расширение (в нижнем регистре)

$l2=$l;
if (function_exists('iconv'))$l2=iconv('windows-1251', 'utf-8', $l2);


$jfile=eregi_replace('\.jad$', '.jar', $file);

$size=filesize($dir_loads.'/'.$jfile);
if (function_exists('iconv'))$jfile=iconv('windows-1251', 'utf-8', $jfile);

$path=(function_exists('iconv'))?iconv('windows-1251', 'utf-8', $l):$l;
$path='/'.eregi_replace('^/+|/+$', null, $path).'/';
$loads=mysql_fetch_assoc(mysql_query("SELECT * FROM `loads_list` WHERE `name` = '$jfile' AND `size` = '$size' AND `path` = '".my_esc($path)."' LIMIT 1"));

if (!isset($set['downloads_select']) || $set['downloads_select']=='0')
{
if ($loads!=NULL)
mysql_query("UPDATE `loads_list` SET `loads` = '".($loads['loads']+1)."' WHERE `name` = '$jfile' AND `size` = '$size' AND `path` = '".my_esc($path)."' LIMIT 1");
else
mysql_query("INSERT INTO `loads_list` (`name`, `size`,  `path`, `time`, `loads`) values('".my_esc($jfile)."', '$size', '".my_esc($path)."', '".filectime($dir_loads.'/'.$jfile)."', '1')");
DownloadFile($dir_loads.'/'.$file, basename($dir_loads.'/'.$file), ras_to_mime($ras));
}
else
{
include 'inc/download.php';
}


exit;
}
elseif (isset($_GET['f']) && is_file($dir_loads.'/'.ereg_replace(".*/",'',urldecode($_GET['f']))))
{
$file=ereg_replace(".*/",NULL,urldecode($_GET['f'])); // получение имени файла
$name=eregi_replace('\.[^\.]*$', NULL, $file); // имя файла без расширения
$ras=strtolower(eregi_replace('^.*\.', NULL, $file)); // расширение (в нижнем регистре)
$size=filesize($dir_loads.'/'.$file);




if (is_file($dir_loads.'/'.$file.'.name'))
$name2=trim(esc(file_get_contents($dir_loads.'/'.$file.'.name')));
elseif (function_exists('iconv'))
$name2=iconv('windows-1251', 'utf-8', $name);
else $name2=$name;

$set['title']="Download - $name2 download";
include_once '../sys/inc/thead.php';
title();
include 'inc/admin_act_file.php';

err();
aut();
$tmp_sess=null;
if(is_file("inc/file/$ras.php"))include "inc/file/$ras.php";
else
include_once 'inc/file.php';
if (isset($_GET['page']) && (is_numeric($_GET['page']) || $_GET['page']=='end'))$_SESSION['page']=$_GET['page'];else $_SESSION['page']=1;

echo "<div class='foot'>";
if ($l!=NULL){
echo "<a href='?'>Download</a> &gt; ".rupath($l,'../sys/loads/files')."<br />\n";
}




echo "<a href='?".url("d=$l&amp;page=$_SESSION[page]")."'>Back</a><br />\n";

echo "</div>\n";

include 'inc/admin_form_file.php';


include_once '../sys/inc/tfoot.php';
}

include_once 'inc/dir.php';



?>