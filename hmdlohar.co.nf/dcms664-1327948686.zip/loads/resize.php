<?
include_once '../sys/inc/start.php';
//include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/loads.php';
include_once '../sys/inc/user.php';
if (!isset($_GET['f']) || eregi('^\.|^http://',$_GET['f']))
exit;
$path=ereg_replace('/[^/]*$', NULL, '../sys/loads/files/'.$_GET['f']);





$file=ereg_replace(".*/",NULL,urldecode($_GET['f'])); // получение имени файла

$name=eregi_replace('\.[^\.]*$', NULL, $file); // имя файла без расширения
$ras=strtolower(eregi_replace('^.*\.', NULL, $file)); // расширение (в нижнем регистре)



$l2=$l=str_replace('../sys/loads/files/', NULL, $path);
if (function_exists('iconv'))$l2=iconv('windows-1251', 'utf-8', $l2);
$jfile=eregi_replace('\.jad$', '.jar', $file);

$size=filesize($path.'/'.$file);
if (function_exists('iconv'))$jfile=iconv('windows-1251', 'utf-8', $jfile);

$path2=(function_exists('iconv'))?iconv('windows-1251', 'utf-8', $l):$l;
$path2='/'.eregi_replace('^/+|/+$', null, $path2).'/';
$loads=mysql_fetch_assoc(mysql_query("SELECT * FROM `loads_list` WHERE `name` = '$jfile' AND `size` = '$size' AND `path` = '".my_esc($path2)."' LIMIT 1"));



if (!isset($set['downloads_select']) || $set['downloads_select']=='0' || ereg('PNG|GIF|JPE?G',$file) || isset($_GET['tmp']) && @eregi('^[A-z0-9]{32}$',$_GET['tmp']))
{
if (!isset($set['downloads_select']) || $set['downloads_select']=='0' || ereg('PNG|GIF|JPE?G',$file) || $tmp_file=@file_get_contents(H.'sys/tmp/down_'.$_GET['tmp'].'.dat'))
{
if (!isset($set['downloads_select']) || $set['downloads_select']=='0' || ereg('PNG|GIF|JPE?G',$file) || $tmp_array=@unserialize($tmp_file))
{

if (!isset($set['downloads_select']) || $set['downloads_select']=='0' || ereg('PNG|GIF|JPE?G',$file))
{
$tmp_array[0]=array('l'=>$l,'file'=>$file,'time'=>$time);
}

for($iiii=0;$iiii<sizeof($tmp_array);$iiii++)
{

if (!isset($set['downloads_select']) || $set['downloads_select']=='0' || ereg('PNG|GIF|JPE?G',$file) || $tmp_array[$iiii]['time']>$time-3600*2 && $tmp_array[$iiii]['l']==$l && $tmp_array[$iiii]['file']==$jfile  && $tmp_array[$iiii]['ip']==$iplong)
{

if (!ereg('PNG|GIF|JPE?G',$file)){
if ($loads!=NULL)
mysql_query("UPDATE `loads_list` SET `loads` = '".($loads['loads']+1)."' WHERE `name` = '$jfile' AND `size` = '$size' AND `path` = '".my_esc($path2)."' LIMIT 1");
else
mysql_query("INSERT INTO `loads_list` (`name`, `size`,  `path`, `time`, `loads`) values('".my_esc($jfile)."', '$size', '".my_esc($path2)."', '".filectime($path.'/'.$file)."', '1')");
}


$file=ereg_replace('.*/', NULL, $_GET['f']);
$name=ereg_replace('\.[^\.]*$', NULL, $jfile); // имя файла без расширения
$ras=strtolower(ereg_replace('^.*\.', NULL, $file)); // расширение (в нижнем регистре)


if (!isset($_GET['w']) || !is_numeric($_GET['w']) || !isset($_GET['h']) || !is_numeric($_GET['h']))
{
$size=getimagesize($path.'/'.$file);
$w=$size[0];$h=$size[1];
}
else
{
$w=intval($_GET['w']);if ($w<16)$w=16;
$h=intval($_GET['h']);if ($h<16)$h=16;
}


if (!ereg('^(gif|jpe?g|png)$',$ras) || !is_file($path.'/'.$file))exit;

if ($ras=='jpg' || $ras=='jpeg')
$img=imagecreatefromjpeg($path.'/'.$file);
elseif ($ras=='gif')
$img=imagecreatefromgif($path.'/'.$file);
elseif ($ras=='png')
$img=imagecreatefrompng($path.'/'.$file);
else exit;

$img_x=imagesx($img);
$img_y=imagesy($img);

$x_ratio = $w/$img_x; 
$y_ratio = $h/$img_y; 

if (($img_x <= $w) && ($img_y <= $h))
{
$dstW = $img_x; 
$dstH = $img_y; 
} 
else if (($x_ratio * $img_y) < $h)
{ 
$dstH = ceil($x_ratio * $img_y); 
$dstW = $w; 
} 
else
{ 
$dstW = ceil($y_ratio * $img_x); 
$dstH = $h; 
} 




$screen=ImageCreateTrueColor($dstW, $dstH);
imagecopyresampled($screen, $img, 0, 0, 0, 0, $dstW, $dstH, $img_x, $img_y);
imagedestroy($img);

$screen=img_copyright($screen); // наложение копирайта



if ($ras=='jpg' || $ras=='jpeg')
{
header("Content-type: image/jpeg"); 
header("Content-Disposition: attachment; filename=$name.jpg");
ImageJpeg ($screen, '../sys/tmp/'.$sess, 100);
header("Accept-Ranges: bytes");
header("Content-length: ".filesize('../sys/tmp/'.$sess)."");
unlink('../sys/tmp/'.$sess);
ImageJpeg ($screen, null, 100);
}
elseif ($ras=='gif')
{
header("Content-type: image/gif");
header("Content-Disposition: attachment; filename=$name.gif");
Imagegif ($screen, '../sys/tmp/'.$sess);
header("Accept-Ranges: bytes");
header("Content-length: ".filesize('../sys/tmp/'.$sess)."");
unlink('../sys/tmp/'.$sess);
ImageGif ($screen);
}
elseif ($ras=='png')
{
//imagecolortransparent($screen,0);
header("Content-type: image/png");
header("Content-Disposition: attachment; filename=$name.png");
Imagepng ($screen, '../sys/tmp/'.$sess);
header("Accept-Ranges: bytes");
header("Content-length: ".filesize('../sys/tmp/'.$sess)."");
unlink('../sys/tmp/'.$sess);
ImagePng ($screen);
}
imagedestroy($screen);
exit;




}


}
}
}
}

$set['title']='Downloading Error';
include_once '../sys/inc/thead.php';
title();
$err[]='Invalid link or a time came';
err();
aut();

echo "<a href='/loads/?d=$l&amp;f=$file'>File descriptions</a><br />\n";

include_once '../sys/inc/tfoot.php';


?>