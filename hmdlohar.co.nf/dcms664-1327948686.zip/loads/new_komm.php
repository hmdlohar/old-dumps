<?
include_once '../sys/inc/start.php';
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/loads.php';
include_once '../sys/inc/user.php';

$set['title']='Downloads Comments';

include_once '../sys/inc/thead.php';
title();
err();
aut(); // форма авторизации


$k_post=mysql_result(mysql_query("SELECT COUNT(DISTINCT `loads_list`.`name`,`loads_list`.`size`) FROM `loads_komm` LEFT JOIN `loads_list` ON `loads_komm`.`file` = `loads_list`.`name` AND `loads_komm`.`size` = `loads_list`.`size` WHERE `loads_komm`.`time` > '".($time-60*60*24)."'"), 0);
$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];
echo "<table class='post'>\n";

if ($k_post==0){
echo "   <tr>\n";
echo "  <td class='p_t'>\n";
echo "No files with new comments\n";
echo "  </td>\n";
echo "   </tr>\n";
}
$q=mysql_query("SELECT `loads_list`.`name`, `loads_list`.`path`, `loads_list`.`size` FROM `loads_komm` LEFT JOIN `loads_list` ON `loads_komm`.`file` = `loads_list`.`name` AND `loads_komm`.`size` = `loads_list`.`size` WHERE `loads_komm`.`time` > '".($time-60*60*24)."' GROUP BY `loads_list`.`name`,`loads_list`.`size` ORDER BY `loads_komm`.`time` DESC LIMIT $start, $set[p_str]");
while ($post = mysql_fetch_assoc($q))
{
$i=passgen();
echo "   <tr>\n";
$l=$post['path'];
$l=ereg_replace("\./|/\.",NULL,$l);
$l=ereg_replace("(/){1,}","/",$l);
$l=ereg_replace("(^(/){1,})|((/){1,}$)","",$l);


$dir_loads=H.'sys/loads/files/'.$l;
$dirlist[$i]=$post['name'];
if (function_exists('iconv'))$dirlist[$i]=iconv('utf-8', 'windows-1251', $dirlist[$i]);
$ras=strtolower(eregi_replace('^.*\.', NULL, $dirlist[$i]));
$name=eregi_replace('\.[^\.]*$', NULL, $dirlist[$i]);

if (is_file($dir_loads.'/'.$dirlist[$i].'.name'))
$name2=trim(esc(file_get_contents($dir_loads.'/'.$dirlist[$i].'.name')));
elseif (function_exists('iconv'))
$name2=iconv('windows-1251', 'utf-8', $name);
else $name2=$name;

$name2=htmlspecialchars($name2);

$size=$post['size'];




if ($set['set_show_icon']==2){

echo "  <td rowspan='2' class='icon48'>\n";
include 'inc/icon48.php';
echo "  </td>\n";
}
elseif ($set['set_show_icon']==1){

echo "  <td class='icon14'>\n";
include 'inc/icon14.php';
echo "  </td>\n";
}

echo "  <td class='p_t'>\n";


if ($set['echo_rassh']==1)$ras2=".$ras";else $ras2=NULL;

echo "<a href='index.php?komm&amp;d=".urlencode("$l")."&amp;f=".urlencode("$dirlist[$i]")."&amp;page=$page'>$name2$ras2</a> (".mysql_result(mysql_query("SELECT COUNT(*) FROM `loads_komm` WHERE `file` = '$post[name]' AND `size` = '$post[size]' AND `time` > '".($time-60*60*24)."'"), 0)." new)\n";
echo "  </td>\n";
echo "   </tr>\n";
echo "   <tr>\n";
if ($set['set_show_icon']==1)echo "  <td class='p_m' colspan='2'>\n"; else echo "  <td class='p_m'>\n";
include 'inc/opis.php';
echo "  </td>\n";
echo "   </tr>\n";







}
echo "</table>\n";

if ($k_page>1)str('?',$k_page,$page); // Вывод страниц
echo "<div class=\"foot\">\n";
echo "&laquo;<a href='/loads/'>Downloads</a><br />\n";
echo "</div>\n";
include_once '../sys/inc/tfoot.php';
?>