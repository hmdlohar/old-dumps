<?

if (function_exists('getimagesize'))
{
$img_size=getimagesize($dir_loads.'/'.$dirlist[$i]);
echo "Resolution: $img_size[0]*$img_size[1] px.<br />\n";

}

echo 'Size: '.size_file($size)."<br />\n";
echo 'Added: '.vremja(filectime($dir_loads.'/'.$dirlist[$i]))."<br />\n";
?>