<?
include 'inc/ff_opis.php';
?>