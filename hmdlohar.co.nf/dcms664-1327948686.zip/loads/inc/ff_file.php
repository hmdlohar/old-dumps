<?
if ($set['web'] && $ras=='flv' && (!isset($set['downloads_select']) || $set['downloads_select']=='0')){
?>
<center><p id='preview'>Install Flash Player</p>
<script type='text/javascript' src='/sys/swfobject.js'></script>
<script type='text/javascript'>
var s1 = new SWFObject('/sys/player.swf','player','350','300','9');
s1.addParam('allowfullscreen','true');
s1.addParam('allowscriptaccess','always');
//s1.addParam('flashvars','file=".$_GET['id'].".flv&amp;image=".$_GET['id'].".jpg');
s1.addParam('flashvars','file=<? echo "/loads/down/".url2("$l/$file")."&amp;image=/sys/loads/screens/128/$size.$name.gif"; ?>');
s1.write('preview');
</script>
</center>
<br />
<?
}
elseif (is_file($dir_loads.'/'.$file.'.GIF'))
echo "<img src=\"resize.php?".url("f=$l/$file.GIF")."&amp;w=128&amp;h=128\" alt=\"Скрин...\" /><br />\n";
elseif (is_file($dir_loads.'/'.$file.'.JPG'))
echo "<img src=\"resize.php?".url("f=$l/$file.JPG")."&amp;w=128&amp;h=128\" alt=\"Скрин...\" /><br />\n";
elseif (is_file($dir_loads.'/'.$file.'.PNG'))
echo "<img src=\"resize.php?".url("f=$l/$file.PNG")."&amp;w=128&amp;h=128\" alt=\"Скрин...\" /><br />\n";
elseif (is_file(H."sys/loads/screens/128/$size.$name.gif"))
{
if (function_exists('iconv'))
echo "<img src='".iconv('windows-1251', 'utf-8',"/sys/loads/screens/128/$size.$name.gif")."' alt='scr...' /><br />\n";

else
echo "<img src='/sys/loads/screens/128/$size.$name.gif' alt='scr...' /><br />\n";
}
elseif (class_exists('ffmpeg_movie')){
$media = new ffmpeg_movie(realpath($dir_loads.'/'.$file));
$k_frame=intval($media->getFrameCount());

$w = $media->GetFrameWidth();
$h = $media->GetFrameHeight();
$k_kadr=6;
for ($i=0;$i<$k_kadr;$i++)
{
$ff_frame = $media->getFrame(intval($k_frame/($k_kadr/($i+1))));
if ($ff_frame) {
$gd_image = $ff_frame->toGDImage();
if ($gd_image) {
$des_img = imagecreatetruecolor(128, 128);
$s_img = $gd_image;
imagecopyresampled($des_img, $s_img, 0, 0, 0, 0, 128, 128, $w, $h);
$des_img=img_copyright($des_img); // копирайт
$frames[$i]=H."sys/tmp/frame_$sess.$i.gif";
imagegif($des_img,$frames[$i]);
chmod($frames[$i], 0777);
$framed [$i] = 60;
imagedestroy($des_img);
imagedestroy($s_img);
}
}
}
include_once H.'sys/inc/gifencoder.php';
$gif = @new GIFEncoder	($frames,$framed,0,2,0, 0, 0,"url");

$screen=$gif->GetAnimation();
file_put_contents(H."sys/loads/screens/128/$size.$name.gif", $screen);
@chmod(H."sys/loads/screens/128/$size.$name.gif",0777);

for ($i=0;$i<$k_kadr;$i++)
{
unlink(H."sys/tmp/frame_$sess.$i.gif");
}


if ($screen!=NULL){
if (function_exists('iconv'))
echo "<img src='".iconv('windows-1251', 'utf-8',"/sys/loads/screens/128/$size.$name.gif")."' alt='scr...' /><br />\n";
else
echo "<img src='/sys/loads/screens/128/$size.$name.gif' alt='scr...' /><br />\n";

}
}




if (class_exists('ffmpeg_movie')){
$media = new ffmpeg_movie(realpath($dir_loads.'/'.$file));

echo 'Resolution: '. $media->GetFrameWidth().'x'.$media->GetFrameHeight()."px<br />\n";
echo 'Frame Rate: '.$media->getFrameRate()."<br />\n";
echo 'Codec (video): '.$media->getVideoCodec()."<br />\n";

if (intval($media->getDuration())>3599)
echo 'Duration: '.intval($media->getDuration()/3600).":".date('s',fmod($media->getDuration()/60,60)).":".date('s',fmod($media->getDuration(),3600))."<br />\n";
elseif (intval($media->getDuration())>59)
echo 'Duration: '.intval($media->getDuration()/60).":".date('s',fmod($media->getDuration(),60))."<br />\n";
else
echo 'Duration: '.intval($media->getDuration())." sec<br />\n";
echo "Bitrate: ".ceil(($media->getBitRate())/1024)." KBPS<br />\n";

}
echo "Added: ".vremja(filectime($dir_loads.'/'.$file))."<br />\n";


if (is_file($dir_loads.'/'.$file.'.opis')) // проверка описания
echo output_text(file_get_contents($dir_loads.'/'.$file.'.opis'))."<br />\n";
elseif (is_file($dir_loads.'/'.$file.'.txt')) // проверка описания в txt файле
echo output_text(file_get_contents($dir_loads.'/'.$file.'.txt'))."<br />\n";

echo "Size: ".size_file(filesize($dir_loads.'/'.$file))."<br />\n";
if (class_exists('ffmpeg_movie') && isset($user) && $user['level']==4)include 'inc/convert.php';
include 'inc/add_file_loads.php'; // обработа вывода ссылки
echo "<a href=\"?komm&amp;".url("d=$l&amp;f=$file")."\">Comments</a> (".k_komm($file,$size).")<br />\n";
?>