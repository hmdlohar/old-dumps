<?
if (is_file(H."sys/loads/screens/48/$size.$name.gif"))
{
if (function_exists('iconv'))
echo "<img src='".iconv('windows-1251', 'utf-8',"/sys/loads/screens/48/$size.$name.gif")."' alt='scr...' /><br />\n";
else
echo "<img src='/sys/loads/screens/48/$size.$name.gif' alt='scr...' />\n";
}
elseif (class_exists('ffmpeg_movie')){
$media = new ffmpeg_movie(realpath($dir_loads.'/'.$dirlist[$i]));
$k_frame=intval($media->getFrameCount());

$w = $media->GetFrameWidth();
$h = $media->GetFrameHeight();
$ff_frame = $media->getFrame(intval($k_frame/2));
if ($ff_frame) {
$gd_image = $ff_frame->toGDImage();
if ($gd_image) {
$des_img = imagecreatetruecolor(48, 48);
$s_img = $gd_image;
imagecopyresampled($des_img, $s_img, 0, 0, 0, 0, 48, 48, $w, $h);
imagegif($des_img,H."sys/loads/screens/48/$size.$name.gif");
chmod(H."sys/loads/screens/48/$size.$name.gif", 0777);
imagedestroy($des_img);
imagedestroy($s_img);




if (function_exists('iconv'))
echo "<img src='".iconv('windows-1251', 'utf-8',"/sys/loads/screens/48/$size.$name.gif")."' alt='scr...' /><br />\n";
else
echo "<img src='/sys/loads/screens/48/$size.$name.gif' alt='scr...' /><br />\n";

}
}
}
elseif (is_file(H.'style/themes/'.$set['set_them'].'/loads/48/'.$ras.'.png'))
echo "<img src='/style/themes/$set[set_them]/loads/48/$ras.png' alt='$ras' />\n";
else echo "<img src='/style/themes/$set[set_them]/loads/48/file.png' alt='file' />\n";


?>