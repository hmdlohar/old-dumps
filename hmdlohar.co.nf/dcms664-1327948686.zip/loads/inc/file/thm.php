<?

include_once H.'sys/inc/scrmaker.php';
include_once H.'sys/inc/PEAR.php';
include_once H."sys/inc/tar.php";


if (is_file($dir_loads.'/'.$file.'.GIF'))
echo "<img src=\"resize.php?".url("f=$l/$file.GIF")."&amp;w=128&amp;h=128\" alt=\"Скрин...\" /><br />\n";
elseif (is_file($dir_loads.'/'.$file.'.JPG'))
echo "<img src=\"resize.php?".url("f=$l/$file.JPG")."&amp;w=128&amp;h=128\" alt=\"Скрин...\" /><br />\n";
elseif (is_file($dir_loads.'/'.$file.'.PNG'))
echo "<img src=\"resize.php?".url("f=$l/$file.PNG")."&amp;w=128&amp;h=128\" alt=\"Скрин...\" /><br />\n";
else
{
 make_pre($dir_loads,$file);

if (is_file($dir_loads.'/'.$file.'.GIF'))
echo "<img src=\"resize.php?".url("f=$l/$file.GIF")."&amp;w=128&amp;h=128\" alt=\"Скрин...\" /><br />\n";
elseif (is_file($dir_loads.'/'.$file.'.JPG'))
echo "<img src=\"resize.php?".url("f=$l/$file.JPG")."&amp;w=128&amp;h=128\" alt=\"Скрин...\" /><br />\n";
elseif (is_file($dir_loads.'/'.$file.'.PNG'))
echo "<img src=\"resize.php?".url("f=$l/$file.PNG")."&amp;w=128&amp;h=128\" alt=\"Скрин...\" /><br />\n";
}
$img_size=getimagesize($dir_loads.'/'.$file);
echo "Resolution: $img_size[0]*$img_size[1] px.<br />\n";
echo "Added: ".vremja(filectime($dir_loads.'/'.$file))."<br />\n";


if (is_file($dir_loads.'/'.$file.'.opis')) // проверка описания
echo output_text(file_get_contents($dir_loads.'/'.$file.'.opis'))."<br />\n";
elseif (is_file($dir_loads.'/'.$file.'.txt')) // проверка описания в txt файле
echo output_text(file_get_contents($dir_loads.'/'.$file.'.txt'))."<br />\n";



echo "Size: ".size_file(filesize($dir_loads.'/'.$file))."<br />\n";
include 'inc/add_file_loads.php'; // обработа вывода ссылки
echo "<a href=\"?komm&amp;".url("d=$l&amp;f=$file")."\">Comments</a> (".k_komm($file,$size).")<br />\n";

?>



