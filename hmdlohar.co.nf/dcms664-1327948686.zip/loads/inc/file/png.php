<?


if (is_file(H."sys/loads/screens/128/$size.$name.$ras"))
{
if (function_exists('iconv'))
echo "<img src='/sys/loads/screens/128/".iconv('windows-1251', 'utf-8',"$size.$name.$ras")."' alt='Скрин...' /><br />\n";
else
echo "<img src='/sys/loads/screens/128/$size.$name.$ras' alt='Скрин...' /><br />\n";
}
elseif (function_exists('imagecreatefrompng'))
{

$imgc=imagecreatefrompng($dir_loads.'/'.$file);
$img_x=imagesx($imgc);
$img_y=imagesy($imgc);
if ($img_x==$img_y)
{
$dstW=128; // ширина
$dstH=128; // высота 
}
elseif ($img_x>$img_y)
{
$prop=$img_x/$img_y;
$dstW=128;
$dstH=ceil($dstW/$prop);
}
else
{
$prop=$img_y/$img_x;
$dstH=128;
$dstW=ceil($dstH/$prop);
}

$screen=imagecreatetruecolor($dstW, $dstH);
imagecopyresampled($screen, $imgc, 0, 0, 0, 0, $dstW, $dstH, $img_x, $img_y);
imagedestroy($imgc);
$screen=img_copyright($screen); // копирайт
imagepng($screen,H."sys/loads/screens/128/$size.$name.$ras");
imagedestroy($screen);
echo "<img src='/sys/loads/screens/128/$size.$name.$ras' alt='Скрин...' /><br />\n";
}

if (function_exists('getimagesize'))
{
$img_size=getimagesize($dir_loads.'/'.$file);
echo "Resolution: $img_size[0]*$img_size[1] px.<br />\n";
}

echo "Added: ".vremja(filectime($dir_loads.'/'.$file))."<br />\n";


if (is_file($dir_loads.'/'.$file.'.opis')) // проверка описания
echo output_text(file_get_contents($dir_loads.'/'.$file.'.opis'))."<br />\n";
elseif (is_file($dir_loads.'/'.$file.'.txt')) // проверка описания в txt файле
echo output_text(file_get_contents($dir_loads.'/'.$file.'.txt'))."<br />\n";

echo "Size: ".size_file(filesize($dir_loads.'/'.$file))."<br />\n";
include 'inc/add_file_loads.php'; // обработа вывода ссылки


echo "<a href=\"resize.php?".url("f=$l/$file")."&amp;w=128&amp;h=128&amp;tmp=$tmp_sess\">Download (128*128)</a><br />\n";
echo "<a href=\"resize.php?".url("f=$l/$file")."&amp;w=128&amp;h=160&amp;tmp=$tmp_sess\">Download (128*160)</a><br />\n";
echo "<a href=\"resize.php?".url("f=$l/$file")."&amp;w=132&amp;h=176&amp;tmp=$tmp_sess\">Download (132*176)</a><br />\n";
echo "<a href=\"resize.php?".url("f=$l/$file")."&amp;w=178&amp;h=208&amp;tmp=$tmp_sess\">Download (178*208)</a><br />\n";
echo "<a href=\"resize.php?".url("f=$l/$file")."&amp;w=240&amp;h=320&amp;tmp=$tmp_sess\">Download (240*320)</a><br />\n";



echo "<a href=\"?komm&amp;".url("d=$l&amp;f=$file")."\">Comments</a> (".k_komm($file,$size).")<br />\n";

?>