<?



if (is_file($dir_loads.'/'.$file.'.GIF'))
echo "<img src=\"resize.php?".url("f=$l/$file.GIF")."&amp;w=128&amp;h=128\" alt=\"Скрин...\" /><br />\n";
elseif (is_file($dir_loads.'/'.$file.'.JPG'))
echo "<img src=\"resize.php?".url("f=$l/$file.JPG")."&amp;w=128&amp;h=128\" alt=\"Скрин...\" /><br />\n";
elseif (is_file($dir_loads.'/'.$file.'.PNG'))
echo "<img src=\"resize.php?".url("f=$l/$file.PNG")."&amp;w=128&amp;h=128\" alt=\"Скрин...\" /><br />\n";
else
{


include_once H.'sys/inc/zip.php';
$zip=new PclZip($dir_loads.'/'.$file);
$content = $zip->extract(PCLZIP_OPT_BY_NAME, 'theme_descriptor.xml' ,PCLZIP_OPT_EXTRACT_AS_STRING);
$theme_descriptor=$content[0]['content'];

$p = xml_parser_create();
xml_parse_into_struct($p,$theme_descriptor,$vals,$index);
xml_parser_free($p);

for ($i=0;$i<count($vals);$i++)
{
if ($vals[$i]['tag']=='THEME' && isset ($vals[$i]['attributes']['VERSION']))
{
$ver=$vals[$i]['attributes']['VERSION'];
}


if ($vals[$i]['tag']=='THEME' && isset ($vals[$i]['attributes']['NAME']) && $vals[$i]['attributes']['NAME']!=NULL)
{
file_put_contents($dir_loads.'/'.$file.'.name', $vals[$i]['attributes']['NAME']);
}


}

//echo "Версия: ".$ver."<br />\n";

for ($i=0;$i<count($vals);$i++)
{


if ($ver=='1.1' && $vals[$i]['tag']=='BACKGROUND' && isset ($vals[$i]['attributes']['SRC']))
{
$back=$vals[$i]['attributes']['SRC'];
}
if ($ver=='2.0' && $vals[$i]['tag']=='BACKGROUND' && isset ($vals[$i]['attributes']['GRID_MENU_BG']))
{
$back=$vals[$i]['attributes']['GRID_MENU_BG'];
}


}



if (isset($back)){
//echo "BACKGROUND: ".$back."<br />\n";

$content = $zip->extract(PCLZIP_OPT_BY_NAME, $back ,PCLZIP_OPT_EXTRACT_AS_STRING);
$back_img=imagecreatefromstring($content[0]['content']);
$img=imagecreatetruecolor(imagesx($back_img), imagesy($back_img));

imagecopy($img, $back_img, 0, 0, 0, 0, imagesx($back_img), imagesy($back_img));




for ($i=0;$i<count($vals);$i++)
{
if ($ver=='1.1' && $vals[$i]['tag']=='ICON' && isset ($vals[$i]['attributes']['SRC']) && $vals[$i]['attributes']['SIZE']=='small')
{
$icon_id=$vals[$i]['attributes']['ITEM_ID'];
$icon[$icon_id]=$vals[$i]['attributes']['SRC'];
}
if ($ver=='2.0' && $vals[$i]['tag']=='MENU_ITEM' && isset($vals[$i]['attributes']['ITEM_ID']) && isset($vals[$i]['attributes']['LIST_VIEW_ICON']))
{
$icon_id=$vals[$i]['attributes']['ITEM_ID'];
$icon[$icon_id]=$vals[$i]['attributes']['LIST_VIEW_ICON'];
}
if ($ver=='2.0' && $vals[$i]['tag']=='HIGHLIGHT' && isset($vals[$i]['attributes']['ACTIVE_IDLE_SHORTCUT_BAR']))
{
$icon_back=$vals[$i]['attributes']['ACTIVE_IDLE_SHORTCUT_BAR'];
}





}








if ($ver=='1.1')
{
$v_ots=24;
$v_ots2=24;
if (isset($icon_back)){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon_back ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_back_img2=imagecreatefromstring($content[0]['content']);


$icon_back_img=imagecreate(74, 74);
imagecopyresampled($icon_back_img, $icon_back_img2, 0, 0, 0, 0, imagesx($icon_back_img), imagesy($icon_back_img), imagesx($icon_back_img2), imagesy($icon_back_img2));

imagecopy($img, $icon_back_img, imagesx($img)/6-imagesx($icon_back_img)/2, imagesy($img)/8-imagesy($icon_back_img)/2+$v_ots, 0, 0, imagesx($icon_back_img), imagesy($icon_back_img));
}




if (isset($icon))
{


if (isset($icon['messages'])){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon['messages'] ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_img=imagecreate(48, 48);
$icon_img2=imagecreatefromstring($content[0]['content']);
imagecopyresampled($icon_img, $icon_img2, 0, 0, 0, 0, imagesx($icon_img), imagesy($icon_img), imagesx($icon_img2), imagesy($icon_img2));
imagecopy($img, $icon_img, imagesx($img)/6-imagesx($icon_img)/2, imagesy($img)/6-imagesy($icon_img)/2+$v_ots, 0, 0, imagesx($icon_img), imagesy($icon_img));
}

if (isset($icon['contacts'])){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon['contacts'] ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_img=imagecreate(48, 48);
$icon_img2=imagecreatefromstring($content[0]['content']);
imagecopyresampled($icon_img, $icon_img2, 0, 0, 0, 0, imagesx($icon_img), imagesy($icon_img), imagesx($icon_img2), imagesy($icon_img2));
imagecopy($img, $icon_img, imagesx($img)/2-imagesx($icon_img)/2, imagesy($img)/6-imagesy($icon_img)/2+$v_ots, 0, 0, imagesx($icon_img), imagesy($icon_img));
}

if (isset($icon['callregister'])){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon['callregister'] ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_img=imagecreate(48, 48);
$icon_img2=imagecreatefromstring($content[0]['content']);
imagecopyresampled($icon_img, $icon_img2, 0, 0, 0, 0, imagesx($icon_img), imagesy($icon_img), imagesx($icon_img2), imagesy($icon_img2));
imagecopy($img, $icon_img, imagesx($img)-imagesx($img)/6-imagesx($icon_img)/2, imagesy($img)/6-imagesy($icon_img)/2+$v_ots, 0, 0, imagesx($icon_img), imagesy($icon_img));
}

if (isset($icon['settings'])){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon['settings'] ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_img=imagecreate(48, 48);
$icon_img2=imagecreatefromstring($content[0]['content']);
imagecopyresampled($icon_img, $icon_img2, 0, 0, 0, 0, imagesx($icon_img), imagesy($icon_img), imagesx($icon_img2), imagesy($icon_img2));
imagecopy($img, $icon_img, imagesx($img)/6-imagesx($icon_img)/2, imagesy($img)/6-imagesy($icon_img)/2+$v_ots+(imagesy($img)-$v_ots-$v_ots2)/3, 0, 0, imagesx($icon_img), imagesy($icon_img));
}

if (isset($icon['gallery'])){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon['gallery'] ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_img=imagecreate(48, 48);
$icon_img2=imagecreatefromstring($content[0]['content']);
imagecopyresampled($icon_img, $icon_img2, 0, 0, 0, 0, imagesx($icon_img), imagesy($icon_img), imagesx($icon_img2), imagesy($icon_img2));
imagecopy($img, $icon_img, imagesx($img)/2-imagesx($icon_img)/2, imagesy($img)/6-imagesy($icon_img)/2+$v_ots+(imagesy($img)-$v_ots-$v_ots2)/3, 0, 0, imagesx($icon_img), imagesy($icon_img));
}


if (isset($icon['media'])){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon['media'] ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_img=imagecreate(48, 48);
$icon_img2=imagecreatefromstring($content[0]['content']);
imagecopyresampled($icon_img, $icon_img2, 0, 0, 0, 0, imagesx($icon_img), imagesy($icon_img), imagesx($icon_img2), imagesy($icon_img2));
imagecopy($img, $icon_img, imagesx($img)-imagesx($img)/6-imagesx($icon_img)/2, imagesy($img)/6-imagesy($icon_img)/2+$v_ots+(imagesy($img)-$v_ots-$v_ots2)/3, 0, 0, imagesx($icon_img), imagesy($icon_img));
}


if (isset($icon['organizer'])){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon['organizer'] ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_img=imagecreate(48, 48);
$icon_img2=imagecreatefromstring($content[0]['content']);
imagecopyresampled($icon_img, $icon_img2, 0, 0, 0, 0, imagesx($icon_img), imagesy($icon_img), imagesx($icon_img2), imagesy($icon_img2));
imagecopy($img, $icon_img, imagesx($img)/6-imagesx($icon_img)/2, imagesy($img)/6-imagesy($icon_img)/2+$v_ots+(imagesy($img)-$v_ots-$v_ots2)/1.5, 0, 0, imagesx($icon_img), imagesy($icon_img));
}

if (isset($icon['push_to_talk'])){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon['push_to_talk'] ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_img=imagecreate(48, 48);
$icon_img2=imagecreatefromstring($content[0]['content']);
imagecopyresampled($icon_img, $icon_img2, 0, 0, 0, 0, imagesx($icon_img), imagesy($icon_img), imagesx($icon_img2), imagesy($icon_img2));
imagecopy($img, $icon_img, imagesx($img)/2-imagesx($icon_img)/2, imagesy($img)/6-imagesy($icon_img)/2+$v_ots+(imagesy($img)-$v_ots-$v_ots2)/1.5, 0, 0, imagesx($icon_img), imagesy($icon_img));
}


if (isset($icon['applications'])){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon['applications'] ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_img=imagecreate(48, 48);
$icon_img2=imagecreatefromstring($content[0]['content']);
imagecopyresampled($icon_img, $icon_img2, 0, 0, 0, 0, imagesx($icon_img), imagesy($icon_img), imagesx($icon_img2), imagesy($icon_img2));
imagecopy($img, $icon_img, imagesx($img)-imagesx($img)/6-imagesx($icon_img)/2, imagesy($img)/6-imagesy($icon_img)/2+$v_ots+(imagesy($img)-$v_ots-$v_ots2)/1.5, 0, 0, imagesx($icon_img), imagesy($icon_img));
}







}


/*

$antenna=imagecreatefromgif(H."loads/inc/file/antenna.gif");
imagecopy($img, $antenna, 4, 4, 0, 0, imagesx($antenna), imagesy($antenna));
*/
$fon=imagecreatefrompng(H."loads/inc/file/208.png");
imagecopy($img, $fon, 0, 0, 0, 0, imagesx($fon), imagesy($fon));




//$white = imagecolorallocate ($img, 255, 255, 255);
//imagettftext ($img, 12, 0, 3, 38, $white, H."/sys/fonts/tahoma.ttf", "Сообщения");
//imagettftext ($img, 12, 0, 196, 18, $white, H."/sys/fonts/tahoma.ttf", "12:00");
//imagettftext ($img, 12, 0, 228, 38, $white, H."/sys/fonts/tahoma.ttf", "1");


$black = imagecolorallocate ($img, 0, 0, 0);
imagettftext ($img, 11, 0, imagesx($img)/2-42, 15, $black, H."/sys/fonts/tahoma.ttf", "Сообщения");
imagettftext ($img, 11, 0, imagesx($img)-11, 16, $black, H."/sys/fonts/tahoma.ttf", "1");


imagettftext ($img, 11, 0, imagesx($img)/2-30, imagesy($img)-6, $black, H."/sys/fonts/tahoma.ttf", "Выбрать");
imagettftext ($img, 11, 0, imagesx($img)-48, imagesy($img)-6, $black, H."/sys/fonts/tahoma.ttf", "Выйти");


/*
imagettftext(resource image, int size, int angle, int x, int y, int color, string fontfile, string text)
*/

}







if ($ver=='2.0')
{
$v_ots=40;
$v_ots2=28;
if (isset($icon_back)){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon_back ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_back_img2=imagecreatefromstring($content[0]['content']);


$icon_back_img=imagecreate(74, 74);
imagecopyresampled($icon_back_img, $icon_back_img2, 0, 0, 0, 0, imagesx($icon_back_img), imagesy($icon_back_img), imagesx($icon_back_img2), imagesy($icon_back_img2));

imagecopy($img, $icon_back_img, imagesx($img)/6-imagesx($icon_back_img)/2, imagesy($img)/8-imagesy($icon_back_img)/2+$v_ots, 0, 0, imagesx($icon_back_img), imagesy($icon_back_img));
}




if (isset($icon))
{


if (isset($icon['messages'])){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon['messages'] ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_img=imagecreate(48, 48);
$icon_img2=imagecreatefromstring($content[0]['content']);
imagecopyresampled($icon_img, $icon_img2, 0, 0, 0, 0, imagesx($icon_img), imagesy($icon_img), imagesx($icon_img2), imagesy($icon_img2));
imagecopy($img, $icon_img, imagesx($img)/6-imagesx($icon_img)/2, imagesy($img)/8-imagesy($icon_img)/2+$v_ots, 0, 0, imagesx($icon_img), imagesy($icon_img));
}

if (isset($icon['contacts'])){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon['contacts'] ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_img=imagecreate(48, 48);
$icon_img2=imagecreatefromstring($content[0]['content']);
imagecopyresampled($icon_img, $icon_img2, 0, 0, 0, 0, imagesx($icon_img), imagesy($icon_img), imagesx($icon_img2), imagesy($icon_img2));
imagecopy($img, $icon_img, imagesx($img)/2-imagesx($icon_img)/2, imagesy($img)/8-imagesy($icon_img)/2+$v_ots, 0, 0, imagesx($icon_img), imagesy($icon_img));
}

if (isset($icon['callregister'])){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon['callregister'] ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_img=imagecreate(48, 48);
$icon_img2=imagecreatefromstring($content[0]['content']);
imagecopyresampled($icon_img, $icon_img2, 0, 0, 0, 0, imagesx($icon_img), imagesy($icon_img), imagesx($icon_img2), imagesy($icon_img2));
imagecopy($img, $icon_img, imagesx($img)-imagesx($img)/6-imagesx($icon_img)/2, imagesy($img)/8-imagesy($icon_img)/2+$v_ots, 0, 0, imagesx($icon_img), imagesy($icon_img));
}

if (isset($icon['settings'])){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon['settings'] ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_img=imagecreate(48, 48);
$icon_img2=imagecreatefromstring($content[0]['content']);
imagecopyresampled($icon_img, $icon_img2, 0, 0, 0, 0, imagesx($icon_img), imagesy($icon_img), imagesx($icon_img2), imagesy($icon_img2));
imagecopy($img, $icon_img, imagesx($img)/6-imagesx($icon_img)/2, imagesy($img)/8-imagesy($icon_img)/2+$v_ots+(imagesy($img)-$v_ots-$v_ots2)/4, 0, 0, imagesx($icon_img), imagesy($icon_img));
}

if (isset($icon['gallery'])){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon['gallery'] ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_img=imagecreate(48, 48);
$icon_img2=imagecreatefromstring($content[0]['content']);
imagecopyresampled($icon_img, $icon_img2, 0, 0, 0, 0, imagesx($icon_img), imagesy($icon_img), imagesx($icon_img2), imagesy($icon_img2));
imagecopy($img, $icon_img, imagesx($img)/2-imagesx($icon_img)/2, imagesy($img)/8-imagesy($icon_img)/2+$v_ots+(imagesy($img)-$v_ots-$v_ots2)/4, 0, 0, imagesx($icon_img), imagesy($icon_img));
}


if (isset($icon['media'])){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon['media'] ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_img=imagecreate(48, 48);
$icon_img2=imagecreatefromstring($content[0]['content']);
imagecopyresampled($icon_img, $icon_img2, 0, 0, 0, 0, imagesx($icon_img), imagesy($icon_img), imagesx($icon_img2), imagesy($icon_img2));
imagecopy($img, $icon_img, imagesx($img)-imagesx($img)/6-imagesx($icon_img)/2, imagesy($img)/8-imagesy($icon_img)/2+$v_ots+(imagesy($img)-$v_ots-$v_ots2)/4, 0, 0, imagesx($icon_img), imagesy($icon_img));
}


if (isset($icon['organizer'])){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon['organizer'] ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_img=imagecreate(48, 48);
$icon_img2=imagecreatefromstring($content[0]['content']);
imagecopyresampled($icon_img, $icon_img2, 0, 0, 0, 0, imagesx($icon_img), imagesy($icon_img), imagesx($icon_img2), imagesy($icon_img2));
imagecopy($img, $icon_img, imagesx($img)/6-imagesx($icon_img)/2, imagesy($img)/8-imagesy($icon_img)/2+$v_ots+(imagesy($img)-$v_ots-$v_ots2)/2, 0, 0, imagesx($icon_img), imagesy($icon_img));
}

if (isset($icon['push_to_talk'])){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon['push_to_talk'] ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_img=imagecreate(48, 48);
$icon_img2=imagecreatefromstring($content[0]['content']);
imagecopyresampled($icon_img, $icon_img2, 0, 0, 0, 0, imagesx($icon_img), imagesy($icon_img), imagesx($icon_img2), imagesy($icon_img2));
imagecopy($img, $icon_img, imagesx($img)/2-imagesx($icon_img)/2, imagesy($img)/8-imagesy($icon_img)/2+$v_ots+(imagesy($img)-$v_ots-$v_ots2)/2, 0, 0, imagesx($icon_img), imagesy($icon_img));
}


if (isset($icon['applications'])){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon['applications'] ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_img=imagecreate(48, 48);
$icon_img2=imagecreatefromstring($content[0]['content']);
imagecopyresampled($icon_img, $icon_img2, 0, 0, 0, 0, imagesx($icon_img), imagesy($icon_img), imagesx($icon_img2), imagesy($icon_img2));
imagecopy($img, $icon_img, imagesx($img)-imagesx($img)/6-imagesx($icon_img)/2, imagesy($img)/8-imagesy($icon_img)/2+$v_ots+(imagesy($img)-$v_ots-$v_ots2)/2, 0, 0, imagesx($icon_img), imagesy($icon_img));
}


if (isset($icon['simatk'])){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon['simatk'] ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_img=imagecreate(48, 48);
$icon_img2=imagecreatefromstring($content[0]['content']);
imagecopyresampled($icon_img, $icon_img2, 0, 0, 0, 0, imagesx($icon_img), imagesy($icon_img), imagesx($icon_img2), imagesy($icon_img2));
imagecopy($img, $icon_img, imagesx($img)/6-imagesx($icon_img)/2, imagesy($img)/8-imagesy($icon_img)/2+$v_ots+(imagesy($img)-$v_ots-$v_ots2)/4*3, 0, 0, imagesx($icon_img), imagesy($icon_img));
}

if (isset($icon['services'])){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon['services'] ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_img=imagecreate(48, 48);
$icon_img2=imagecreatefromstring($content[0]['content']);
imagecopyresampled($icon_img, $icon_img2, 0, 0, 0, 0, imagesx($icon_img), imagesy($icon_img), imagesx($icon_img2), imagesy($icon_img2));
imagecopy($img, $icon_img, imagesx($img)/2-imagesx($icon_img)/2, imagesy($img)/8-imagesy($icon_img)/2+$v_ots+(imagesy($img)-$v_ots-$v_ots2)/4*3, 0, 0, imagesx($icon_img), imagesy($icon_img));
}


if (isset($icon['default'])){
$content = $zip->extract(PCLZIP_OPT_BY_NAME, $icon['default'] ,PCLZIP_OPT_EXTRACT_AS_STRING);
$icon_img=imagecreate(48, 48);
$icon_img2=imagecreatefromstring($content[0]['content']);
imagecopyresampled($icon_img, $icon_img2, 0, 0, 0, 0, imagesx($icon_img), imagesy($icon_img), imagesx($icon_img2), imagesy($icon_img2));
imagecopy($img, $icon_img, imagesx($img)-imagesx($img)/6-imagesx($icon_img)/2, imagesy($img)/8-imagesy($icon_img)/2+$v_ots+(imagesy($img)-$v_ots-$v_ots2)/4*3, 0, 0, imagesx($icon_img), imagesy($icon_img));
}





}




$antenna=imagecreatefromgif(H."loads/inc/file/antenna.gif");
imagecopy($img, $antenna, 4, 4, 0, 0, imagesx($antenna), imagesy($antenna));

$battery=imagecreatefromgif(H."loads/inc/file/battery.gif");
imagecopy($img, $battery, 30, 4, 0, 0, imagesx($battery), imagesy($battery));




$white = imagecolorallocate ($img, 255, 255, 255);
imagettftext ($img, 12, 0, 3, 38, $white, H."/sys/fonts/tahoma.ttf", "Сообщения");
imagettftext ($img, 12, 0, 196, 18, $white, H."/sys/fonts/tahoma.ttf", "12:00");
imagettftext ($img, 12, 0, 228, 38, $white, H."/sys/fonts/tahoma.ttf", "1");


$black = imagecolorallocate ($img, 0, 0, 0);
imagettftext ($img, 12, 0, 3, imagesy($img)-6, $black, H."/sys/fonts/tahoma.ttf", "Функции");
imagettftext ($img, 12, 0, imagesx($img)/2-30, imagesy($img)-6, $black, H."/sys/fonts/tahoma.ttf", "Выбрать");
imagettftext ($img, 12, 0, imagesx($img)-48, imagesy($img)-6, $black, H."/sys/fonts/tahoma.ttf", "Выйти");


/*
imagettftext(resource image, int size, int angle, int x, int y, int color, string fontfile, string text)
*/

}




$img=img_copyright($img); // копирайт

imagejpeg($img, $dir_loads.'/'.$file.'.JPG', 100);



if (is_file($dir_loads.'/'.$file.'.GIF'))
echo "<img src=\"resize.php?".url("f=$l/$file.GIF")."&amp;w=128&amp;h=128\" alt=\"Скрин...\" /><br />\n";
elseif (is_file($dir_loads.'/'.$file.'.JPG'))
echo "<img src=\"resize.php?".url("f=$l/$file.JPG")."&amp;w=128&amp;h=128\" alt=\"Скрин...\" /><br />\n";
elseif (is_file($dir_loads.'/'.$file.'.PNG'))
echo "<img src=\"resize.php?".url("f=$l/$file.PNG")."&amp;w=128&amp;h=128\" alt=\"Скрин...\" /><br />\n";
}




}




echo "Добавлен: ".vremja(filectime($dir_loads.'/'.$file))."<br />\n";
if (is_file($dir_loads.'/'.$file.'.opis')) // проверка описания
echo output_text(file_get_contents($dir_loads.'/'.$file.'.opis'))."<br />\n";
elseif (is_file($dir_loads.'/'.$file.'.txt')) // проверка описания в txt файле
echo output_text(file_get_contents($dir_loads.'/'.$file.'.txt'))."<br />\n";

echo "Размер: ".size_file(filesize($dir_loads.'/'.$file))."<br />\n";
include 'inc/add_file_loads.php'; // обработа вывода ссылки
echo "<a href=\"?komm&amp;".url("d=$l&amp;f=$file")."\">Комментарии</a> (".k_komm($file,$size).")<br />\n";
?>