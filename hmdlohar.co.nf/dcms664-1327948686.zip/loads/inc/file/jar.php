<?
if (is_file($dir_loads.'/'.$file.'.GIF'))
echo "<img src=\"resize.php?".url("f=$l/$file.GIF")."&amp;w=128&amp;h=128\" alt=\"Скрин...\" /><br />\n";
elseif (is_file($dir_loads.'/'.$file.'.JPG'))
echo "<img src=\"resize.php?".url("f=$l/$file.JPG")."&amp;w=128&amp;h=128\" alt=\"Скрин...\" /><br />\n";
elseif (is_file($dir_loads.'/'.$file.'.PNG'))
echo "<img src=\"resize.php?".url("f=$l/$file.PNG")."&amp;w=128&amp;h=128\" alt=\"Скрин...\" /><br />\n";





echo "Added: ".vremja(filectime($dir_loads.'/'.$file))."<br />\n";


if (is_file($dir_loads.'/'.$file.'.opis')) // проверка описания
echo output_text(file_get_contents($dir_loads.'/'.$file.'.opis'))."<br />\n";
elseif (is_file($dir_loads.'/'.$file.'.txt')) // проверка описания в txt файле
echo output_text(file_get_contents($dir_loads.'/'.$file.'.txt'))."<br />\n";


if (!is_file($dir_loads.'/'.$name.'.jad'))
{
include_once H.'sys/inc/zip.php';
$zip=new PclZip($dir_loads.'/'.$file);

$content = $zip->extract(PCLZIP_OPT_BY_NAME, "META-INF/MANIFEST.MF" ,PCLZIP_OPT_EXTRACT_AS_STRING);
$jad=eregi_replace("(MIDlet-Jar-URL:( )*[^(\n|\r)]*)", NULL, $content[0]['content']);
$jad=eregi_replace("(MIDlet-Jar-Size:( )*[^(\n|\r)]*)(\n|\r)", NULL, $jad);
$jad=trim($jad);
$jad.="\r\nMIDlet-Jar-Size: ".filesize($dir_loads.'/'.$file)."";
$jad.="\r\nMIDlet-Jar-URL: $name.jar";

$jad=br($jad,"\r\n");

file_put_contents($dir_loads.'/'.$name.'.jad', $jad);
@chmod($dir_loads.'/'.$name.'.jad', 0777);
}



echo "Size: ".size_file(filesize($dir_loads.'/'.$file))."<br />\n";


if (!isset($set['downloads_select']) || $set['downloads_select']=='0')
{
echo "<a href=\"/loads/down/$l/$file\">Download JAR</a> <a href=\"/loads/down/$l/$name.jad\">JAD</a> (".k_loads($file,$size).")<br />\n";
echo "<input type='text' value='http://$_SERVER[SERVER_NAME]/loads/down/$l/$file' /><br />\n";
}
elseif(isset($user) && $set['downloads_select']=='1')
{
if (!isset($_SESSION['down_sess']))$_SESSION['down_sess']=md5(passgen());
$tmp_sess=$_SESSION['down_sess'];
$data_sess[]=array('l'=>$l,'file'=>$file,'time'=>$time, 'ip'=>$iplong);
if ($tmp_file=@file_get_contents(H.'sys/tmp/down_'.$_SESSION['down_sess'].'.dat'))
{
$tmp_array=unserialize($tmp_file);
for($iiii=0;$iiii<5 && $iiii<sizeof($tmp_array);$iiii++)
{
$data_sess[]=$tmp_array[$iiii];
}
}
file_put_contents(H.'sys/tmp/down_'.$_SESSION['down_sess'].'.dat', serialize($data_sess));
echo "<a href=\"/loads/down_$tmp_sess/$l/$file\">Download JAR</a> <a href=\"/loads/down_$tmp_sess/$l/$name.jad\">JAD</a> (".k_loads($file,$size).")<br />\n";
echo "<input type='text' value='http://$_SERVER[SERVER_NAME]/loads/down_$tmp_sess/$l/$file' /><br />\n";
echo "* Link valid for 2 hours<br />\n";
}
elseif($user['balls']>=100 && $set['downloads_select']=='2')
{
if (!isset($_SESSION['down_sess']))$_SESSION['down_sess']=md5(passgen());
$tmp_sess=$_SESSION['down_sess'];
$data_sess[]=array('l'=>$l,'file'=>$file,'time'=>$time, 'ip'=>$iplong);
if ($tmp_file=@file_get_contents(H.'sys/tmp/down_'.$_SESSION['down_sess'].'.dat'))
{
$tmp_array=unserialize($tmp_file);
for($iiii=0;$iiii<5 && $iiii<sizeof($tmp_array);$iiii++)
{
$data_sess[]=$tmp_array[$iiii];
}
}
file_put_contents(H.'sys/tmp/down_'.$_SESSION['down_sess'].'.dat', serialize($data_sess));
echo "<a href=\"/loads/down_$tmp_sess/$l/$file\">Download JAR</a> <a href=\"/loads/down_$tmp_sess/$l/$name.jad\">JAD</a> (".k_loads($file,$size).")<br />\n";
echo "<input type='text' value='http://$_SERVER[SERVER_NAME]/loads/down_$tmp_sess/$l/$file' /><br />\n";
echo "* Link valid for 2 hours<br />\n";
}
else
{
if ($set['downloads_select']=='2')
echo 'Downloading is available only to users who receives more than 100 points<br />';
if ($set['downloads_select']=='1')
echo 'To download file, you must log in or register<br />';
}




echo "<a href=\"?komm&amp;".url("d=$l&amp;f=$file")."\">Comments</a> (".k_komm($file,$size).")<br />\n";
?>