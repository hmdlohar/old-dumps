<?
include_once H.'sys/inc/mp3.php';
$id3 = &new MP3_Id(); 
$result = $id3->read($dir_loads.'/'.$file);
$result = $id3->study();
if (user_access('loads_file_edit')){
if (isset($_GET['act']) && $_GET['act']=='edit_tag_ok')
{
$id3->setTag('name',(function_exists('iconv')?iconv('utf-8', 'windows-1251', $_POST['name']):$_POST['name'])); 
$id3->setTag('artists', (function_exists('iconv')?iconv('utf-8', 'windows-1251', $_POST['artists']):$_POST['artists'])); 
$id3->setTag('album', (function_exists('iconv')?iconv('utf-8', 'windows-1251', $_POST['album']):$_POST['album'])); 
$id3->setTag('year', (function_exists('iconv')?iconv('utf-8', 'windows-1251', $_POST['year']):$_POST['year'])); 
$id3->setTag('comment', (function_exists('iconv')?iconv('utf-8', 'windows-1251', $_POST['comment']):$_POST['comment']));
$id3->setTag('genre', (function_exists('iconv')?iconv('utf-8', 'windows-1251', $_POST['genre']):$_POST['genre'])); 
$id3->setTag('track', (function_exists('iconv')?iconv('utf-8', 'windows-1251', $_POST['track']):$_POST['track']));
$result = $id3->write(); 
if (PEAR::isError($result))
{
echo "Error writing tags";
}
else
msg('Tags successfully written');


}
}



if (is_file($dir_loads.'/'.$file.'.GIF'))
echo "<img src=\"resize.php?".url("f=$l/$file.GIF")."&amp;w=128&amp;h=128\" alt=\"Скрин...\" /><br />\n";
elseif (is_file($dir_loads.'/'.$file.'.JPG'))
echo "<img src=\"resize.php?".url("f=$l/$file.JPG")."&amp;w=128&amp;h=128\" alt=\"Скрин...\" /><br />\n";
elseif (is_file($dir_loads.'/'.$file.'.PNG'))
echo "<img src=\"resize.php?".url("f=$l/$file.PNG")."&amp;w=128&amp;h=128\" alt=\"Скрин...\" /><br />\n";





echo "Added: ".vremja(filectime($dir_loads.'/'.$file))."<br />\n";


if (is_file($dir_loads.'/'.$file.'.opis')) // проверка описания
echo output_text(file_get_contents($dir_loads.'/'.$file.'.opis'))."<br />\n";
elseif (is_file($dir_loads.'/'.$file.'.txt')) // проверка описания в txt файле
echo output_text(file_get_contents($dir_loads.'/'.$file.'.txt'))."<br />\n";



$name_id=(function_exists('iconv')?iconv('windows-1251', 'utf-8', $id3->getTag('name')):$id3->getTag('name'));
$artist=(function_exists('iconv')?iconv('windows-1251', 'utf-8', $id3->getTag('artists')):$id3->getTag('artists'));
$album=(function_exists('iconv')?iconv('windows-1251', 'utf-8', $id3->getTag('album')):$id3->getTag('album'));
$year=(function_exists('iconv')?iconv('windows-1251', 'utf-8', $id3->getTag('year')):$id3->getTag('year')); 
$comment=(function_exists('iconv')?iconv('windows-1251', 'utf-8', $id3->getTag('comment')):$id3->getTag('comment')); 
$genre=(function_exists('iconv')?iconv('windows-1251', 'utf-8', $id3->getTag('genre')):$id3->getTag('genre'));
$track=(function_exists('iconv')?iconv('windows-1251', 'utf-8', $id3->getTag('track')):$id3->getTag('track'));




if (class_exists('ffmpeg_movie'))
{
$media = new ffmpeg_movie($dir_loads.'/'.$file);
if (intval($media->getDuration())>3599)
$length=intval($media->getDuration()/3600).":".date('s',fmod($media->getDuration()/60,60)).":".date('s',fmod($media->getDuration(),3600));
elseif (intval($media->getDuration())>59)
$length=intval($media->getDuration()/60).":".date('s',fmod($media->getDuration(),60));
else
$length= intval($media->getDuration())." sec";
$bitrate=ceil(($media->getBitRate())/1024).' KBPS';
}
else
{
$length=$id3->getTag('length');
$bitrate=$id3->getTag('bitrate').' KBPS';
}






if ($name_id!=null && $name_id!=0)echo "Title: ".output_text($name_id)."<br />\n";
if ($artist!=null && $artist!=0)echo "Artist: ".output_text($artist)."<br />\n";
if ($album!=null && $album!=0)echo "Album: ".output_text($album)."<br />\n";
if ($year!=null && $year!=0)echo "Year: ".output_text($year)."<br />\n";
if ($comment!=null && $comment!=0)echo "Comments: ".output_text($comment)."<br />\n";
if ($genre!=null && $genre!=0)echo "Genre: ".output_text($genre)."<br />\n";
if ($track!=null && $track!=0)echo "Track No.: ".output_text($track)."<br />\n";

if ($length!=null)echo "Duration: $length<br />\n";
if ($bitrate!=null)echo "Bitrate: $bitrate<br />\n";


echo "Size: ".size_file(filesize($dir_loads.'/'.$file))."<br />\n";

if (isset($_GET['act']) && $_GET['act']=='crop')
{
echo "<form method='post' action='?".url("d=$l&amp;f=$file")."&amp;act=cropok'>\n";
echo 'Croping Method:<br />
<select name="way">
<option value="size">By size</option>
<option value="time">By time</option>
</select><br />';

echo "KB or SEC:<br />\n";
echo "From <input type=\"text\" name=\"s\" size='3' value='0' /> to <input type=\"text\" name=\"p\" size='3' value='".intval(filesize($dir_loads.'/'.$file)/1024)."' /><br />\n";
echo "<input type='submit' value='Croping' />\n";
echo "</form>\n";
}
elseif(isset($_GET['act']) && $_GET['act']=='cropok')
{
$s=$_POST['s'];
$p=$_POST['p'];
$fp = fopen($dir_loads.'/'.$file, "rb");
if($_POST['way']=="size"){

$s = $s*1024;
$p = $p*1024;
if($s>$size||$s<0){$s = 0;}
if($p>$size||$p<$s){$p = $size;}}
else{ 
$byterate = $id3->getTag('bitrate')/8;
$secbit = $size/1024/$byterate;
if($s>$secbit||$s<0){$s = 0;}
if($p>$secbit||$p<$s){$p = $secbit;}
$s = $s*$byterate*1024;
$p = $p*$byterate*1024;}
$p = $p-$s;
fseek($fp, $s);
$filefp = fread($fp, $p);
fclose($fp);
$tempfilename=rand(00000001,9999999).'_'.$file;
$tempfile=H.'sys/loads/mp3crop/'.$tempfilename;
$fp = fopen($tempfile, "xb");
fwrite($fp, $filefp);


if (function_exists('iconv'))
echo "<a href=\"/loads/mp3crop/".iconv('windows-1251', 'utf-8', $tempfilename)."\"><b>Download Croping</b></a><br />\n";
else echo "<a href=\"/loads/mp3crop/$tempfilename\"><b>Download Croping</b></a><br />\n";

}

echo "<a href=\"?".url("d=$l&amp;f=$file")."&amp;act=crop\">Croping</a><br />\n";


if (user_access('loads_file_edit')){
if (isset($_GET['act']) && $_GET['act']=='edit_tag')
{
echo "<form method='post' action='?".url("d=$l&amp;f=$file")."&amp;act=edit_tag_ok'>\n";
echo "Title:<br />\n";
echo "<input type='text' name='name' value='".htmlentities($name_id==0?null:$name_id, ENT_QUOTES, 'UTF-8')."' /><br />\n";
echo "Artist:<br />\n";
echo "<input type='text' name='artists' value='".htmlentities($artist==0?null:$artist, ENT_QUOTES, 'UTF-8')."' /><br />\n";
echo "Album:<br />\n";
echo "<input type='text' name='album' value='".htmlentities($album==0?null:$album, ENT_QUOTES, 'UTF-8')."' /><br />\n";
echo "Year:<br />\n";
echo "<input type='text' name='year' value='".htmlentities($year==0?null:$year, ENT_QUOTES, 'UTF-8')."' /><br />\n";
echo "Comments:<br />\n";
echo "<textarea name='comment'>".htmlentities($comment==0?null:$comment, ENT_QUOTES, 'UTF-8')."</textarea><br />\n";
echo "Genre:<br />\n";
echo "<input type='text' name='genre' value='".htmlentities($genre==0?null:$genre, ENT_QUOTES, 'UTF-8')."' /><br />\n";
echo "Track No.:<br />\n";
echo "<input type='text' name='track' value='".htmlentities($track==0?null:$track, ENT_QUOTES, 'UTF-8')."' /><br />\n";


echo "<input type='submit' value='Apply' /><br />\n";
echo "</form>\n";
echo "<a href=\"?".url("d=$l&amp;f=$file")."\">Cancel</a><br />\n";
}
else
echo "<a href=\"?".url("d=$l&amp;f=$file")."&amp;act=edit_tag\">Edit Tags</a><br />\n";
}
include 'inc/add_file_loads.php'; // обработа вывода ссылки
echo "<a href=\"?komm&amp;".url("d=$l&amp;f=$file")."\">Comments</a> (".k_komm($file,$size).")<br />\n";
?>