<?
if (dir_name($dir_loads)!=NULL)
$set['title']='Download - '.dir_name($dir_loads);
else $set['title']='Download';
include_once '../sys/inc/thead.php';
title();
include 'inc/admin_act.php';
err();
aut();


$dirlist_t=NULL;
$opendir=opendir($dir_loads);
while ($readdir=readdir($opendir)){
if (!eregi("^\.|\.php|\.name$|\.txt$|\.opis$|\.html?$|\.sql$|\.ini$|\.db$|\.dat$|\.jad$",$readdir) && !ereg("\.JPG$|\.PNG$|\.GIF$",$readdir))
{
$dirlist_t[]=is_dir($dir_loads.'/'.$readdir)?array('time'=>9999999999999,'dir'=>1,'name'=>$readdir):array('time'=>filectime($dir_loads.'/'.$readdir),'dir'=>0,'name'=>$readdir);
}
}
closedir($opendir);


function cmp_time($a2, $b2)
{
return ($a2['time']<$b2['time'])?1:0;
}
function cmp_dir($a2, $b2)
{
return ($a2['dir']<$b2['dir'])?1:0;
}
if (count($dirlist_t)!=0)usort($dirlist_t, "cmp_time");
if (count($dirlist_t)!=0)usort($dirlist_t, "cmp_dir");
if (count($dirlist_t)!=0)usort($dirlist_t, "cmp_dir");


$k_post=count($dirlist_t);
$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];
$end=$set['p_str']*$page;
if ($l!=NULL){
echo "<div class='foot'>";
echo "<a href='?'>Downloads</a> &gt; ".rupath($l,'../sys/loads/files')."<br />\n";
echo "</div>\n";
}
echo "<table class='post'>\n";

if ($k_post==0){
echo "   <tr>\n";
echo "  <td class='p_t'>\n";
echo "Folder Empty\n";
echo "  </td>\n";
echo "   </tr>\n";
}

for ($i=$start;$i<$end && $i<$k_post;$i++)
{
$dirlist[$i]=$dirlist_t[$i]['name'];
if ($dirlist_t[$i]['dir']==1) // папка
{
echo "   <tr>\n";
if ($set['set_show_icon']==2){
echo "  <td rowspan='2' class='icon48'>\n";
echo "<img src='/style/themes/$set[set_them]/loads/48/dir.png' alt='' />\n";
echo "  </td>\n";
}
elseif ($set['set_show_icon']==1){
echo "  <td class='icon14'>\n";
echo "<img src='/style/themes/$set[set_them]/loads/14/dir.png' alt='' />\n";
echo "  </td>\n";
}
echo "  <td class='p_t'>\n";
echo "<a href='?d=".urlencode("$l/$dirlist[$i]")."'>".dir_name($dir_loads.'/'.$dirlist[$i])."</a>\n";
echo "  </td>\n";
echo "   </tr>\n";
echo "   <tr>\n";
if ($set['set_show_icon']==1)echo "  <td class='p_m' colspan='2'>\n"; else echo "  <td class='p_m'>\n";



echo "Files: ".k_files($l.'/'.$dirlist[$i])."<br />\n";

echo "  </td>\n";
echo "   </tr>\n";
}
else // файл
{
echo "   <tr>\n";
$ras=strtolower(eregi_replace('^.*\.', NULL, $dirlist[$i]));
$name=eregi_replace('\.[^\.]*$', NULL, $dirlist[$i]);
if (is_file($dir_loads.'/'.$dirlist[$i].'.name'))
$name2=trim(esc(file_get_contents($dir_loads.'/'.$dirlist[$i].'.name')));
elseif (function_exists('iconv'))
$name2=iconv('windows-1251', 'utf-8', $name);
else $name2=$name;

$name2=htmlspecialchars($name2);

$size=filesize($dir_loads.'/'.$dirlist[$i]);



if ($set['set_show_icon']==2){

echo "  <td rowspan='2' class='icon48'>\n";
include 'inc/icon48.php';
echo "  </td>\n";
}
elseif ($set['set_show_icon']==1){

echo "  <td class='icon14'>\n";
include 'inc/icon14.php';
echo "  </td>\n";
}

echo "  <td class='p_t'>\n";


if ($set['echo_rassh']==1)$ras2=".$ras";else $ras2=NULL;

echo "<a href='?d=".urlencode("$l")."&amp;f=".urlencode("$dirlist[$i]")."&amp;page=$page'>$name2$ras2</a>".file_new($dir_loads.'/'.$dirlist[$i])."\n";
echo "  </td>\n";
echo "   </tr>\n";
echo "   <tr>\n";
if ($set['set_show_icon']==1)echo "  <td class='p_m' colspan='2'>\n"; else echo "  <td class='p_m'>\n";
include 'inc/opis.php';
echo "  </td>\n";
echo "   </tr>\n";
}
}

echo "</table>\n";


if ($k_page>1)str("?d=".urlencode("$l")."&amp;",$k_page,$page); // Вывод страниц

if ($l!=NULL){
echo "<div class='foot'>";
echo "<a href='?'>Downloads</a> &gt; ".rupath($l,'../sys/loads/files')."<br />\n";
echo "</div>\n";
}






include 'inc/admin_form.php';

if ($l==NULL){
echo "<div class='foot'>";
echo "&raquo;<a href='/loads/new_komm.php'>New Comments</a> (".mysql_result(mysql_query("SELECT COUNT(*) FROM `loads_komm` LEFT JOIN `loads_list` ON `loads_komm`.`file` = `loads_list`.`name` AND `loads_komm`.`size` = `loads_list`.`size` WHERE `loads_komm`.`time` > '".($time-60*60*24)."'"), 0).")<br />\n";
echo "&raquo;<a href='/loads/search.php'>Search Files</a><br />\n";
echo "</div>\n";
}
include_once '../sys/inc/tfoot.php';
?>