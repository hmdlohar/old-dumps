<?





if (is_file(H."sys/loads/screens/48/$size.$name.$ras"))
{
if (function_exists('iconv'))
echo "<img src='/sys/loads/screens/48/".iconv('windows-1251', 'utf-8',"$size.$name.$ras")."' alt='scr...' /><br />\n";
else
echo "<img src='/sys/loads/screens/48/$size.$name.$ras' alt='scr...' /><br />\n";
}
elseif (function_exists('imagecreatefromgif'))
{

$imgc=imagecreatefromgif($dir_loads.'/'.$dirlist[$i]);
$img_x=imagesx($imgc);
$img_y=imagesy($imgc);
if ($img_x==$img_y)
{
$dstW=48; // ширина
$dstH=48; // высота 
}
elseif ($img_x>$img_y)
{
$prop=$img_x/$img_y;
$dstW=48;
$dstH=ceil($dstW/$prop);
}
else
{
$prop=$img_y/$img_x;
$dstH=48;
$dstW=ceil($dstH/$prop);
}

$screen=imagecreatetruecolor($dstW, $dstH);
imagecopyresampled($screen, $imgc, 0, 0, 0, 0, $dstW, $dstH, $img_x, $img_y);
imagedestroy($imgc);
imagegif($screen,H."sys/loads/screens/48/$size.$name.$ras");
imagedestroy($screen);
echo "<img src='/sys/loads/screens/48/$size.$name.$ras' alt='scr...' />\n";
}
elseif (is_file(H.'style/themes/'.$set['set_them'].'/loads/48/'.$ras.'.png'))
echo "<img src='/style/themes/$set[set_them]/loads/48/$ras.png' alt='$ras' />\n";
else echo "<img src='/style/themes/$set[set_them]/loads/48/file.png' alt='file' />\n";


?>