<?


if (user_access('loads_file_delete') && isset($_GET['act']) && $_GET['act']=='delete' && isset($_GET['ok']))
{

if (@unlink($dir_loads.'/'.$file))
{
@unlink($dir_loads.'/'.$file.'.GIF');
@unlink($dir_loads.'/'.$file.'.JPG');
@unlink($dir_loads.'/'.$file.'.PNG');
@unlink($dir_loads.'/'.$file.'.name');
@unlink($dir_loads.'/'.$file.'.opis');
msg("File \"$name2\" successfully removed");
admin_log('Download center','Delete',"Delete files $name2");
$jfile=eregi_replace('\.jad$', '.jar', $file);
if (function_exists('iconv'))$jfile=iconv('windows-1251', 'utf-8', $jfile);

$path=(function_exists('iconv'))?iconv('windows-1251', 'utf-8', $l):$l;
$path='/'.eregi_replace('^/+|/+$', null, $path).'/';
mysql_query("DELETE FROM `loads_list` WHERE `path` = '".my_esc($path)."' AND `name` = '".my_esc($jfile)."' LIMIT 1");

mysql_query("DELETE FROM `loads_komm` WHERE `file` = '".my_esc($jfile)."' AND `size` = '$size'"); // удаление комментариев

echo "<div class=\"foot\">\n";
echo "<a href=\"?".url("d=$l")."\">Back to folder</a><br />\n";
echo "</div>\n";
include_once '../sys/inc/tfoot.php';
}
else
$err= "Unable to delete files\n";
@unlink($dir_loads.'/.k_files');
}




if (user_access('loads_file_edit') && isset($_GET['act']) && $_GET['act']=='prop' && isset($_GET['ok']) && isset($_POST['name_serv']) && isset($_POST['ras_serv']) && isset($_POST['name_loads']) && isset($_POST['opis']))
{


$new_name_serv=$_POST['name_serv'].'.'.$_POST['ras_serv'];


if ($new_name_serv==NULL)
$err= "Enter the filename";
elseif (!ereg('^[^/]*.[^/]*$',$new_name_serv))
$err= "No specified file name";
elseif (ereg('^\.|\.php|\.name$|\.txt$|\.opis$|\.html?$|\.sql$|\.ini$|\.db$|\.dat$',$new_name_serv))
$err= "Prohibited file extension";
else
{

if (function_exists('iconv'))
$newdir_serv=iconv('utf-8', 'windows-1251', esc($new_name_serv));
else
$newdir_serv=retranslit(esc($new_name_serv));
if (@rename($dir_loads.'/'.$file, $dir_loads.'/'.$newdir_serv))
{
$jfile=eregi_replace('\.jad$', '.jar', $file);
if (function_exists('iconv'))$jfile=iconv('windows-1251', 'utf-8', $jfile);
$name=eregi_replace('\.[^\.]*$', NULL, $file); // имя файла без расширения
@unlink($dir_loads.'/'.$name.'.jad');
@unlink($dir_loads.'/'.$file.'.name');


@rename($dir_loads.'/'.$file.'.opis', $dir_loads.'/'.$newdir_serv.'.opis');
@rename($dir_loads.'/'.$file.'.GIF', $dir_loads.'/'.$newdir_serv.'.GIF');
@rename($dir_loads.'/'.$file.'.JPG', $dir_loads.'/'.$newdir_serv.'.JPG');
@rename($dir_loads.'/'.$file.'.PNG', $dir_loads.'/'.$newdir_serv.'.PNG');

$file=ereg_replace(".*/",NULL,$newdir_serv); // получение имени файла
$name=eregi_replace('\.[^\.]*$', NULL, $file); // имя файла без расширения
$ras=strtolower(eregi_replace('^.*\.', NULL, $file)); // расширение (в нижнем регистре)



$jfile2=eregi_replace('\.jad$', '.jar', $newdir_serv);
if (function_exists('iconv'))$jfile2=iconv('windows-1251', 'utf-8', $jfile2);




$path=(function_exists('iconv'))?iconv('windows-1251', 'utf-8', $l):$l;
$path='/'.eregi_replace('^/+|/+$', null, $path).'/';
mysql_query("UPDATE `loads_list` SET `name` = '".my_esc($jfile2)."' WHERE `path` = '".my_esc($path)."' AND `name` = '".my_esc($jfile)."' LIMIT 1");
mysql_query("UPDATE `loads_komm` SET `file` = '".my_esc($jfile2)."' WHERE `file` = '".my_esc($jfile)."' AND `size` = '$size'");
msg("The filename on server was changed successfully");
admin_log('Download center','Settings file',"File $file renamed to $jfile2");
if ($_POST["opis"]!=NULL)
{
$f=@fopen($dir_loads.'/'.$file.'.opis', 'w');
@fwrite($f, stripslashes(htmlspecialchars(esc($_POST["opis"]))));
@fclose($f);
@chmod($dir_loads.'/'.$file.'.opis', 0777);
}

$newdir_loads=esc($_POST['name_loads'],1);
if ($f=@fopen($dir_loads.'/'.$newdir_serv.'.name', 'w'))
{
@fwrite($f, $newdir_loads);
fclose($f);
admin_log('Download center','Settings file',"File '$name2' renamed to '$newdir_loads'");
$name2=$newdir_loads;
@chmod($dir_loads.'/'.$newdir_serv.'.name', 0777);
msg("File successfully renamed");
}
else
{
$err= "Unable change filename in download";
}
}
else
$err= "Unable change filename in the server";
}
}
?>