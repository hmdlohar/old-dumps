<?
if (isset($_GET['tmp']) && @eregi('^[A-z0-9]{32}$',$_GET['tmp']))
{
if ($tmp_file=@file_get_contents(H.'sys/tmp/down_'.$_GET['tmp'].'.dat'))
{
if ($tmp_array=@unserialize($tmp_file))
{


for($iiii=0;$iiii<sizeof($tmp_array);$iiii++)
{

if ($tmp_array[$iiii]['time']>$time-3600*2 && $tmp_array[$iiii]['l']==$l && $tmp_array[$iiii]['file']==$jfile && $tmp_array[$iiii]['ip']==$iplong)
{
if ($loads!=NULL)
mysql_query("UPDATE `loads_list` SET `loads` = '".($loads['loads']+1)."' WHERE `name` = '$jfile' AND `size` = '$size' AND `path` = '".my_esc($path)."' LIMIT 1");
else
mysql_query("INSERT INTO `loads_list` (`name`, `size`,  `path`, `time`, `loads`) values('".my_esc($jfile)."', '$size', '".my_esc($path)."', '".filectime($dir_loads.'/'.$jfile)."', '1')");
DownloadFile($dir_loads.'/'.$file, basename($dir_loads.'/'.$file), ras_to_mime($ras));
exit;
}


}
}
}
}
$set['title']='Error downloading';
include_once '../sys/inc/thead.php';
title();
$err[]='Invalid link or a valid time over';
err();
aut();

echo "<a href='/loads/?d=".urlencode("$l")."&amp;f=".urlencode("$file")."'>File description</a><br />\n";

include_once '../sys/inc/tfoot.php';
?>