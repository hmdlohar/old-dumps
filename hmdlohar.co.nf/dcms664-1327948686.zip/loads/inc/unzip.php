<?

if (isset($_GET['unzip']))
{
include_once H.'sys/inc/zip.php';
$zip=new PclZip($dir_loads.'/'.$file);

switch ($_GET['unzip']) {
case 'name':$path_unzip=$dir_loads.'/'.$name;break;
case 'name2':$path_unzip=$dir_loads.'/'.$name; $dir_n=$name2; break;
default:$path_unzip=$dir_loads;	break;
}



$zip->extract(PCLZIP_OPT_PATH, $path_unzip, PCLZIP_OPT_SET_CHMOD, 0777,PCLZIP_OPT_BY_PREG, "#^[^\.]+#ui");
msg('Archieve successfully extracted');

if (isset($dir_n)){
if ($f=@fopen($path_unzip.'/.dirname', 'w'))
{
@fwrite($f, $dir_n);
fclose($f);
@chmod($path_unzip.'/.dirname', 0777);
}
else
{
$err= "Unable to set the folder name";
}
}
admin_log('Download center','Add Files',"Unpacked archieve '$l/$file' in folder '".dir_name($path_unzip)."'");


}

if (isset($_GET['select_unzip']))
{
echo "<div class='foot'>\n";
echo "&raquo;<a href='?".url("d=$l&amp;f=$file")."&amp;unzip=this'>Unpack the current folder</a><br />\n";
echo "&raquo;<a href='?".url("d=$l&amp;f=$file")."&amp;unzip=name'>Unpack in \"$name/\"</a><br />\n";
if ($name!=$name2)
echo "&raquo;<a href='?".url("d=$l&amp;f=$file")."&amp;unzip=name2'>Unpack in \"$name2/\"</a><br />\n";
echo "&laquo;<a href='?".url("d=$l&amp;f=$file")."&amp;$passgen'>Cancel</a><br />\n";
echo "</div>\n";
}
else
{
echo "<div class='foot'>\n";
echo "&raquo;<a href='?".url("d=$l&amp;f=$file")."&amp;select_unzip'>Unpack the archieve</a><br />\n";
echo "</div>\n";
}
?>