<?
$path=(function_exists('iconv'))?iconv('windows-1251', 'utf-8', $l):$l;
$path='/'.eregi_replace('^/+|/+$', null, $path).'/';

if (user_access('loads_file_import') && isset($_GET['act']) && $_GET['act']=='import' && isset($_POST['ok']) && isset($_POST['k_forms']) && $l!=null)
{

$k_forms=intval($_POST['k_forms']);
for ($i=0;$i<$k_forms;$i++)
{
if (isset($_POST["file_$i"]) && isset($_POST["name_$i"]) && isset($_POST["opis_$i"]))
{
$newfile=basename($_POST["file_$i"]);
if (ereg('^[^/]*.[^/]*$',$newfile) && !ereg('^\.|\.php|\.name$|\.txt$|\.opis$|\.html?$|\.sql$|\.ini$|\.db$|\.dat$',$newfile) && @copy($_POST["file_$i"], $dir_loads.'/'.$newfile))
{
if ($_POST["opis_$i"]!=NULL)
{
$f=@fopen($dir_loads.'/'.$newfile.'.opis', 'w');
@fwrite($f, stripslashes(htmlspecialchars(esc($_POST["opis_$i"]))));
@fclose($f);
@chmod($dir_loads.'/'.$newfile.'.opis', 0777);
}


@chmod($dir_loads.'/'.$newfile, 0777);
$f=@fopen($dir_loads.'/'.$newfile.'.name', 'w');

if ($_POST["name_$i"]!=NULL)$name=eregi_replace('\.[^\.]*$', NULL, $_POST["name_$i"]);
else $name=eregi_replace('\.[^\.]*$', NULL, $newfile); // имя файла без расширения
@fwrite($f, $name);
@fclose($f);
@chmod($dir_loads.'/'.$newfile.'.name', 0777);
msg ("File \"$name\" successfully imported");
admin_log('App Center','Adding files',"Imported file '$name' in the folder '".dir_name($dir_loads)."'");
$size=filesize($dir_loads.'/'.$newfile);
mysql_query("INSERT INTO `loads_list` (`name`, `size`,  `path`, `time`) values('".my_esc($newfile)."', '$size', '".my_esc($path)."', '".filectime($dir_loads.'/'.$newfile)."')");


if (isset($_POST["scr_$i"]))
{
$file_scr=eregi_replace('^.*/', NULL, $_POST["scr_$i"]);


if (eregi('\.gif$|\.jpe?g$|\.png$',$file_scr))
{

$ras=strtolower(eregi_replace('^.*\.', NULL,$newfile));
$scr_ras=strtoupper(eregi_replace('^.*\.', NULL,$file_scr));
@copy($_POST["scr_$i"], $dir_loads.'/'.$newfile.'.'.$scr_ras);
}
}
}
else $err[]=($i+1).') Unable to import in the specified path';
}

}

}



if (user_access('loads_file_upload') && isset($_GET['act']) && $_GET['act']=='upload' && isset($_POST['ok']) && isset($_POST['k_forms']) && $l!=null)
{
$k_forms=intval($_POST['k_forms']);
for ($i=0;$i<$k_forms;$i++)
{
if (isset($_FILES["file_$i"]) && !eregi('^\.|\.php|\.name$|\.txt$|\.opis$|\.html?$|\.sql$|\.ini$|\.db$|\.dat$',$_FILES["file_$i"]['name']) && filesize($_FILES["file_$i"]['tmp_name'])>0 && isset($_POST["opis_$i"]))
{

$newfile=tr_loads(retranslit($_FILES["file_$i"]['name']));
if (@copy($_FILES["file_$i"]['tmp_name'], $dir_loads.'/'.$newfile))
{
if ($_POST["opis_$i"]!=NULL)
{
$f=@fopen($dir_loads.'/'.$newfile.'.opis', 'w');
@fwrite($f, stripslashes(htmlspecialchars(esc($_POST["opis_$i"]))));
@fclose($f);
@chmod($dir_loads.'/'.$newfile.'.opis', 0777);
}


@chmod($dir_loads.'/'.$newfile, 0777);
$f=@fopen($dir_loads.'/'.$newfile.'.name', 'w');
$name=eregi_replace('\.[^\.]*$', NULL, $newfile); // имя файла без расширения
@fwrite($f, eregi_replace('\.[^\.]*$', NULL, esc($_FILES["file_$i"]['name'])));
@fclose($f);
@chmod($dir_loads.'/'.$newfile.'.name', 0777);
msg("File \"".stripslashes(htmlspecialchars(esc($_FILES["file_$i"]['name'])))."\" successfully uploaded");
admin_log('App Center','Add files',"Uploaded files '$newfile' in folder '".dir_name($dir_loads)."'");

$size=filesize($dir_loads.'/'.$newfile);
mysql_query("INSERT INTO `loads_list` (`name`, `size`,  `path`, `time`) values('".my_esc($newfile)."', '$size', '".my_esc($path)."', '".filectime($dir_loads.'/'.$newfile)."')");



}

if (isset($_FILES["scr_$i"]) && eregi('\.gif$|\.jpe?g$|\.png$',$_FILES["scr_$i"]['name']) && filesize($_FILES["scr_$i"]['tmp_name'])>0)
{
$ras=strtolower(eregi_replace('^.*\.', NULL,$newfile));
$scr_ras=strtoupper(eregi_replace('^.*\.', NULL,$_FILES["scr_$i"]['name']));
@copy($_FILES["scr_$i"]['tmp_name'], $dir_loads.'/'.$newfile.'.'.$scr_ras);
}
}
}

}





if (user_access('loads_dir_delete') && isset($_GET['act']) && $_GET['act']=='delete_ok' && isset($_GET['ok']) && $l!=NULL)
{

if (@delete_dir($dir_loads))
{
$l=ereg_replace("^\.\./sys/loads/files", NULL, $dir_loads);
$path=(function_exists('iconv'))?iconv('windows-1251', 'utf-8', $l):$l;
$path=eregi_replace('^/*|/*$', '/', $path);
$dir_loads=ereg_replace('/[^/]*$', NULL, $dir_loads);
$l=ereg_replace("^\.\./sys/loads/files", NULL, $dir_loads);


admin_log('App Center','Folders',"Delete folder '$l'");
mysql_query("DELETE FROM `loads_list` WHERE `path` LIKE '".my_esc($path)."%'");
msg('The folder successfully deleted');
}
else
$err='Unable to delete a folder';
}



if (user_access('loads_dir_mesto') && isset($_GET['act']) && $_GET['act']=='mesto' && isset($_GET['ok']) && isset($_POST['path']) && $l!=NULL)
{
if ($_POST['path']==NULL)
$err= "Destination folder is not in select";
else
{

$new_dir=urldecode($_POST['path']).'/'.ereg_replace('^.*/', NULL, $dir_loads);

if (@rename($dir_loads, $new_dir))
{
$dir_loads=$new_dir;
$l=ereg_replace("^\.\./sys/loads/files/", NULL, $dir_loads);
msg('The folder successfully moved');
admin_log('App Center','Folders',"Moving folder '$l'");

$path2=(function_exists('iconv'))?iconv('windows-1251', 'utf-8', $l):$l;
$path2='/'.eregi_replace('^/+|/+$', null, $path2).'/';
$q=mysql_query("SELECT `path` FROM `loads_list` WHERE `path` LIKE '".my_esc($path)."%'");
while ($path_1=mysql_fetch_assoc($q)) {


mysql_query("UPDATE `loads_list` SET `path` = '".my_esc(str_replace($path,$path2,$path_1['path']))."' WHERE `path` = '".my_esc($path_1['path'])."'");
}




}
else
$err= "Unable to move the folder";
}
@unlink($dir_loads.'/.k_files');
}



if (user_access('loads_dir_rename') && isset($_GET['act']) && $_GET['act']=='rename' && isset($_GET['ok']) && isset($_POST['name']) && $l!=NULL)
{

if ($_POST['name']==NULL)
$err= "Enter the name of folder";
else
{

$newdir_serv=tr_loads(retranslit($_POST['name']));
$newdir_serv=ereg_replace('^\(([0-9]{1,3})\)_(.*)','\\1_\\2',$newdir_serv);
$new_dir=ereg_replace('/[^/]*$', NULL, $dir_loads).'/'.$newdir_serv;
if (@rename($dir_loads, $new_dir))
{
@chmod($dir_loads, 0777);
$dir_loads=$new_dir;
$l=ereg_replace("^\.\./sys/loads/files/", NULL, $dir_loads);
msg('The folder successfully renamed');
admin_log('App Center','Folders',"Rename the folder $newdir_loads in ".esc($_POST['name'],1));
$newdir_loads=esc($_POST['name'],1);



$newdir_loads=ereg_replace('^\(([0-9]{1,3})\)_(.*)','\\2',$newdir_loads);


$path2=(function_exists('iconv'))?iconv('windows-1251', 'utf-8', $l):$l;
$path2='/'.eregi_replace('^/+|/+$', null, $path2).'/';
$q=mysql_query("SELECT `path` FROM `loads_list` WHERE `path` LIKE '".my_esc($path)."%'");
while ($path_1=mysql_fetch_assoc($q)) {
mysql_query("UPDATE `loads_list` SET `path` = '".my_esc(str_replace($path,$path2,$path_1['path']))."' WHERE `path` = '".my_esc($path_1['path'])."'");
}

if ($f=@fopen($dir_loads.'/.dirname', 'w'))
{
@fwrite($f, $newdir_loads);
fclose($f);
@chmod($dir_loads.'/.dirname', 0777);
msg('The folder name is given');
}
else
{
$err= "Unable to set the folder name";
}
}
else
$err= "Can not rename the folder";
}
}



if (user_access('loads_dir_create') && isset($_GET['act']) && $_GET['act']=='mkdir' && isset($_GET['ok']) && isset($_POST['name']))
{

if ($_POST['name']==NULL)
$err= "Enter the folder name";
else
{
$newdir_serv=tr_loads(retranslit($_POST['name']));

$newdir_serv=ereg_replace('^\(([0-9]{1,3})\)_(.*)','\\1_\\2',$newdir_serv);

if (@mkdir($dir_loads.'/'.$newdir_serv, 0777))
{
@chmod($dir_loads.'/'.$newdir_serv, 0777);

msg('TThe folder successfully created');
$newdir_loads=esc($_POST['name'],1);

$newdir_loads=ereg_replace('^\(([0-9]{1,3})\)_(.*)','\\2',$newdir_loads);
if ($f=@fopen($dir_loads.'/'.$newdir_serv.'/.dirname', 'w'))
{
@fwrite($f, $newdir_loads);
fclose($f);
@chmod($dir_loads.'/'.$newdir_serv.'/.dirname', 0777);
msg('The folder name is given');
admin_log('App Center','Folders',"Create a folder '$newdir_loads' folder '".dir_name($dir_loads)."'");
}
else
{
$err= "Can not set the folder name";
}
}
else
$err= "Unable to create folder";
}
}

?>