<?
if (!isset($set['downloads_select']) || $set['downloads_select']=='0')
{
echo "<a href=\"/loads/down/".url2("$l/$file")."\">Download</a> (".k_loads($file,$size).")<br />\n";
echo "<input type='text' value='http://$_SERVER[SERVER_NAME]/loads/down/".url2("$l/$file")."' /><br />\n";
}
elseif(isset($user) && $set['downloads_select']=='1')
{
if (!isset($_SESSION['down_sess']))$_SESSION['down_sess']=md5(passgen());
$tmp_sess=$_SESSION['down_sess'];
$data_sess[]=array('l'=>$l,'file'=>$file,'time'=>$time, 'ip'=>$iplong);
if ($tmp_file=@file_get_contents(H.'sys/tmp/down_'.$_SESSION['down_sess'].'.dat'))
{
$tmp_array=unserialize($tmp_file);
for($iiii=0;$iiii<5 && $iiii<sizeof($tmp_array);$iiii++)
{
$data_sess[]=$tmp_array[$iiii];
}
}
file_put_contents(H.'sys/tmp/down_'.$_SESSION['down_sess'].'.dat', serialize($data_sess));
echo "<a href=\"/loads/down_$tmp_sess/".url2("$l/$file")."\">Download</a> (".k_loads($file,$size).")<br />\n";
echo "<input type='text' value='http://$_SERVER[SERVER_NAME]/loads/down_$tmp_sess/".url2("$l/$file")."' /><br />\n";
echo "* Link valid for 2 hours<br />\n";
}
elseif($user['balls']>=100 && $set['downloads_select']=='2')
{
if (!isset($_SESSION['down_sess']))$_SESSION['down_sess']=md5(passgen());
$tmp_sess=$_SESSION['down_sess'];
$data_sess[]=array('l'=>$l,'file'=>$file,'time'=>$time, 'ip'=>$iplong);
if ($tmp_file=@file_get_contents(H.'sys/tmp/down_'.$_SESSION['down_sess'].'.dat'))
{
$tmp_array=unserialize($tmp_file);
for($iiii=0;$iiii<5 && $iiii<sizeof($tmp_array);$iiii++)
{
$data_sess[]=$tmp_array[$iiii];
}
}
file_put_contents(H.'sys/tmp/down_'.$_SESSION['down_sess'].'.dat', serialize($data_sess));
echo "<a href=\"/loads/down_$tmp_sess/".url2("$l/$file")."\">Download</a> (".k_loads($file,$size).")<br />\n";
echo "<input type='text' value='http://$_SERVER[SERVER_NAME]/loads/down_$tmp_sess/".url2("$l/$file")."' /><br />\n";
echo "* Link valid for 2 hours<br />\n";
}
else
{
if ($set['downloads_select']=='2')
echo 'Downloading is available only to users who receives more than 100 points<br />';
if ($set['downloads_select']=='1')
echo 'To downloads this files, you must login or registration first<br />';
}
?>