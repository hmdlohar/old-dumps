<?

if (user_access('loads_dir_create') && isset($_GET['act']) && $_GET['act']=='mkdir')
{
echo "<form class=\"foot\" action=\"?".url("d=$l&amp;act=mkdir&amp;ok&amp;page=$page")."\" method=\"post\">";
echo "Folder name:<br />\n";
echo "<input type=\"text\" name=\"name\" value=\"\"/><br />\n";
echo "<input class=\"submit\" type=\"submit\" value=\"Create\" /><br />\n";
echo "&laquo;<a href=\"?".url("d=$l&amp;page=$page")."\">Cancel</a><br />\n";
echo "</form>";
}

if (user_access('loads_dir_rename') && isset($_GET['act']) && $_GET['act']=='rename' && $l!=NULL)
{
echo "<form class=\"foot\" action=\"?".url("d=$l&amp;act=rename&amp;ok&amp;page=$page")."\" method=\"post\">";
echo "Folder name:<br />\n";
$dirname=ereg_replace('^.*/', NULL, $dir_loads);
if (is_file($dir_loads.'/.dirname'))
$dirname=trim(esc(file_get_contents($dir_loads.'/.dirname')));
elseif (function_exists('iconv'))
$dirname=iconv('windows-1251', 'utf-8', $dirname);
$value=$dirname;

if (ereg('^([0-9]{1,3})_',ereg_replace('^.*/',NULL,$dir_loads),$num))
$value='('.$num[1].')_'.$dirname;





echo "<input type=\"text\" name=\"name\" value=\"$value\"/><br />\n";
echo "<input class=\"submit\" type=\"submit\" value=\"Rename\" /><br />\n";
echo "&laquo;<a href=\"?".url("d=$l&amp;page=$page")."\">Cancel</a><br />\n";
echo "</form>";
}


if (user_access('loads_dir_mesto') && isset($_GET['act']) && $_GET['act']=='mesto' && $l!=NULL)
{
echo "<form class=\"foot\" action=\"?".url("d=$l&amp;act=mesto&amp;ok&amp;page=$page")."\" method=\"post\">";
echo "New Path:<br />\n";
echo "<select class=\"submit\" name=\"path\">";

dirrs('../sys/loads/files','../sys/loads/files');
echo "</select><br />\n";
echo "<input class=\"submit\" type=\"submit\" value=\"Move\" /><br />\n";
echo "&laquo;<a href=\"?".url("d=$l&amp;page=$page")."\">Cancel</a><br />\n";
echo "</form>";
}

if (user_access('loads_dir_delete') && isset($_GET['act']) && $_GET['act']=='delete' && $l!=NULL)
{

echo "<div class=\"err\">";
$dirname=ereg_replace('^.*/', NULL, $dir_loads);
if (is_file($dir_loads.'/.dirname'))
$dirname=trim(esc(file_get_contents($dir_loads.'/.dirname')));
elseif (function_exists('iconv'))
$dirname=iconv('windows-1251', 'utf-8', $dirname);
echo "Delete the current folder ($dirname)?<br />\n";
echo "<a href=\"?".url("d=$l&amp;act=delete_ok&amp;ok&amp;page=$page")."\">Yes</a> \n";
echo "<a href=\"?".url("d=$l&amp;page=$page")."\">No</a><br />\n";
echo "</div>";
}




if (user_access('loads_file_upload') && isset($_GET['act']) && $_GET['act']=='upload' && $l!=null)
{
if(isset($_POST['k_forms']))$k_forms=intval($_POST['k_forms']);
elseif (isset($_SESSION['k_forms']))$k_forms=intval($_SESSION['k_forms']);
else $k_forms=1;
$_SESSION['k_forms']=$k_forms;
echo "<form class=\"foot\" enctype=\"multipart/form-data\" action=\"?".url("d=$l&amp;act=upload&amp;page=$page")."\" method=\"post\">";
echo "Number of upload files:<br />\n";
echo "<input type=\"text\" name=\"k_forms\" value=\"$k_forms\"/><br />\n";
echo "<input class=\"submit\" type=\"submit\" value=\"Accept\" /><br />\n";

for ($i=0;$i<$k_forms;$i++)
{
echo "File (".($i+1).") [&lt;".size_file($upload_max_filesize)."]:<br />\n";
echo "<input name=\"file_$i\" type=\"file\" /><br />\n";
echo "Screenshoot:<br />\n";
echo "<input name=\"scr_$i\" type=\"file\" accept='image/*,image/gif,image/png,image/jpeg' /><br />\n";
echo "Description:<br />\n";
echo "<textarea name='opis_$i'></textarea><br /><br />\n";
//echo "<input name=\"opis_$i\" type=\"text\" /><br /><br />\n";
}
echo "* Server can upload file up to ".size_file($upload_max_filesize)."<br />\n";
echo "<input class=\"submit\" name=\"ok\" type=\"submit\" value=\"Upload\" /><br />\n";
echo "&laquo;<a href=\"?".url("d=$l&amp;page=$page")."\">Cancel</a><br />\n";
echo "</form>";
}


if (user_access('loads_file_import') && isset($_GET['act']) && $_GET['act']=='import' && $l!=null)
{
if(isset($_POST['k_forms']))$k_forms=intval($_POST['k_forms']);
elseif (isset($_SESSION['k_forms']))$k_forms=intval($_SESSION['k_forms']);
else $k_forms=1;
$_SESSION['k_forms']=$k_forms;
echo "<form class=\"foot\" enctype=\"multipart/form-data\" action=\"?".url("d=$l&amp;act=import&amp;page=$page")."\" method=\"post\">";
echo "The number of imported file:<br />\n";
echo "<input type=\"text\" name=\"k_forms\" value=\"$k_forms\"/><br />\n";
echo "<input class=\"submit\" type=\"submit\" value=\"Accept\" /><br />\n";

for ($i=0;$i<$k_forms;$i++)
{
echo "File path (".($i+1)."):<br />\n";
echo "<input name=\"file_$i\" type=\"text\" /><br />\n";
echo "Save in page:<br />\n";
echo "<input name=\"scr_$i\" type=\"text\" /><br />\n";
echo "Filename (optional):<br />\n";
echo "<input name=\"name_$i\" type=\"text\" /><br />\n";
echo "Description:<br />\n";
echo "<textarea name='opis_$i'></textarea><br /><br />\n";
//echo "<input name=\"opis_$i\" type=\"text\" /><br /><br />\n";
}

echo "<input class=\"submit\" name=\"ok\" type=\"submit\" value=\"Import\" /><br />\n";
echo "&laquo;<a href=\"?".url("d=$l&amp;page=$page")."\">Cancel</a><br />\n";
echo "</form>";
}

if (user_access('loads_dir_create') || user_access('loads_dir_rename') && $l!=null || user_access('loads_dir_mesto') && $l!=null
 || user_access('loads_dir_delete') && $l!=null || user_access('loads_file_upload') && $l!=null || user_access('loads_file_import') && $l!=null)
{
echo "<div class=\"foot\">\n";

if (user_access('loads_dir_create'))
echo "&raquo;<a href=\"?".url("d=$l&amp;act=mkdir&amp;page=$page")."\">Create Folder</a><br />\n";

if ($l!=NULL){
if (user_access('loads_dir_rename'))
echo "&raquo;<a href=\"?".url("d=$l&amp;act=rename&amp;page=$page")."\">Rename Folder</a><br />\n";
if (user_access('loads_dir_mesto'))
echo "&raquo;<a href=\"?".url("d=$l&amp;act=mesto&amp;page=$page")."\">Move Folder</a><br />\n";
if (user_access('loads_dir_delete'))
echo "&raquo;<a href=\"?".url("d=$l&amp;act=delete&amp;page=$page")."\">Delete Folder</a><br />\n";


if (user_access('loads_file_upload') && $l!=null)
echo "&raquo;<a href=\"?".url("d=$l&amp;act=upload&amp;page=$page")."\">Upload Files</a><br />\n";
if (user_access('loads_file_import') && $l!=null)
echo "&raquo;<a href=\"?".url("d=$l&amp;act=import&amp;page=$page")."\">Import Files</a><br />\n";
}
echo "</div>\n";

}

?>