<?
if (function_exists('exec')){


if (isset($_POST['format']) && isset($_POST['bit']))
{
$all_path_input_file=realpath($dir_loads.'/'.$file);
$all_path_output_file=eregi_replace('.[^\.]*$', '.'.$_POST['format'], $all_path_input_file);

if (!file_exists($all_path_output_file))
{
$exec="ffmpeg -i $all_path_input_file -b ".$_POST['bit']." $all_path_output_file";
$exec=urlencode($exec);
if (function_exists('set_time_limit'))@set_time_limit(600); // Ограничиваем выполнение скрипта 10 минутами
@chmod($all_path_output_file, 0777);
$result=exec($exec);


echo "Convert<br />\n";
echo "From: $all_path_input_file<br />\n";
echo "In: $all_path_output_file<br />\n";
echo "Result: ".output_text($result)."<br />\n";
}
else
echo "$all_path_output_file exists<br />\n";

}
if (isset($_GET['act']) && $_GET['act']=='convert')
{
echo "This function is not tested and may lead to unpredictanle results<br />\n";
echo "This function also can lead to increased load on the server and as a consequence, locking account<br />\n";
echo "Using this feature is recomended only on a dedicated server<br />\n";

echo "<form method='post' action=''>\n";
echo "Output Format:<br />\n";
echo "<select name='format'>\n";
echo "<option value='flv'>FLV</option>\n";
echo "<option value='3gp'>3GP</option>\n";
echo "<option value='mp4'>MP4</option>\n";
echo "<option value='avi'>AVI</option>\n";
echo "</select>\n";

echo "<select name='bit'>\n";
echo "<option value='64k'>64KB\s</option>\n";
echo "<option value='128k'>128KB\s</option>\n";
echo "<option value='256k'>256KB\s</option>\n";
echo "</select><br />\n";


echo "<input type='submit' value='Start' />";
echo "</form>\n";
echo "<a href='?".url("d=$l&amp;f=$file")."'>Cancel</a><br />";
}
else
echo "<a href='?".url("d=$l&amp;f=$file")."&amp;act=convert'>Converter</a><br />";
}
?>