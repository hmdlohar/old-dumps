<?

if (user_access('loads_file_edit')  && isset($_GET['act']) && $_GET['act']=='prop')
{
echo "<form class=\"foot\" action=\"?".url("d=$l&amp;act=prop&amp;ok&amp;f=$file&amp;page=$_SESSION[page]")."\" method=\"post\">";



if (function_exists('iconv'))$jfile=iconv('windows-1251', 'utf-8', $file);else $jfile=$file;

$name=eregi_replace('\.[^\.]*$', NULL, $jfile); // имя файла без расширения
$ras=strtolower(eregi_replace('^.*\.', NULL, $jfile)); // расширение (в нижнем регистре)

echo "Filename on server:<br />\n";
echo "<input type=\"text\" name=\"name_serv\" value=\"$name\" />.<input type=\"text\" size='3' name=\"ras_serv\" value=\"$ras\" /><br />\n";



echo "Filename to load:<br />\n";
echo "<input type=\"text\" name=\"name_loads\" value=\"$name2\"/><br />\n";
echo "Description:<br />\n";

$opis=NULL;
if (is_file($dir_loads.'/'.$file.'.opis')) // проверка описания
$opis = trim(esc(implode(NULL,file($dir_loads.'/'.$file.'.opis'))));
elseif (is_file($dir_loads.'/'.$file.'.txt')) // проверка описания в txt файле
$opis = trim(esc(implode(NULL,file($dir_loads.'/'.$file.'.txt'))));

echo "<input type=\"text\" name=\"opis\" value=\"$opis\"/><br />\n";
echo "<textarea name='opis'>$opis</textarea><br />\n";

echo "<input class=\"submit\" type=\"submit\" value=\"Edit\" /><br />\n";
echo "<a href=\"?".url("d=$l&amp;f=$file&amp;page=$_SESSION[page]")."\">Отмена</a><br />\n";
echo "</form>";
}

if (user_access('loads_file_delete') && isset($_GET['act']) && $_GET['act']=='delete')
{

echo "<div class=\"err\">";
echo "Confirm delete a file?<br />\n";
echo "<a href=\"?".url("d=$l&amp;act=delete&amp;ok&amp;f=$file&amp;page=$_SESSION[page]")."\">Yes</a> \n";
echo "<a href=\"?".url("d=$l&amp;f=$file&amp;page=$_SESSION[page]")."\">No</a><br />\n";
echo "</div>";
}



if (user_access('loads_file_edit') || user_access('loads_file_delete'))
{
echo "<div class=\"foot\">\n";
if (user_access('loads_file_edit'))
echo "&raquo;<a href=\"?".url("d=$l&amp;act=prop&amp;f=$file&amp;page=$_SESSION[page]")."\">Modify</a><br />\n";
if (user_access('loads_file_delete'))
echo "&raquo;<a href=\"?".url("d=$l&amp;act=delete&amp;f=$file&amp;page=$_SESSION[page]")."\">Delete Files</a><br />\n";
echo "</div>\n";
}




?>