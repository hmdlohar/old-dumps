<?
if (is_file(H."loads/inc/opis/$ras.php"))include H."loads/inc/opis/$ras.php";
else
{
echo 'Size: '.size_file($size)."<br />\n";
echo 'Added: '.vremja(filectime($dir_loads.'/'.$dirlist[$i]))."<br />\n";
}





$l2=$l;
if (function_exists('iconv'))$l2=iconv('windows-1251', 'utf-8', $l2);
$jfile=eregi_replace('\.jad$', '.jar', $dirlist[$i]);
$size=filesize($dir_loads.'/'.$jfile);
if (function_exists('iconv'))$jfile=iconv('windows-1251', 'utf-8', $jfile);

$path=(function_exists('iconv'))?iconv('windows-1251', 'utf-8', $l):$l;
$path='/'.eregi_replace('^/+|/+$', null, $path).'/';
$loads=mysql_fetch_assoc(mysql_query("SELECT * FROM `loads_list` WHERE `name` = '$jfile' AND `size` = '$size' AND `path` = '".my_esc($path)."' LIMIT 1"));
if ($loads==NULL)
mysql_query("INSERT INTO `loads_list` (`name`, `size`,  `path`, `time`) values('".my_esc($jfile)."', '$size', '".my_esc($path)."', '".filectime($dir_loads.'/'.$dirlist[$i])."')");


?>