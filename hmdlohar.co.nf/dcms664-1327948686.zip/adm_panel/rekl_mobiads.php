<?
include_once '../sys/inc/start.php';
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
$temp_set=$set;
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/adm_check.php';
include_once '../sys/inc/user.php';
user_access('adm_rekl',null,true);
adm_check();

$set['title']='Реклама MOBIADS.RU';
include_once '../sys/inc/thead.php';
title();


if (isset($_POST['mobiads_id']) && isset($_POST['mobiads_code']) && isset($_POST['mobiads_num_links']))
{
$temp_set['mobiads_id']=intval($_POST['mobiads_id']);
$temp_set['mobiads_code']=esc($_POST['mobiads_code']);
$temp_set['mobiads_num_links']=intval($_POST['mobiads_num_links']);
if (save_settings($temp_set))
msg('Настройки успешно приняты');
else
$err='Нет прав для изменения файла настроек';
}
err();
aut();

echo "<form method=\"post\" action=\"?\">\n";

echo "ID клиента:<br />\n<input name=\"mobiads_id\" value=\"$temp_set[mobiads_id]\" type=\"text\" /><br />\n";
echo "CODE клиента:<br />\n<input name=\"mobiads_code\" value=\"$temp_set[mobiads_code]\" type=\"text\" /><br />\n";
echo "Количество ссылок:<br />\n<input name=\"mobiads_num_links\" value=\"$temp_set[mobiads_num_links]\" type=\"text\" /><br />\n";
echo "<input value=\"Изменить\" type=\"submit\" />\n";
echo "</form>\n";



echo "Регистрация своего ID на сайте <a target='_blank' href='http://mobiads.ru'>mobiads.ru</a><br />\n";
echo "* Для удаления рекламы в поле \"Количество ссылок\" поставьте \"0\"<br />\n";
if ($set['rekl']!='mobiads')
echo "** <b>Для использования рекламы, ее необходимо выбрать в <a href='rekl_select.php'>настройках</a></b><br />\n";
echo "<div class='foot'>\n";
echo "&laquo;<a href='/adm_panel/rekl.php'>Реклама</a><br />\n";
if (user_access('adm_panel_show'))
echo "&laquo;<a href='/adm_panel/'>В админку</a><br />\n";
echo "</div>\n";


include_once '../sys/inc/tfoot.php';
?>