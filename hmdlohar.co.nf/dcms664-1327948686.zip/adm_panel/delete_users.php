<?
include_once '../sys/inc/start.php';
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/adm_check.php';
include_once '../sys/inc/user.php';
user_access('user_mass_delete',null,'index.php?'.SID);
adm_check();
$set['title']='Deleting Users';
include_once '../sys/inc/thead.php';
title();
if (isset($_POST['write']) && isset($_POST['write2']))
{
$timeclear1=0;
if ($_POST['write2']=='sut')$timeclear1=$time-intval($_POST['write'])*60*60*24;
elseif ($_POST['write2']=='mes')$timeclear1=$time-intval($_POST['write'])*60*60*24*30;
else $err[]='Net selected period';
$q = mysql_query("SELECT * FROM `user` WHERE `date_last` < '$timeclear1'",$db);
$del_th=0;
while ($post = mysql_fetch_assoc($q))
{

$ank['id']=&$post['id'];

mysql_query("DELETE FROM `user` WHERE `id` = '$ank[id]' LIMIT 1");
mysql_query("DELETE FROM `chat_post` WHERE `id_user` = '$ank[id]'");


$q5=mysql_query("SELECT * FROM `forum_t` WHERE `id_user` = '$ank[id]'");
while ($post5 = mysql_fetch_assoc($q5))
{
mysql_query("DELETE FROM `forum_p` WHERE `id_them` = '$post5[id]'");
}
mysql_query("DELETE FROM `forum_t` WHERE `id_user` = '$ank[id]'");


mysql_query("DELETE FROM `forum_p` WHERE `id_user` = '$ank[id]'");
mysql_query("DELETE FROM `forum_zakl` WHERE `id_user` = '$ank[id]'");
mysql_query("DELETE FROM `guest` WHERE `id_user` = '$ank[id]'");
mysql_query("DELETE FROM `loads_komm` WHERE `id_user` = '$ank[id]'");
mysql_query("DELETE FROM `news_komm` WHERE `id_user` = '$ank[id]'");


$opdirbase=@opendir(H.'sys/add/delete_user_act');
while ($filebase=@readdir($opdirbase))
if (eregi('\.php$',$filebase))
include_once(H.'sys/add/delete_user_act/'.$filebase);

$q5=mysql_query("SELECT * FROM `obmennik_files` WHERE `id_user` = '$ank[id]'");
while ($post5 = mysql_fetch_assoc($q5))
{
unlink(H.'sys/obmen/files/'.$post5['id'].'.dat');
}


mysql_query("DELETE FROM `obmennik_files` WHERE `id_user` = '$ank[id]'");

mysql_query("DELETE FROM `users_konts` WHERE `id_user` = '$ank[id]' OR `id_kont` = '$ank[id]'");
mysql_query("DELETE FROM `mail` WHERE `id_user` = '$ank[id]' OR `id_kont` = '$ank[id]'");
mysql_query("DELETE FROM `user_voice` WHERE `id_user` = '$ank[id]' OR `id_kont` = '$ank[id]'");
mysql_query("DELETE FROM `user_collision` WHERE `id_user` = '$ank[id]' OR `id_user2` = '$ank[id]'");
mysql_query("DELETE FROM `votes_user` WHERE `u_id` = '$ank[id]'");





$del_th++;
}
mysql_query("OPTIMIZE TABLE `user`",$db);
msg ("Removed $del_th users");
}
err();
aut();




echo "<form method=\"post\" class='foot' action=\"?\">\n";
echo "This will delete users who dont visit a site<br />\n";
echo "<input name=\"write\" value=\"6\" type=\"text\" size='3' />\n";
echo "<select name=\"write2\">\n";
echo "<option value=\"\">       </option>\n";
echo "<option value=\"mes\">Months</option>\n";
echo "<option value=\"sut\">Days</option>\n";
echo "</select><br />\n";
echo "<input value=\"Remove\" type=\"submit\" /><br />\n";
echo "<a href=\"?\">Cancel</a><br />\n";
echo "</form>\n";
if (user_access('adm_panel_show')){
echo "<div class='foot'>\n";
echo "&laquo;<a href='/adm_panel/'>Admin Panel</a><br />\n";
echo "</div>\n";
}
include_once '../sys/inc/tfoot.php';
?>