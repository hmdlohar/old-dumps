<?
include_once 'sys/inc/start.php';
include_once 'sys/inc/compress.php';
include_once 'sys/inc/sess.php';
include_once 'sys/inc/home.php';
include_once 'sys/inc/settings.php';
include_once 'sys/inc/db_connect.php';
include_once 'sys/inc/ipua.php';
include_once 'sys/inc/fnc.php';
include_once 'sys/inc/user.php';
only_reg(); 



switch (@$_GET['type']) {
case 'favorite':
$type='favorite';
$type_name='Favorites';
break;
case 'ignor':
$type='ignor';
$type_name='Ignored';
break;
case 'deleted':
$type='deleted';
$type_name='Deleted';
break;
default:
$type='common';
$type_name='General';
break;
}


$set['title']=$type_name.' contacts';
include_once 'sys/inc/thead.php';
title();




if (isset($_GET['id']))
{
$ank=get_user($_GET['id']);
if ($ank)
{
if (isset($_GET['act']))
{
switch ($_GET['act']) {
case 'add':
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `id_kont` = '$ank[id]'"), 0)==1)
$err[]='This user is already in your contacts list';
else
{
mysql_query("INSERT INTO `users_konts` (`id_user`, `id_kont`, `time`) VALUES ('$user[id]', '$ank[id]', '$time')");
msg ('Contact successfully added');
}

break;
case 'del':
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `id_kont` = '$ank[id]'"), 0)==0)
$warn[]='This user is not in your contact list';
else
{
mysql_query("UPDATE `users_konts` SET `type` = 'deleted', `time` = '$time' WHERE `id_user` = '$user[id]' AND `id_kont` = '$ank[id]' LIMIT 1");
msg ('Contacts was successfully deleted or moved to the remote');
$type='deleted';
}
break;
}
}
}
else
$err[]='Users not found';
}

if (isset($_GET['act']) && $_GET['act']==='edit_ok' && isset($_GET['id']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `id` = '".intval($_GET['id'])."' LIMIT 1"),0)==1)
{
$ank=get_user(intval($_GET['id']));
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `id_kont` = '$ank[id]'"), 0)==1)
{
$kont=mysql_fetch_array(mysql_query("SELECT * FROM `users_konts` WHERE `id_user` = '$user[id]' AND `id_kont` = '$ank[id]'"));
if (isset($_POST['name']) && $_POST['name']!=($kont['name']!=null?$kont['name']:$ank['nick']))
{
if (eregi('[^a-zA-Z0-9\-_\.,\[\]\(\)]', $_POST['name']))$err[]='The name of the contact presence of prohibited characters';
if (strlen($_POST['name'])>64)$err[]='Name of contact longer than 64 characters';

if (!isset($err))
{
mysql_query("UPDATE `users_konts` SET `name` = '".mysql_real_escape_string($_POST['name'])."' WHERE `id_user` = '$user[id]' AND `id_kont` = '$ank[id]' LIMIT 1");
msg ('Contacts was successfully renamed');
}
}

if (isset($_POST['type']) && mb_ereg('^(common|ignor|favorite|deleted)$',$_POST['type']) && $_POST['type']!=$type)
{
mysql_query("UPDATE `users_konts` SET `type` = '$_POST[type]', `time` = '$time' WHERE `id_user` = '$user[id]' AND `id_kont` = '$ank[id]' LIMIT 1");
msg ('The contacts was successfully transferred');
}

}
else
$err[]='Contacts not found';
}

aut();
err();


if ($type=='deleted')echo "Contacts of this group are deleted after 30 days<br />\n";
if ($type=='ignor')echo "Notice of messages from those contacts do not appear<br />\n";
if ($type=='favorite')echo "Notice of messages from those contacts are allocated<br />\n";


$k_post=mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `type` = '$type'"), 0);
echo "Contacts: $k_post<br />\n";

if ($k_post){

$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];
echo "<table class='post'>\n";
$q=mysql_query("SELECT * FROM `users_konts` WHERE `id_user` = '$user[id]' AND `type` = '$type' ORDER BY `time` DESC, `new_msg` DESC LIMIT $start, $set[p_str]");
while ($post = mysql_fetch_array($q))
{
$ank_kont=get_user($post['id_kont']);
$k_mess=mysql_result(mysql_query("SELECT COUNT(*) FROM `mail` WHERE `id_user` = '$ank_kont[id]' AND `id_kont` = '$user[id]'"), 0);
$k_new_mess=mysql_result(mysql_query("SELECT COUNT(*) FROM `mail` WHERE `id_user` = '$ank_kont[id]' AND `id_kont` = '$user[id]' AND `read` = '0'"), 0);





echo "   <tr>\n";
if ($set['set_show_icon']==2){
echo "  <td class='icon48' rowspan='2'>\n";
avatar($ank_kont['id']);
echo "  </td>\n";
}
elseif ($set['set_show_icon']==1)
{
echo "  <td class='icon14'>\n";
echo "<img src='/style/themes/$set[set_them]/user/$ank_kont[pol].png' alt='' />";
echo "  </td>\n";
}
echo "  <td class='p_t'>\n";
echo ($k_new_mess!=0?'<span class="off">[new]</span> ':null)."<a href=\"/mail.php?id=$ank_kont[id]\">".($post['name']!=null?$post['name']:$ank_kont['nick'])."</a>".online($ank_kont['id'])."\n";
echo ($k_new_mess!=0?'<b>':null)."(".($k_new_mess!=0?'+'.$k_new_mess:$k_mess).")".($k_new_mess!=0?'</b>':null);
echo "  </td>\n";
echo "   </tr>\n";

echo "   <tr>\n";
if ($set['set_show_icon']==1)echo "  <td class='p_m' colspan='2'>\n"; else echo "  <td class='p_m'>\n";
echo "<a href=\"/info.php?id=$ank_kont[id]\">View Profile</a><br />\n";
if ($type!='deleted')echo "<a href='/konts.php?type=$type&amp;act=del&amp;id=$ank_kont[id]'>Delete contacts from list</a><br />\n";


if (isset($_GET['act']) && $_GET['act']==='edit' && isset($_GET['id']) && $_GET['id']==$ank_kont['id'])
{
echo "<form method='post' action='?type=$type&amp;act=edit_ok&amp;id=$ank_kont[id]&amp;page=$page'>\n";
echo "Display as:<br />\n";
echo "<input type='text' maxlenght='64' name='name' value='".($post['name']!=null?$post['name']:$ank_kont['nick'])."' /><br />\n";
echo "Group:<br />\n";
echo "<select name='type'>\n";
echo "<option value='common'".($type=='common'?" selected='selected'":null).">General</option>\n";
echo "<option value='favorite'".($type=='favorite'?" selected='selected'":null).">Favorite</option>\n";
echo "<option value='ignor'".($type=='ignor'?" selected='selected'":null).">Ignored</option>\n";
echo "<option value='deleted'".($type=='deleted'?" selected='selected'":null).">Deleted</option>\n";
echo "</select><br />\n";
echo "<input type='submit' name='apply' value='Apply' /><br />\n";
echo "</form>\n";
echo "<a href='?type=$type&amp;id=$ank_kont[id]&amp;page=$page'>Cancel</a><br />\n";
}
else
{
echo "<a href='?type=$type&amp;act=edit&amp;id=$ank_kont[id]&amp;page=$page'>Edit</a><br />\n";
}



echo "  </td>\n";
echo "   </tr>\n";
}

echo "</table>\n";


if ($k_page>1)str("?type=$type&amp;",$k_page,$page); // Вывод страниц
}
echo "<div class='menu'>";
//echo "<b>Group:</b><br />\n";
echo ($type=='common'?'<b>':null)."<a href='?type=common'>General</a>".($type=='common'?'</b>':null)." (".mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `type` = 'common'"), 0).")<br />\n";
echo ($type=='favorite'?'<b>':null)."<a href='?type=favorite'>Favorite</a>".($type=='favorite'?'</b>':null)." (".mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `type` = 'favorite'"), 0).")<br />\n";
echo ($type=='ignor'?'<b>':null)."<a href='?type=ignor'>Ignored</a>".($type=='ignor'?'</b>':null)."<br />\n";
echo ($type=='deleted'?'<b>':null)."<a href='?type=deleted'>Deleted</a>".($type=='deleted'?'</b>':null)."<br />\n";
echo "</div>\n";
echo "<div class='foot'>\n";
if(isset($_SESSION['refer']) && $_SESSION['refer']!=NULL && otkuda($_SESSION['refer']))
echo "&laquo;<a href='$_SESSION[refer]'>".otkuda($_SESSION['refer'])."</a><br />\n";
echo "&laquo;<a href='umenu.php'>Back</a><br />\n";
echo "</div>\n";
include_once 'sys/inc/tfoot.php';
?>