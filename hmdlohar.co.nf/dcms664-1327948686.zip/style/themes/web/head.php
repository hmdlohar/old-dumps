<?
$set['web']=true;
$set['set_show_icon']=2;
//header("Content-type: application/xhtml+xml");
header("Content-type: text/html");
echo '<?xml version="1.0" encoding="utf-8"?>';
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?echo $set['title'];?></title>
<link rel="shortcut icon" href="/favicon.ico" />

<link rel="stylesheet" href="/style/themes/<?echo $set['set_them'];?>/body.css" type="text/css" />
<link rel="stylesheet" href="/style/themes/<?echo $set['set_them'];?>/tables.css" type="text/css" />
<link rel="stylesheet" href="/style/themes/<?echo $set['set_them'];?>/style.css" type="text/css" />
<link rel="stylesheet" href="/style/themes/<?echo $set['set_them'];?>/block.css" type="text/css" />
<script src="/style/themes/<?echo $set['set_them'];?>/js.js" type="text/javascript" language="JavaScript" charset="utf-8"></script>
<link rel="alternate" title="RSS News" href="/news/rss.php" type="application/rss+xml" />
</head>
<body>
<div class="body">
<?include_once H.'style/themes/'.$set['set_them'].'/title.php';
?>
<table class="table_body" cellspacing="0" cellpadding="0">
<tr>
<td class='table_left'>


<?
include_once H.'style/themes/'.$set['set_them'].'/rekl.php';
include_once H.'style/themes/'.$set['set_them'].'/menu.php';
?>


</td><td class='table_center'>
<?
if ($_SERVER['PHP_SELF']!='/index.php'){
?>

<table class='table_block2' cellspacing="0" cellpadding="0">
<tr>
<td class='block11'>
&nbsp;
</td>
<td class='block12'>
<?echo $set['title'];?>
</td>
<td class='block13'>
&nbsp;
</td>
</tr>
<tr>
<td class='block21'>

</td>
<td class='block22'>
<?}?>

