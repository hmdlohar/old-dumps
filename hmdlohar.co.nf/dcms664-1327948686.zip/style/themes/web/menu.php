<table class='table_block' cellspacing="0" cellpadding="0">
<tr>
<td class='block11'>
&nbsp;
</td>
<td class='block12'>
Navigation
</td>
<td class='block13'>
&nbsp;
</td>
</tr>
<tr>
<td class='block21'></td>
<td class='block22'>
<div class='main_menu'>
<?
include_once H.'sys/inc/main_menu.php';
?>
</div>
</td>
<td class='block23'></td>
</tr>
<tr>
<td class='block31'>
&nbsp;
</td>
<td class='block32'>
&nbsp;
</td>
<td class='block33'>
&nbsp;
</td>
</tr>
</table>