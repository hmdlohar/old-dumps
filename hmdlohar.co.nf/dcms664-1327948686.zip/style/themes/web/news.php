<?

$q=mysql_query("SELECT * FROM `news` WHERE `main_time` > '".time()."' ORDER BY `id` DESC LIMIT 1");
if (mysql_num_rows($q)==1)
{
$news = mysql_fetch_assoc($q);

?>
<table class='table_block2' cellspacing="0" cellpadding="0">
<tr>
<td class='block11'>
&nbsp;
</td>
<td class='block12'>
<a href='/news/'><?echo $news['title'];?></a>
</td>
<td class='block13'>
&nbsp;
</td>
</tr>
<tr>
<td class='block21'>
</td>
<td class='block22'>
<div class='news'>
<?
echo trim(br(bbcode(smiles(links(stripcslashes(htmlspecialchars($news['msg'])))))))."<br />\n";
if ($news['link']!=NULL)echo "<a href='$news[link]'>Details</a><br />\n";
echo "<a href='/news/komm.php?id=$news[id]'>Comments (".mysql_result(mysql_query("SELECT COUNT(*) FROM `news_komm` WHERE `id_news` = '$news[id]'"),0).")<br />\n";
?>
</div>
</td>
<td class='block23'>
</td>
</tr>
<tr>
<td class='block31'>
&nbsp;
</td>
<td class='block32'>
&nbsp;
</td>
<td class='block33'>
&nbsp;
</td>
</tr>
</table>
<?

}

?>