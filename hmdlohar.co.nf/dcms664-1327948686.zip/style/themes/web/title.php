<table class="title" cellspacing="0" cellpadding="0">
<tr style='height:88px;'>
<td>
<img src='/style/themes/<?echo $set['set_them'];?>/title/logo.png' alt='' />
</td>
</tr>
<tr>
<td>
<table align="center">
<tr>
<td class='buttom'><a href='/'>Home</a></td>
<td class='buttom'><a href='/forum/'>Forum</a></td>
<td class='buttom'><a href='/loads/'>Downloads</a></td>
<td class='buttom'><a href='/guest/'>Guestbook</a></td>
</tr>
</table>
</td>
</tr>
</table>