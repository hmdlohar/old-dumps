<table class='table_block2' cellspacing="0" cellpadding="0">
<tr>
<td class='block11'>
&nbsp;
</td>
<td class='block12'>
Topics with New Posts
</td>
<td class='block13'>
&nbsp;
</td>
</tr>
<tr>
<td class='block21'>
</td>
<td class='block22'>
<?

$adm_add2=NULL;
if (!isset($user) || $user['level']==0){
$q222=mysql_query("SELECT * FROM `forum_f` WHERE `adm` = '1'");
while ($adm_f = mysql_fetch_assoc($q222))
{
$adm_add[]="`id_forum` <> '$adm_f[id]'";
}
if (sizeof($adm_add)!=0)
$adm_add2=' WHERE'.implode(' AND ', $adm_add);
}


echo "<table class='post'>\n";
$q=mysql_query("SELECT * FROM `forum_t`$adm_add2 ORDER BY `time` DESC LIMIT 5");

while ($them = mysql_fetch_assoc($q))
{


$forum=mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_f` WHERE `id` = '$them[id_forum]' LIMIT 1"));
$razdel=mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_r` WHERE `id` = '$them[id_razdel]' LIMIT 1"));
//$them=mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_t` WHERE `id` = '$post[id_them]' LIMIT 1"));
$ank=mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = $them[id_user] LIMIT 1"));


echo "   <tr>\n";
if ($set['set_show_icon']==2){
echo "  <td class='icon48' rowspan='2'>\n";
echo "<img src='/style/themes/$set[set_them]/forum/48/them_$them[up]$them[close].png' />";
echo "  </td>\n";
}
elseif ($set['set_show_icon']==1)
{
echo "  <td class='icon14'>\n";
echo "<img src='/style/themes/$set[set_them]/forum/14/them_$them[up]$them[close].png' alt='' />";
echo "  </td>\n";
}


echo "  <td class='p_t'>\n";
echo "<a href='/forum/$forum[id]/$razdel[id]/$them[id]/'>$them[name]</a> <a href='/forum/$forum[id]/$razdel[id]/$them[id]/?page=end'>(".mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_p` WHERE `id_forum` = '$forum[id]' AND `id_razdel` = '$razdel[id]' AND `id_them` = '$them[id]'"),0).")</a>\n";
echo "  </td>\n";
echo "   </tr>\n";


echo "   <tr>\n";
if ($set['set_show_icon']==1)echo "  <td class='p_m' colspan='2'>\n"; else echo "  <td class='p_m'>\n";


echo "<a href='/forum/$forum[id]/'>$forum[name]</a> &gt; <a href='/forum/$forum[id]/$razdel[id]/'>$razdel[name]</a><br />\n";

$post1=mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_p` WHERE `id_them` = '$them[id]' AND `id_razdel` = '$razdel[id]' AND `id_forum` = '$forum[id]' ORDER BY `time` ASC LIMIT 1"));
$ank=mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = $post1[id_user] LIMIT 1"));
echo "Author: <a href='/info.php?id=$ank[id]' title='Profile \"$ank[nick]\"'>$ank[nick]</a> (".vremja($them['time_create']).")<br />\n";

$post=mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_p` WHERE `id_them` = '$them[id]' AND `id_razdel` = '$razdel[id]' AND `id_forum` = '$forum[id]' ORDER BY `time` DESC LIMIT 1"));
$ank2=mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = $post[id_user] LIMIT 1"));
echo "Last.: <a href='/info.php?id=$ank2[id]' title='Profile \"$ank2[nick]\"'>$ank2[nick]</a> (".vremja($post['time']).")<br />\n";
echo "  </td>\n";
echo "   </tr>\n";

}
echo "</table>\n";

?>
</td>
<td class='block23'>

</td>
</tr>
<tr>
<td class='block31'>
&nbsp;
</td>
<td class='block32'>
&nbsp;
</td>
<td class='block33'>
&nbsp;
</td>
</tr>
</table>








<table class='table_block2' cellspacing="0" cellpadding="0">
<tr>
<td class='block11'>
&nbsp;
</td>
<td class='block12'>
New Topics
</td>
<td class='block13'>
&nbsp;
</td>
</tr>
<tr>
<td class='block21'>
</td>
<td class='block22'>
<?

$adm_add2=NULL;
if (!isset($user) || $user['level']==0){
$q222=mysql_query("SELECT * FROM `forum_f` WHERE `adm` = '1'");
while ($adm_f = mysql_fetch_assoc($q222))
{
$adm_add[]="`id_forum` <> '$adm_f[id]'";
}
if (sizeof($adm_add)!=0)
$adm_add2=' WHERE'.implode(' AND ', $adm_add);
}


echo "<table class='post'>\n";
$q=mysql_query("SELECT * FROM `forum_t`$adm_add2 ORDER BY `time_create` DESC LIMIT 5");

while ($them = mysql_fetch_assoc($q))
{


$forum=mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_f` WHERE `id` = '$them[id_forum]' LIMIT 1"));
$razdel=mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_r` WHERE `id` = '$them[id_razdel]' LIMIT 1"));
//$them=mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_t` WHERE `id` = '$post[id_them]' LIMIT 1"));
$ank=mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = $them[id_user] LIMIT 1"));


echo "   <tr>\n";
if ($set['set_show_icon']==2){
echo "  <td class='icon48' rowspan='2'>\n";
echo "<img src='/style/themes/$set[set_them]/forum/48/them_$them[up]$them[close].png' />";
echo "  </td>\n";
}
elseif ($set['set_show_icon']==1)
{
echo "  <td class='icon14'>\n";
echo "<img src='/style/themes/$set[set_them]/forum/14/them_$them[up]$them[close].png' alt='' />";
echo "  </td>\n";
}


echo "  <td class='p_t'>\n";
echo "<a href='/forum/$forum[id]/$razdel[id]/$them[id]/'>$them[name]</a> <a href='/forum/$forum[id]/$razdel[id]/$them[id]/?page=end'>(".mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_p` WHERE `id_forum` = '$forum[id]' AND `id_razdel` = '$razdel[id]' AND `id_them` = '$them[id]'"),0).")</a>\n";
echo "  </td>\n";
echo "   </tr>\n";


echo "   <tr>\n";
if ($set['set_show_icon']==1)echo "  <td class='p_m' colspan='2'>\n"; else echo "  <td class='p_m'>\n";


echo "<a href='/forum/$forum[id]/'>$forum[name]</a> &gt; <a href='/forum/$forum[id]/$razdel[id]/'>$razdel[name]</a><br />\n";

$post1=mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_p` WHERE `id_them` = '$them[id]' AND `id_razdel` = '$razdel[id]' AND `id_forum` = '$forum[id]' ORDER BY `time` ASC LIMIT 1"));
$ank=mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = $post1[id_user] LIMIT 1"));
echo "Author: <a href='/info.php?id=$ank[id]' title='Profile \"$ank[nick]\"'>$ank[nick]</a> (".vremja($them['time_create']).")<br />\n";

$post=mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_p` WHERE `id_them` = '$them[id]' AND `id_razdel` = '$razdel[id]' AND `id_forum` = '$forum[id]' ORDER BY `time` DESC LIMIT 1"));
$ank2=mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = $post[id_user] LIMIT 1"));
echo "Last.: <a href='/info.php?id=$ank2[id]' title='Profile \"$ank2[nick]\"'>$ank2[nick]</a> (".vremja($post['time']).")<br />\n";
echo "  </td>\n";
echo "   </tr>\n";

}
echo "</table>\n";

?>
</td>
<td class='block23'>

</td>
</tr>
<tr>
<td class='block31'>
&nbsp;
</td>
<td class='block32'>
&nbsp;
</td>
<td class='block33'>
&nbsp;
</td>
</tr>
</table>









<table class='table_block2' cellspacing="0" cellpadding="0">
<tr>
<td class='block11'>
&nbsp;
</td>
<td class='block12'>
New Files
</td>
<td class='block13'>
&nbsp;
</td>
</tr>
<tr>
<td class='block21'>
</td>
<td class='block22'>
<?


echo "<table class='post'>\n";


$q=mysql_query("SELECT `name`, `path`, `size` FROM `loads_list` ORDER BY `time` DESC LIMIT 5");


if (mysql_num_rows($q)==0){
echo "   <tr>\n";
echo "  <td class='p_t'>\n";
echo "Empty\n";
echo "  </td>\n";
echo "   </tr>\n";
}

while ($post = mysql_fetch_assoc($q))
{
$i=passgen();
echo "   <tr>\n";
$l=$post['path'];
$l=ereg_replace("\./|/\.",NULL,$l);
$l=ereg_replace("(/){1,}","/",$l);
$l=ereg_replace("(^(/){1,})|((/){1,}$)","",$l);


$dir_loads=H.'sys/loads/files/'.$l;
$dirlist[$i]=$post['name'];
if (function_exists('iconv'))$dirlist[$i]=iconv('utf-8', 'windows-1251', $dirlist[$i]);
$ras=strtolower(eregi_replace('^.*\.', NULL, $dirlist[$i]));
$name=eregi_replace('\.[^\.]*$', NULL, $dirlist[$i]);

if (is_file($dir_loads.'/'.$dirlist[$i].'.name'))
$name2=trim(esc(file_get_contents($dir_loads.'/'.$dirlist[$i].'.name')));
elseif (function_exists('iconv'))
$name2=iconv('windows-1251', 'utf-8', $name);
else $name2=$name;
$name2=htmlspecialchars($name2);
$size=$post['size'];
if ($set['set_show_icon']==2){
echo "  <td rowspan='2' class='icon48'>\n";
include H.'loads/inc/icon48.php';
echo "  </td>\n";
}
elseif ($set['set_show_icon']==1){
echo "  <td class='icon14'>\n";
include H.'loads/inc/icon14.php';
echo "  </td>\n";
}
echo "  <td class='p_t'>\n";
if ($set['echo_rassh']==1)$ras2=".$ras";else $ras2=NULL;
echo "<a href='/loads/?d=".urlencode("$l")."&amp;f=".urlencode("$dirlist[$i]")."'>$name2$ras2</a>\n";
echo "  </td>\n";
echo "   </tr>\n";
echo "   <tr>\n";
if ($set['set_show_icon']==1)echo "  <td class='p_m' colspan='2'>\n"; else echo "  <td class='p_m'>\n";
include H.'loads/inc/opis.php';
echo "  </td>\n";
echo "   </tr>\n";
}
echo "</table>\n";

?>
</td>
<td class='block23'>

</td>
</tr>
<tr>
<td class='block31'>
&nbsp;
</td>
<td class='block32'>
&nbsp;
</td>
<td class='block33'>
&nbsp;
</td>
</tr>
</table>