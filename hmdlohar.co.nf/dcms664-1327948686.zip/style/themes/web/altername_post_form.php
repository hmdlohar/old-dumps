<table width='100%'>
<tr>
<td>
Message:
</td>
</tr>
<tr>
<td>
<textarea width='100%' name="msg"
onselect="storeCaret(this);"
onclick="storeCaret(this);"
onkeyup="storeCaret(this);"
onkeypress="if((event.ctrlKey) && ((event.keyCode==10)||(event.keyCode==13))) {this.form.submit();}"><? echo isset($msg2)?$msg2:null; ?></textarea><br />
</td>
<td width='200'>

<table height='150' style='border: 2px outset #D0CFFF; background-color:#4C5E90;' >
<tr style='background-color:#9EA2C6; height:16px; text-align:center;'>
<td><a href="javascript:view_block('smiles')"><img src='/style/themes/<? echo $set['set_them']; ?>/add_form/smiles.png' alt='Smiles�' /></a></td>
<td><a href="javascript:view_block('font')"><img src='/style/themes/<? echo $set['set_them']; ?>/add_form/font.png' alt='Fonts' /></a></td>
<td><a href="javascript:view_block('url')"><img src='/style/themes/<? echo $set['set_them']; ?>/add_form/bbcode.png' alt='BBcode' /></a></td>
</tr>
<tr>
<td colspan="3">
<div id='smiles'>
<table width='200'>
<tr>
<td><a href="javascript:emoticon(':smile:')"><img src="/style/smiles/smile.gif" border="0" alt="" title="Smile" /></a></td>
<td><a href="javascript:emoticon(':sad:')"><img src="/style/smiles/sad.gif" border="0" alt="" title="Sad" /></a></td>
<td><a href="javascript:emoticon(':COOL:')"><img src="/style/smiles/dirol.gif" border="0" alt="" title="Kruty" /></a></td>
<td><a href="javascript:emoticon(':wink:')"><img src="/style/smiles/wink.gif" border="0" alt="" title="Wink" /></a></td>
</tr>
<tr>
<td><a href="javascript:emoticon('O_O')"><img src="/style/smiles/shok.gif" border="0" alt="" title="Shock" /></a></td>
<td><a href="javascript:emoticon(':BRAVO:')"><img src="/style/smiles/clapping.gif" border="0" alt="" title="Clapping" /></a></td>
<td><a href="javascript:emoticon(':-D')"><img src="/style/smiles/biggrin.gif" border="0" alt="" title="Bigrain" /></a></td>
<td><a href="javascript:emoticon(':\'-(\ ')"><img src="/style/smiles/cray.gif" border="0" alt="" title="Cry" /></a></td>
</tr>
<tr>
<td><a href="javascript:emoticon(':angry:')"><img src="/style/smiles/aggressive.gif" border="0" alt="" title="Aggressive" /></a></td>
<td><a href="javascript:emoticon(':-|')"><img src="/style/smiles/fool.gif" border="0" alt="" title="Fool" /></a></td>
<td><a href="javascript:emoticon(':-/')"><img src="/style/smiles/beee.gif" border="0" alt="" title="Beee" /></a></td>
<td><a href="javascript:emoticon(':diablo:')"><img src="/style/smiles/diablo.gif" border="0" alt="" title="Devil" /></a></td>
</tr>
<tr>
<td><a href="javascript:emoticon(':crazy:')"><img src="/style/smiles/crazy.gif" border="0" alt="" title="Crazy" /></a></td>
<td><a href="javascript:emoticon(':HZ:')"><img src="/style/smiles/dntknw.gif" border="0" alt="" title="dntkw" /></a></td>
<td><a href="javascript:emoticon(':sorry:')"><img src="/style/smiles/sorry.gif" border="0" alt="" title="Sorry" /></a></td>
<td><a href="javascript:emoticon(':YAHOO:')"><img src="/style/smiles/yahoo.gif" border="0" alt="" title="" /></a></td>
</tr>
</table>
</div>
<div id='font' style='display: none;'>
<table width='200'>
<tr><td colspan='5'>Fonts:</td></tr>
<tr>
<td colspan='5'>
<a href="javascript:bbstyle(0)" title='Bold'><b>B</b></a>&nbsp;&nbsp;
<a href="javascript:bbstyle(4)" title='Underline'><u>U</u></a>&nbsp;&nbsp;
<a href="javascript:bbstyle(2)" title='Italic'><em>I</em></a>&nbsp;&nbsp;
<a href="javascript:bbstyle(6)" title='Big'><big>Big</big></a>&nbsp;&nbsp;
<a href="javascript:bbstyle(8)" title='Small'><small>Small</small></a>
</td>
</tr>
<tr><td colspan='5'>Font Colors:</td></tr>
<tr>
<td><a href="javascript:bbstyle(10)" title='Red'><span style="background-color:#ff0000;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></a></td>
<td><a href="javascript:bbstyle(12)" title='Blue'><span style="background-color:#0000ff;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></a></td>
<td><a href="javascript:bbstyle(14)" title='Green'><span style="background-color:#00ff00;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></a></td>
<td><a href="javascript:bbstyle(16)" title='White'><span style="background-color:#FFFFFF;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></a></td>
<td><a href="javascript:bbstyle(18)" title='Yellow'><span style="background-color:#ffff22;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></a></td>

</tr>
</table>
</div>

<div id='url' style='display: none;'>
<table width='200'>
<tr><td>

Link address:<br />
<input type='text' id='url_http' value='http://' /><br />
Link title:<br />
<input type='text' id='url_name' value='Link' onfocus="if (this.value=='Link'){this.value='';}" onblur="if (this.value==''){this.value='Link';}" /><br />
<br />
<a href='javascript:add_url();'>Insert Link</a>

</td></tr>
</table>
</div>

</td>
</tr>

</table>

</td>
</tr>
</table>
<?
function add_form($str)
{
return preg_replace("#(\n|\r|<br />)+</form>#msiu", " (Ctrl + Enter) </form>", $str);
}
ob_start('add_form');

?>