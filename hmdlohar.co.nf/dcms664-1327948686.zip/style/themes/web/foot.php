<?
if ($_SERVER['PHP_SELF']=='/index.php')
{
include_once H.'style/themes/'.$set['set_them'].'/news.php';
include_once H.'style/themes/'.$set['set_them'].'/main.php';
}
else
{
?>
</td>
<td class='block23'>

</td>
</tr>
<tr>
<td class='block31'>
&nbsp;
</td>
<td class='block32'>
&nbsp;
</td>
<td class='block33'>
&nbsp;
</td>
</tr>
</table>
<?
}

?>

</td>
<td class='table_right'>
<?
include_once H.'style/themes/'.$set['set_them'].'/aut.php';
?>

<?
echo "<div class='rekl'>\n";
rekl(3);
echo "</div>\n";
?>

</td></tr>
<tr>
<td width='100%' colspan='3'>

</td>
</tr>
</table>
<?
include_once H.'style/themes/'.$set['set_them'].'/bottom.php';
?>
</div>
</body>
</html>