<table class="bottom" cellspacing="0" cellpadding="0">
<tr>
<td>
&nbsp;
&nbsp;
&nbsp;
&nbsp;
<? echo "<a href='/users.php'>All Users: ".mysql_result(mysql_query("SELECT COUNT(*) FROM `user`"), 0)."</a><br />\n"; ?>
</td>
<td>
<? echo "<a href='/online.php'>Now Online: ".mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `date_last` > ".(time()-600).""), 0)."</a>"; ?>
</td>
<td>
<? echo "<a href='/online_g.php'>Visitors on site: ".mysql_result(mysql_query("SELECT COUNT(*) FROM `guests` WHERE `date_last` > ".(time()-600)." AND `pereh` > '0'"), 0)."</a><br />\n"; ?>
</td>

<td>
<?
list($msec, $sec) = explode(chr(32), microtime());
if (isset($user) && $user['level']!=0) echo "Page generation: ".round(($sec + $msec) - $conf['headtime'], 3)." secs<br />\n";

?>
</td>
<td>
<a href='http://dcms.su' title='Free Wap-engine'>
<img src='/style/themes/<?echo $set['set_them'];?>/copy.png' alt='' />
</a>
</td>
</tr>
</table>