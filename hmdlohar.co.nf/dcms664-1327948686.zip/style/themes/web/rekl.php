<?


if (mysql_result(mysql_query("SELECT COUNT(*) FROM `rekl` WHERE `sel` = '1' AND `time_last` > '".time()."'"),0)>0)
{
?><table class='table_block' cellspacing="0" cellpadding="0">
<tr>
<td class='block11'>
&nbsp;
</td>
<td class='block12'>
Партнеры
</td>
<td class='block13'>
&nbsp;
</td>
</tr>
<tr>
<td class='block21'>

</td>
<td class='block22'>

<?
echo "<div class='menu'>\n";



$q_rekl=mysql_query("SELECT * FROM `rekl` WHERE `sel` = '1' AND `time_last` > '".time()."' ORDER BY id ASC");
while ($post_rekl = mysql_fetch_assoc($q_rekl))
{

if ($post_rekl['dop_str']==1)
echo "<a target='_blank' href='/go.php?go=$post_rekl[id]'>";
else
echo "<a target='_blank' href='$post_rekl[link]'>";

if ($post_rekl['img']==NULL)echo "$post_rekl[name]";
else echo "<img src='$post_rekl[img]' alt='$post_rekl[name]' />";
echo "</a><br />\n";
}


echo "</div>\n";
?>
</td>
<td class='block23'>
</td>
</tr>
<tr>
<td class='block31'>
&nbsp;
</td>
<td class='block32'>
&nbsp;
</td>
<td class='block33'>
&nbsp;
</td>
</tr>
</table><?
}



if ($set['rekl']=='mobiads'){
if (isset ($set['mobiads_id']) && $set['mobiads_id']!=0 && isset ($set['mobiads_num_links']) && $set['mobiads_num_links']!=0){
?><table width='100%' cellspacing="0" cellpadding="0">
<tr>
<td class='block11'>
&nbsp;
</td>
<td class='block12'>Реклама</td>
<td class='block13'>
&nbsp;
</td>
</tr>
<tr>
<td class='block21'></td>
<td class='block22'><?
echo "<div class='menu'>\n";
echo "<!--mobiads.ru $set[mobiads_id]-->\n"; 
include_once H.'sys/inc/mobiads.php';
$ads = @get_ads($set['mobiads_id'], $set['mobiads_code'],$set['mobiads_num_links']); 
if($ads['STATUS'] == 'OK') 
foreach($ads['ADS'] as $link) 
{
echo '<a target="_blank" href="'.htmlspecialchars($link[0], ENT_QUOTES, 'UTF-8').'">'.htmlspecialchars($link[1], ENT_QUOTES, 'UTF-8')."</a><br />\n"; 
}
else echo $ads['DESCRIPTION'];
echo "</div>\n";
?>
</td>
<td class='block23'></td>
</tr>
<tr>
<td class='block31'>
&nbsp;
</td>
<td class='block32'>
&nbsp;
</td>
<td class='block33'>
&nbsp;
</td>
</tr>
</table>
<?
}
}
if ($set['rekl']=='wappc' && $set['wappc_num_links']!=0){
?>
<table class='table_block' cellspacing="0" cellpadding="0">
<tr>
<td class='block11'>
&nbsp;
</td>
<td class='block12'>
Реклама</td>
<td class='block13'>
&nbsp;
</td>
</tr>
<tr>
<td class='block21'></td>
<td class='block22'>
<div class="menu">
<?
echo "<!-- http://wappc.biz/?uid=".ereg_replace('\..*$','',$set['wappc_id'])." -->";
include_once H.'sys/inc/libwappc3.php';
global $wappc3_curl;
$wappc3_curl=0;
print GetFeedWAPPC3($set['wappc_num_links'],array('charset'=>'utf-8','temp'=>H.'sys/tmp','aff'=>"$set[wappc_id]",'empty'=>"<a target='_blank' href='http://wappc.biz/partner.php?uid=5408'>Заработок WAP-мастеру</a>",'template'=>'%code%','sep'=>'<br />','topbid'=>1,'operator'=>1));
?>
</div>
</td>
<td class='block23'></td>
</tr>
<tr>
<td class='block31'>
&nbsp;
</td>
<td class='block32'>
&nbsp;
</td>
<td class='block33'>
&nbsp;
</td>
</tr>
</table><?
}
?>