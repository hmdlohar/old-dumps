<table class='table_block' cellspacing="0" cellpadding="0">
<tr>
<td class='block11'>
&nbsp;
</td>
<td class='block12'>
<?
if (isset($user))
echo $user['nick'];
else
echo "You are: &nbsp;Guest";
?>
</td>
<td class='block13'>
&nbsp;
</td>
</tr>
<tr>
<td class='block21'></td>
<td class='block22'>
<div class='menu'>
<?
if (isset($user))
{

include_once H.'sys/inc/umenu.php';

echo "<br />\n";




echo "<span class='ank_n'>Points:</span> <span class='ank_d'>$user[balls]</span><br />\n";
echo "<span class='ank_n'>Rating:</span> <span class='ank_d'>$user[rating]</span><br />\n";
if ($user['level']>0)
{
if ($user['ip']!=0)echo "<span class='ank_n'>IP:</span> <span class='ank_d'>".long2ip($user['ip'])."</span><br />\n";
if ($user['ua']!=NULL)echo "<span class='ank_n'>UA:</span> <span class='ank_d'>$user[ua]</span><br />\n";
if (opsos($user['ip']))echo "<span class='ank_n'>IP:</span> <span class='ank_d'>".opsos($user['ip'])."</span><br />\n";
}

echo "<br />\n";
echo "<a href='/exit.php'>Sign Out</a><br />\n";
}
else
{
echo "<form method='post' action='/?$passgen'>\n";
echo "Username:<br /><input type='text' name='nick' maxlength='32' /><br />\n";
echo "Password (<a href='/pass.php'>Lost</a>):<br /><input type='password' name='pass' maxlength='32' /><br />\n";
echo "<label><input type='checkbox' name='aut_save' value='1' /> Remember Me<br /></label>\n";
echo "<input type='submit' value='Sign In' />\n";
echo "</form><br />\n";

echo "<a href='/reg.php'><b>Register</b></a><br />\n";

}
?>
</div>
</td>
<td class='block23'></td>
</tr>
<tr>
<td class='block31'>
&nbsp;
</td>
<td class='block32'>
&nbsp;
</td>
<td class='block33'>
&nbsp;
</td>
</tr>
</table>